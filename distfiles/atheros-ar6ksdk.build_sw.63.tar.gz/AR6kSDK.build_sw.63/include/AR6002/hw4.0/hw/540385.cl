Change 540385 by jhou@jhou-dev on 2009/06/11 14:45:40

	updated analog register *.cfg and *.h files to ToT

Affected files ...

... //depot/chips/venus/dev/doc/headers/analog_intf_athr_wlan_reg.cfg#9 edit
... //depot/chips/venus/dev/doc/headers/analog_intf_athr_wlan_reg.h#12 edit

Differences ...

==== //depot/chips/venus/dev/doc/headers/analog_intf_athr_wlan_reg.cfg#9 (ktext) ====

42,47c42,47
<  an_rxrf_bias2_pwd_ir25agc5gh                          0x3     RXRF_BIAS2           0x1c004  10:8   0 1 1 2 1
<  an_rxrf_bias2_pwd_ir25agc5g                           0x3     RXRF_BIAS2           0x1c004  13:11  0 1 1 2 1
<  an_rxrf_bias2_pwd_ic25agc5g                           0x3     RXRF_BIAS2           0x1c004  16:14  0 1 1 2 1
<  an_rxrf_bias2_pwd_ir25agc2gh                          0x3     RXRF_BIAS2           0x1c004  19:17  0 1 1 2 1
<  an_rxrf_bias2_pwd_ir25agc2g                           0x3     RXRF_BIAS2           0x1c004  22:20  0 1 1 2 1
<  an_rxrf_bias2_pwd_ic25agc2g                           0x3     RXRF_BIAS2           0x1c004  25:23  0 1 1 2 1
---
>  an_rxrf_bias2_pwd_ir25spareh                          0x3     RXRF_BIAS2           0x1c004  10:8   0 1 1 2 1
>  an_rxrf_bias2_pwd_ir25spare                           0x3     RXRF_BIAS2           0x1c004  13:11  0 1 1 2 1
>  an_rxrf_bias2_pwd_ic25lnabuf                          0x3     RXRF_BIAS2           0x1c004  16:14  0 1 1 2 1
>  an_rxrf_bias2_pwd_ir25agch                            0x3     RXRF_BIAS2           0x1c004  19:17  0 1 1 2 1
>  an_rxrf_bias2_pwd_ir25agc                             0x3     RXRF_BIAS2           0x1c004  22:20  0 1 1 2 1
>  an_rxrf_bias2_pwd_ic25agc                             0x3     RXRF_BIAS2           0x1c004  25:23  0 1 1 2 1
73c73,78
<  an_rxrf_agc_spare                                     0x0     RXRF_AGC             0x1c00c  5:0    0 1 1 2 1
---
>  an_rxrf_agc_rf5g_on_during_calpa                      0x0     RXRF_AGC             0x1c00c  0      0 1 1 2 1
>  an_rxrf_agc_rf2g_on_during_calpa                      0x0     RXRF_AGC             0x1c00c  1      0 1 1 2 1
>  an_rxrf_agc_agc_out                                   0x0     RXRF_AGC             0x1c00c  2      0 0 1 2 1
>  an_rxrf_agc_lnabufgain2x                              0x0     RXRF_AGC             0x1c00c  3      0 1 1 2 1
>  an_rxrf_agc_lnabuf_pwd_ovr                            0x0     RXRF_AGC             0x1c00c  4      0 1 1 2 1
>  an_rxrf_agc_pwd_lnabuf                                0x0     RXRF_AGC             0x1c00c  5      0 1 1 2 1
83,92c88,100
<  an_txrf1_dcas2g                                       0x1     TXRF1                0x1c040  2:0    0 1 1 2 1
<  an_txrf1_ob2g_paloff                                  0x6     TXRF1                0x1c040  5:3    0 1 1 2 1
<  an_txrf1_ob2g_qam                                     0x6     TXRF1                0x1c040  8:6    0 1 1 2 1
<  an_txrf1_ob2g_psk                                     0x6     TXRF1                0x1c040  11:9   0 1 1 2 1
<  an_txrf1_ob2g_cck                                     0x6     TXRF1                0x1c040  14:12  0 1 1 2 1
<  an_txrf1_db2g                                         0x5     TXRF1                0x1c040  17:15  0 1 1 2 1
<  an_txrf1_pdout2g                                      0x0     TXRF1                0x1c040  18     0 1 1 2 1
<  an_txrf1_pddr2g                                       0x0     TXRF1                0x1c040  19     0 1 1 2 1
<  an_txrf1_pdmxr2g                                      0x0     TXRF1                0x1c040  20     0 1 1 2 1
<  an_txrf1_pdlo2g                                       0x0     TXRF1                0x1c040  21     0 1 1 2 1
---
>  an_txrf1_pdlobuf5g                                    0x0     TXRF1                0x1c040  0      0 1 1 2 1
>  an_txrf1_pdlodiv5g                                    0x0     TXRF1                0x1c040  1      0 1 1 2 1
>  an_txrf1_lobuf5gforced                                0x0     TXRF1                0x1c040  2      0 1 1 2 1
>  an_txrf1_lodiv5gforced                                0x1     TXRF1                0x1c040  3      0 1 1 2 1
>  an_txrf1_padrv2gn5g                                   0xf     TXRF1                0x1c040  7:4    0 1 1 2 1
>  an_txrf1_padrv3gn5g                                   0xf     TXRF1                0x1c040  11:8   0 1 1 2 1
>  an_txrf1_padrv4gn5g                                   0xf     TXRF1                0x1c040  15:12  0 1 1 2 1
>  an_txrf1_localtxgain5g                                0x0     TXRF1                0x1c040  16     0 1 1 2 1
>  an_txrf1_pdout2g                                      0x0     TXRF1                0x1c040  17     0 1 1 2 1
>  an_txrf1_pddr2g                                       0x0     TXRF1                0x1c040  18     0 1 1 2 1
>  an_txrf1_pdmxr2g                                      0x0     TXRF1                0x1c040  19     0 1 1 2 1
>  an_txrf1_pdlobuf2g                                    0x0     TXRF1                0x1c040  20     0 1 1 2 1
>  an_txrf1_pdlodiv2g                                    0x0     TXRF1                0x1c040  21     0 1 1 2 1
98,111c106,116
<  an_txrf2_spare2                                       0x0     TXRF2                0x1c044  0      0 1 1 2 1
<  an_txrf2_d3b5g                                        0x3     TXRF2                0x1c044  3:1    0 1 1 2 1
<  an_txrf2_d4b5g                                        0x3     TXRF2                0x1c044  6:4    0 1 1 2 1
<  an_txrf2_pdout5g                                      0x0     TXRF2                0x1c044  10:7   0 1 1 2 1
<  an_txrf2_pdmxr5g                                      0x0     TXRF2                0x1c044  11     0 1 1 2 1
<  an_txrf2_pdlobuf5g                                    0x0     TXRF2                0x1c044  12     0 1 1 2 1
<  an_txrf2_pdlodiv5g                                    0x0     TXRF2                0x1c044  13     0 1 1 2 1
<  an_txrf2_lobuf5gforced                                0x0     TXRF2                0x1c044  14     0 1 1 2 1
<  an_txrf2_lodiv5gforced                                0x1     TXRF2                0x1c044  15     0 1 1 2 1
<  an_txrf2_padrv2gn5g                                   0xf     TXRF2                0x1c044  19:16  0 1 1 2 1
<  an_txrf2_padrv3gn5g                                   0xf     TXRF2                0x1c044  23:20  0 1 1 2 1
<  an_txrf2_padrv4gn5g                                   0xf     TXRF2                0x1c044  27:24  0 1 1 2 1
<  an_txrf2_localtxgain5g                                0x0     TXRF2                0x1c044  28     0 1 1 2 1
<  an_txrf2_ocas2g                                       0x3     TXRF2                0x1c044  31:29  0 1 1 2 1
---
>  an_txrf2_d3b5g                                        0x3     TXRF2                0x1c044  2:0    0 1 1 2 1
>  an_txrf2_d4b5g                                        0x3     TXRF2                0x1c044  5:3    0 1 1 2 1
>  an_txrf2_ocas2g                                       0x3     TXRF2                0x1c044  8:6    0 1 1 2 1
>  an_txrf2_dcas2g                                       0x1     TXRF2                0x1c044  11:9   0 1 1 2 1
>  an_txrf2_ob2g_paloff                                  0x6     TXRF2                0x1c044  14:12  0 1 1 2 1
>  an_txrf2_ob2g_qam                                     0x6     TXRF2                0x1c044  17:15  0 1 1 2 1
>  an_txrf2_ob2g_psk                                     0x6     TXRF2                0x1c044  20:18  0 1 1 2 1
>  an_txrf2_ob2g_cck                                     0x6     TXRF2                0x1c044  23:21  0 1 1 2 1
>  an_txrf2_db2g                                         0x5     TXRF2                0x1c044  26:24  0 1 1 2 1
>  an_txrf2_pdout5g                                      0x0     TXRF2                0x1c044  30:27  0 1 1 2 1
>  an_txrf2_pdmxr5g                                      0x0     TXRF2                0x1c044  31     0 1 1 2 1
113,114c118,130
<  an_txrf3_spare3                                       0x0     TXRF3                0x1c048  22:0   0 1 1 2 1
<  an_txrf3_cas5g                                        0x1     TXRF3                0x1c048  25:23  0 1 1 2 1
---
>  an_txrf3_filtr2g                                      0x1     TXRF3                0x1c048  1:0    0 1 1 2 1
>  an_txrf3_pwdfb2_2g                                    0x0     TXRF3                0x1c048  2      0 1 1 2 1
>  an_txrf3_pwdfb1_2g                                    0x0     TXRF3                0x1c048  3      0 1 1 2 1
>  an_txrf3_pdfb2g                                       0x0     TXRF3                0x1c048  4      0 1 1 2 1
>  an_txrf3_rdiv5g                                       0x3     TXRF3                0x1c048  6:5    0 1 1 2 1
>  an_txrf3_capdiv5g                                     0x4     TXRF3                0x1c048  9:7    0 1 1 2 1
>  an_txrf3_pdpredist5g                                  0x0     TXRF3                0x1c048  10     0 1 1 2 1
>  an_txrf3_rdiv2g                                       0x3     TXRF3                0x1c048  12:11  0 1 1 2 1
>  an_txrf3_pdpredist2g                                  0x0     TXRF3                0x1c048  13     0 1 1 2 1
>  an_txrf3_ocas5g                                       0x1     TXRF3                0x1c048  16:14  0 1 1 2 1
>  an_txrf3_d2cas5g                                      0x1     TXRF3                0x1c048  19:17  0 1 1 2 1
>  an_txrf3_d3cas5g                                      0x1     TXRF3                0x1c048  22:20  0 1 1 2 1
>  an_txrf3_d4cas5g                                      0x1     TXRF3                0x1c048  25:23  0 1 1 2 1
118,132c134,144
<  an_txrf4_comp2g_psk                                   0x0     TXRF4                0x1c04c  2:0    0 1 1 2 1
<  an_txrf4_comp2g_cck                                   0x0     TXRF4                0x1c04c  5:3    0 1 1 2 1
<  an_txrf4_amp2b2g_qam                                  0x5     TXRF4                0x1c04c  8:6    0 1 1 2 1
<  an_txrf4_amp2b2g_psk                                  0x5     TXRF4                0x1c04c  11:9   0 1 1 2 1
<  an_txrf4_amp2b2g_cck                                  0x5     TXRF4                0x1c04c  14:12  0 1 1 2 1
<  an_txrf4_amp2cas2g                                    0x3     TXRF4                0x1c04c  17:15  0 1 1 2 1
<  an_txrf4_filtr2g                                      0x1     TXRF4                0x1c04c  19:18  0 1 1 2 1
<  an_txrf4_pwdfb2_2g                                    0x0     TXRF4                0x1c04c  20     0 1 1 2 1
<  an_txrf4_pwdfb1_2g                                    0x0     TXRF4                0x1c04c  21     0 1 1 2 1
<  an_txrf4_pdfb2g                                       0x1     TXRF4                0x1c04c  22     0 1 1 2 1
<  an_txrf4_rdiv5g                                       0x3     TXRF4                0x1c04c  24:23  0 1 1 2 1
<  an_txrf4_capdiv5g                                     0x4     TXRF4                0x1c04c  27:25  0 1 1 2 1
<  an_txrf4_pdpredist5g                                  0x1     TXRF4                0x1c04c  28     0 1 1 2 1
<  an_txrf4_rdiv2g                                       0x3     TXRF4                0x1c04c  30:29  0 1 1 2 1
<  an_txrf4_pdpredist2g                                  0x1     TXRF4                0x1c04c  31     0 1 1 2 1
---
>  an_txrf4_pk1b2g_cck                                   0x1     TXRF4                0x1c04c  1:0    0 1 1 2 1
>  an_txrf4_miob2g_qam                                   0x5     TXRF4                0x1c04c  4:2    0 1 1 2 1
>  an_txrf4_miob2g_psk                                   0x5     TXRF4                0x1c04c  7:5    0 1 1 2 1
>  an_txrf4_miob2g_cck                                   0x5     TXRF4                0x1c04c  10:8   0 1 1 2 1
>  an_txrf4_comp2g_qam                                   0x0     TXRF4                0x1c04c  13:11  0 1 1 2 1
>  an_txrf4_comp2g_psk                                   0x0     TXRF4                0x1c04c  16:14  0 1 1 2 1
>  an_txrf4_comp2g_cck                                   0x0     TXRF4                0x1c04c  19:17  0 1 1 2 1
>  an_txrf4_amp2b2g_qam                                  0x5     TXRF4                0x1c04c  22:20  0 1 1 2 1
>  an_txrf4_amp2b2g_psk                                  0x5     TXRF4                0x1c04c  25:23  0 1 1 2 1
>  an_txrf4_amp2b2g_cck                                  0x5     TXRF4                0x1c04c  28:26  0 1 1 2 1
>  an_txrf4_amp2cas2g                                    0x3     TXRF4                0x1c04c  31:29  0 1 1 2 1
134,147c146,161
<  an_txrf5_fbhi2g                                       0x0     TXRF5                0x1c050  0      0 0 1 2 1
<  an_txrf5_fblo2g                                       0x0     TXRF5                0x1c050  1      0 0 1 2 1
<  an_txrf5_refhi2g                                      0x3     TXRF5                0x1c050  4:2    0 1 1 2 1
<  an_txrf5_reflo2g                                      0x6     TXRF5                0x1c050  7:5    0 1 1 2 1
<  an_txrf5_pk2b2g_qam                                   0x1     TXRF5                0x1c050  9:8    0 1 1 2 1
<  an_txrf5_pk2b2g_psk                                   0x1     TXRF5                0x1c050  11:10  0 1 1 2 1
<  an_txrf5_pk2b2g_cck                                   0x1     TXRF5                0x1c050  13:12  0 1 1 2 1
<  an_txrf5_pk1b2g_qam                                   0x1     TXRF5                0x1c050  15:14  0 1 1 2 1
<  an_txrf5_pk1b2g_psk                                   0x1     TXRF5                0x1c050  17:16  0 1 1 2 1
<  an_txrf5_pk1b2g_cck                                   0x1     TXRF5                0x1c050  19:18  0 1 1 2 1
<  an_txrf5_miob2g_qam                                   0x5     TXRF5                0x1c050  22:20  0 1 1 2 1
<  an_txrf5_miob2g_psk                                   0x5     TXRF5                0x1c050  25:23  0 1 1 2 1
<  an_txrf5_miob2g_cck                                   0x5     TXRF5                0x1c050  28:26  0 1 1 2 1
<  an_txrf5_comp2g_qam                                   0x0     TXRF5                0x1c050  31:29  0 1 1 2 1
---
>  an_txrf5_spare5                                       0x0     TXRF5                0x1c050  0      0 1 1 2 1
>  an_txrf5_pal_locked                                   0x0     TXRF5                0x1c050  1      0 0 1 2 1
>  an_txrf5_fbhi2g                                       0x0     TXRF5                0x1c050  2      0 0 1 2 1
>  an_txrf5_fblo2g                                       0x0     TXRF5                0x1c050  3      0 0 1 2 1
>  an_txrf5_nopalgain2g                                  0x1     TXRF5                0x1c050  4      0 1 1 2 1
>  an_txrf5_enpacal2g                                    0x1     TXRF5                0x1c050  5      0 1 1 2 1
>  an_txrf5_offset2g                                     0x40    TXRF5                0x1c050  12:6   0 1 1 2 1
>  an_txrf5_enoffsetcal2g                                0x1     TXRF5                0x1c050  13     0 1 1 2 1
>  an_txrf5_refhi2g                                      0x3     TXRF5                0x1c050  16:14  0 1 1 2 1
>  an_txrf5_reflo2g                                      0x6     TXRF5                0x1c050  19:17  0 1 1 2 1
>  an_txrf5_palclamp2g                                   0x2     TXRF5                0x1c050  21:20  0 1 1 2 1
>  an_txrf5_pk2b2g_qam                                   0x1     TXRF5                0x1c050  23:22  0 1 1 2 1
>  an_txrf5_pk2b2g_psk                                   0x1     TXRF5                0x1c050  25:24  0 1 1 2 1
>  an_txrf5_pk2b2g_cck                                   0x1     TXRF5                0x1c050  27:26  0 1 1 2 1
>  an_txrf5_pk1b2g_qam                                   0x1     TXRF5                0x1c050  29:28  0 1 1 2 1
>  an_txrf5_pk1b2g_psk                                   0x1     TXRF5                0x1c050  31:30  0 1 1 2 1
149,160c163,173
<  an_txrf6_spare6                                       0x0     TXRF6                0x1c054  0      0 1 1 2 1
<  an_txrf6_pal_locked                                   0x0     TXRF6                0x1c054  1      0 0 1 2 1
<  an_txrf6_padrvgn2g_smout                              0x0     TXRF6                0x1c054  7:2    0 0 1 2 1
<  an_txrf6_gainstep2g                                   0x1     TXRF6                0x1c054  10:8   0 1 1 2 1
<  an_txrf6_use_gain_delta2g                             0x0     TXRF6                0x1c054  11     0 1 1 2 1
<  an_txrf6_padrvgn_index_i2g                            0x8     TXRF6                0x1c054  15:12  0 1 1 2 1
<  an_txrf6_vcmondelay2g                                 0x3     TXRF6                0x1c054  18:16  0 1 1 2 1
<  an_txrf6_capdiv2g                                     0x4     TXRF6                0x1c054  21:19  0 1 1 2 1
<  an_txrf6_capdiv2govr                                  0x0     TXRF6                0x1c054  22     0 1 1 2 1
<  an_txrf6_enpacal2g                                    0x0     TXRF6                0x1c054  23     0 1 1 2 1
<  an_txrf6_offset2g                                     0x40    TXRF6                0x1c054  30:24  0 1 1 2 1
<  an_txrf6_enoffsetcal2g                                0x1     TXRF6                0x1c054  31     0 1 1 2 1
---
>  an_txrf6_palclkgate2g                                 0x0     TXRF6                0x1c054  0      0 1 1 2 1
>  an_txrf6_palfluctcount2g                              0x20    TXRF6                0x1c054  8:1    0 1 1 2 1
>  an_txrf6_palfluctgain2g                               0x2     TXRF6                0x1c054  10:9   0 1 1 2 1
>  an_txrf6_palnofluct2g                                 0x0     TXRF6                0x1c054  11     0 1 1 2 1
>  an_txrf6_gainstep2g                                   0x1     TXRF6                0x1c054  14:12  0 1 1 2 1
>  an_txrf6_use_gain_delta2g                             0x1     TXRF6                0x1c054  15     0 1 1 2 1
>  an_txrf6_capdiv_i2g                                   0x4     TXRF6                0x1c054  19:16  0 1 1 2 1
>  an_txrf6_padrvgn_index_i2g                            0x4     TXRF6                0x1c054  23:20  0 1 1 2 1
>  an_txrf6_vcmondelay2g                                 0x3     TXRF6                0x1c054  26:24  0 1 1 2 1
>  an_txrf6_capdiv2g                                     0x8     TXRF6                0x1c054  30:27  0 1 1 2 1
>  an_txrf6_capdiv2govr                                  0x0     TXRF6                0x1c054  31     0 1 1 2 1
167c180
<  an_txrf7_padrvgntab_0                                 0x4     TXRF7                0x1c058  31:26  0 1 1 2 1
---
>  an_txrf7_padrvgntab_0                                 0x3     TXRF7                0x1c058  31:26  0 1 1 2 1
170,174c183,187
<  an_txrf8_padrvgntab_9                                 0x1d    TXRF8                0x1c05c  7:2    0 1 1 2 1
<  an_txrf8_padrvgntab_8                                 0x1b    TXRF8                0x1c05c  13:8   0 1 1 2 1
<  an_txrf8_padrvgntab_7                                 0x19    TXRF8                0x1c05c  19:14  0 1 1 2 1
<  an_txrf8_padrvgntab_6                                 0xf     TXRF8                0x1c05c  25:20  0 1 1 2 1
<  an_txrf8_padrvgntab_5                                 0xd     TXRF8                0x1c05c  31:26  0 1 1 2 1
---
>  an_txrf8_padrvgntab_9                                 0x3f    TXRF8                0x1c05c  7:2    0 1 1 2 1
>  an_txrf8_padrvgntab_8                                 0x3f    TXRF8                0x1c05c  13:8   0 1 1 2 1
>  an_txrf8_padrvgntab_7                                 0x1f    TXRF8                0x1c05c  19:14  0 1 1 2 1
>  an_txrf8_padrvgntab_6                                 0x1b    TXRF8                0x1c05c  25:20  0 1 1 2 1
>  an_txrf8_padrvgntab_5                                 0xf     TXRF8                0x1c05c  31:26  0 1 1 2 1
178,181c191,194
<  an_txrf9_padrvgntab_13                                0x3d    TXRF9                0x1c060  13:8   0 1 1 2 1
<  an_txrf9_padrvgntab_12                                0x3b    TXRF9                0x1c060  19:14  0 1 1 2 1
<  an_txrf9_padrvgntab_11                                0x39    TXRF9                0x1c060  25:20  0 1 1 2 1
<  an_txrf9_padrvgntab_10                                0x1f    TXRF9                0x1c060  31:26  0 1 1 2 1
---
>  an_txrf9_padrvgntab_13                                0x3f    TXRF9                0x1c060  13:8   0 1 1 2 1
>  an_txrf9_padrvgntab_12                                0x3f    TXRF9                0x1c060  19:14  0 1 1 2 1
>  an_txrf9_padrvgntab_11                                0x3f    TXRF9                0x1c060  25:20  0 1 1 2 1
>  an_txrf9_padrvgntab_10                                0x3f    TXRF9                0x1c060  31:26  0 1 1 2 1
183,190c196,205
<  an_txrf10_spare10                                     0x0     TXRF10               0x1c064  12:0   0 1 1 2 1
<  an_txrf10_pdout5g_3caltx                              0x1     TXRF10               0x1c064  13     0 1 1 2 1
<  an_txrf10_d3b5gcaltx                                  0x7     TXRF10               0x1c064  16:14  0 1 1 2 1
<  an_txrf10_d4b5gcaltx                                  0x4     TXRF10               0x1c064  19:17  0 1 1 2 1
<  an_txrf10_padrvgn2gcaltx                              0x40    TXRF10               0x1c064  26:20  0 1 1 2 1
<  an_txrf10_db2gcaltx                                   0x7     TXRF10               0x1c064  29:27  0 1 1 2 1
<  an_txrf10_caltxshift                                  0x0     TXRF10               0x1c064  30     0 1 1 2 1
<  an_txrf10_caltxshiftovr                               0x0     TXRF10               0x1c064  31     0 1 1 2 1
---
>  an_txrf10_spare10                                     0x0     TXRF10               0x1c064  2:0    0 1 1 2 1
>  an_txrf10_pdout5g_3caltx                              0x1     TXRF10               0x1c064  3      0 1 1 2 1
>  an_txrf10_d3b5gcaltx                                  0x7     TXRF10               0x1c064  6:4    0 1 1 2 1
>  an_txrf10_d4b5gcaltx                                  0x4     TXRF10               0x1c064  9:7    0 1 1 2 1
>  an_txrf10_padrvgn2gcaltx                              0x40    TXRF10               0x1c064  16:10  0 1 1 2 1
>  an_txrf10_db2gcaltx                                   0x7     TXRF10               0x1c064  19:17  0 1 1 2 1
>  an_txrf10_caltxshift                                  0x0     TXRF10               0x1c064  20     0 1 1 2 1
>  an_txrf10_caltxshiftovr                               0x0     TXRF10               0x1c064  21     0 1 1 2 1
>  an_txrf10_padrvgn2g_smout                             0x0     TXRF10               0x1c064  27:22  0 0 1 2 1
>  an_txrf10_padrvgn_index2g_smout                       0x0     TXRF10               0x1c064  31:28  0 0 1 2 1
193,198c208,213
<  an_txrf11_pwd_ir25mixbias5g                           0x3     TXRF11               0x1c068  4:2    0 1 1 2 1
<  an_txrf11_pwd_ir25mixdiv5g                            0x3     TXRF11               0x1c068  7:5    0 1 1 2 1
<  an_txrf11_pwd_ir25pa2g                                0x3     TXRF11               0x1c068  10:8   0 1 1 2 1
<  an_txrf11_pwd_ir25mixbias2g                           0x3     TXRF11               0x1c068  13:11  0 1 1 2 1
<  an_txrf11_pwd_ir25mixdiv2g                            0x3     TXRF11               0x1c068  16:14  0 1 1 2 1
<  an_txrf11_pwd_icspare                                 0x3     TXRF11               0x1c068  19:17  0 1 1 2 1
---
>  an_txrf11_pwd_ir25mixdiv5g                            0x3     TXRF11               0x1c068  4:2    0 1 1 2 1
>  an_txrf11_pwd_ir25pa2g                                0x3     TXRF11               0x1c068  7:5    0 1 1 2 1
>  an_txrf11_pwd_ir25mixbias2g                           0x3     TXRF11               0x1c068  10:8   0 1 1 2 1
>  an_txrf11_pwd_ir25mixdiv2g                            0x3     TXRF11               0x1c068  13:11  0 1 1 2 1
>  an_txrf11_pwd_icspare                                 0x3     TXRF11               0x1c068  16:14  0 1 1 2 1
>  an_txrf11_pwd_ic25tempsen                             0x3     TXRF11               0x1c068  19:17  0 1 1 2 1
205,210c220,227
<  an_txrf12_spare12_1                                   0x0     TXRF12               0x1c06c  15:8   0 1 1 2 1
<  an_txrf12_atbsel5g                                    0x0     TXRF12               0x1c06c  19:16  0 1 1 2 1
<  an_txrf12_atbsel2g                                    0x0     TXRF12               0x1c06c  22:20  0 1 1 2 1
<  an_txrf12_pwd_irspare                                 0x3     TXRF12               0x1c06c  25:23  0 1 1 2 1
<  an_txrf12_pwd_ir25pa5g2                               0x3     TXRF12               0x1c06c  28:26  0 1 1 2 1
<  an_txrf12_pwd_ir25pa5g1                               0x3     TXRF12               0x1c06c  31:29  0 1 1 2 1
---
>  an_txrf12_spare12_1                                   0x0     TXRF12               0x1c06c  9:8    0 1 1 2 1
>  an_txrf12_atbsel5g                                    0x0     TXRF12               0x1c06c  13:10  0 1 1 2 1
>  an_txrf12_atbsel2g                                    0x0     TXRF12               0x1c06c  16:14  0 1 1 2 1
>  an_txrf12_pwd_irspare                                 0x3     TXRF12               0x1c06c  19:17  0 1 1 2 1
>  an_txrf12_pwd_ir25tempsen                             0x3     TXRF12               0x1c06c  22:20  0 1 1 2 1
>  an_txrf12_pwd_ir25pa5g2                               0x3     TXRF12               0x1c06c  25:23  0 1 1 2 1
>  an_txrf12_pwd_ir25pa5g1                               0x3     TXRF12               0x1c06c  28:26  0 1 1 2 1
>  an_txrf12_pwd_ir25mixbias5g                           0x3     TXRF12               0x1c06c  31:29  0 1 1 2 1
544,560c561,577
<  an_pllclkmoda2_spare                                  0x0     PLLCLKMODA2          0x1c284  0      0 1 1 2 1
<  an_pllclkmoda2_dacpwd                                 0x0     PLLCLKMODA2          0x1c284  1      0 1 1 2 1
<  an_pllclkmoda2_adcpwd                                 0x0     PLLCLKMODA2          0x1c284  2      0 1 1 2 1
<  an_pllclkmoda2_local_addac                            0x0     PLLCLKMODA2          0x1c284  3      0 1 1 2 1
<  an_pllclkmoda2_dac_clk_sel                            0x0     PLLCLKMODA2          0x1c284  5:4    0 1 1 2 1
<  an_pllclkmoda2_adc_clk_sel                            0x0     PLLCLKMODA2          0x1c284  9:6    0 1 1 2 1
<  an_pllclkmoda2_local_clkmoda                          0x0     PLLCLKMODA2          0x1c284  10     0 1 1 2 1
<  an_pllclkmoda2_pllbypass                              0x1     PLLCLKMODA2          0x1c284  11     0 1 1 2 1
<  an_pllclkmoda2_local_pllbypass                        0x0     PLLCLKMODA2          0x1c284  12     0 1 1 2 1
<  an_pllclkmoda2_pllatb                                 0x0     PLLCLKMODA2          0x1c284  14:13  0 1 1 2 1
<  an_pllclkmoda2_pll_svreg                              0x0     PLLCLKMODA2          0x1c284  15     0 1 1 2 1
<  an_pllclkmoda2_hi_freq_en                             0x0     PLLCLKMODA2          0x1c284  16     0 1 1 2 1
<  an_pllclkmoda2_rst_warm_int_l                         0x1     PLLCLKMODA2          0x1c284  17     0 1 1 2 1
<  an_pllclkmoda2_rst_warm_ovr                           0x0     PLLCLKMODA2          0x1c284  18     0 1 1 2 1
<  an_pllclkmoda2_pll_kvco                               0x0     PLLCLKMODA2          0x1c284  20:19  0 1 1 2 1
<  an_pllclkmoda2_pllicp                                 0x4     PLLCLKMODA2          0x1c284  23:21  0 1 1 2 1
<  an_pllclkmoda2_pllfilter                              0x33    PLLCLKMODA2          0x1c284  31:24  0 1 1 2 1
---
>  an_pllclkmoda2_spare                                  0x0     PLLCLKMODA2          0x1c284  3:0    0 1 1 2 1
>  an_pllclkmoda2_dacpwd                                 0x0     PLLCLKMODA2          0x1c284  4      0 1 1 2 1
>  an_pllclkmoda2_adcpwd                                 0x0     PLLCLKMODA2          0x1c284  5      0 1 1 2 1
>  an_pllclkmoda2_local_addac                            0x0     PLLCLKMODA2          0x1c284  6      0 1 1 2 1
>  an_pllclkmoda2_dac_clk_sel                            0x0     PLLCLKMODA2          0x1c284  8:7    0 1 1 2 1
>  an_pllclkmoda2_adc_clk_sel                            0x0     PLLCLKMODA2          0x1c284  12:9   0 1 1 2 1
>  an_pllclkmoda2_local_clkmoda                          0x0     PLLCLKMODA2          0x1c284  13     0 1 1 2 1
>  an_pllclkmoda2_pllbypass                              0x1     PLLCLKMODA2          0x1c284  14     0 1 1 2 1
>  an_pllclkmoda2_local_pllbypass                        0x0     PLLCLKMODA2          0x1c284  15     0 1 1 2 1
>  an_pllclkmoda2_pllatb                                 0x0     PLLCLKMODA2          0x1c284  17:16  0 1 1 2 1
>  an_pllclkmoda2_pll_svreg                              0x0     PLLCLKMODA2          0x1c284  18     0 1 1 2 1
>  an_pllclkmoda2_hi_freq_en                             0x0     PLLCLKMODA2          0x1c284  19     0 1 1 2 1
>  an_pllclkmoda2_rst_warm_int_l                         0x1     PLLCLKMODA2          0x1c284  20     0 1 1 2 1
>  an_pllclkmoda2_rst_warm_ovr                           0x0     PLLCLKMODA2          0x1c284  21     0 1 1 2 1
>  an_pllclkmoda2_pll_kvco                               0x0     PLLCLKMODA2          0x1c284  23:22  0 1 1 2 1
>  an_pllclkmoda2_pllicp                                 0x4     PLLCLKMODA2          0x1c284  26:24  0 1 1 2 1
>  an_pllclkmoda2_pllfilter                              0x8     PLLCLKMODA2          0x1c284  31:27  0 1 1 2 1
562,576c579,592
<  an_top_spare                                          0x0     TOP                  0x1c288  1:0    0 1 1 2 1
<  an_top_test_padq_en                                   0x0     TOP                  0x1c288  2      0 1 1 2 1
<  an_top_areg_lvl                                       0x1     TOP                  0x1c288  5:3    0 1 1 2 1
<  an_top_xpaon2                                         0x0     TOP                  0x1c288  6      0 1 1 2 1
<  an_top_xpaon5                                         0x0     TOP                  0x1c288  7      0 1 1 2 1
<  an_top_testiq_rsel                                    0x0     TOP                  0x1c288  8      0 1 1 2 1
<  an_top_test_padi_en                                   0x0     TOP                  0x1c288  9      0 1 1 2 1
<  an_top_pwdv2i                                         0x0     TOP                  0x1c288  10     0 1 1 2 1
<  an_top_pwdbias                                        0x0     TOP                  0x1c288  11     0 1 1 2 1
<  an_top_pwdbg                                          0x0     TOP                  0x1c288  12     0 1 1 2 1
<  an_top_xpabiaslvl                                     0x0     TOP                  0x1c288  14:13  0 1 1 2 1
<  an_top_force_xpaon                                    0x0     TOP                  0x1c288  15     0 1 1 2 1
<  an_top_atbselect                                      0x0     TOP                  0x1c288  16     0 1 1 2 1
<  an_top_local_xpa                                      0x0     TOP                  0x1c288  17     0 1 1 2 1
<  an_top_xpabias_bypass                                 0x0     TOP                  0x1c288  18     0 1 1 2 1
---
>  an_top_spare                                          0x1     TOP                  0x1c288  2:0    0 1 1 2 1
>  an_top_pwdbias                                        0x0     TOP                  0x1c288  3      0 1 1 2 1
>  an_top_flip_xpabias                                   0x0     TOP                  0x1c288  4      0 1 1 2 1
>  an_top_xpaon2                                         0x0     TOP                  0x1c288  5      0 1 1 2 1
>  an_top_xpaon5                                         0x0     TOP                  0x1c288  6      0 1 1 2 1
>  an_top_xpashort2gnd                                   0x1     TOP                  0x1c288  7      0 1 1 2 1
>  an_top_xpabiaslvl                                     0xf     TOP                  0x1c288  11:8   0 1 1 2 1
>  an_top_xpabias_en                                     0x0     TOP                  0x1c288  12     0 1 1 2 1
>  an_top_atbselect                                      0x0     TOP                  0x1c288  13     0 1 1 2 1
>  an_top_local_xpa                                      0x0     TOP                  0x1c288  14     0 1 1 2 1
>  an_top_xpabias_bypass                                 0x0     TOP                  0x1c288  15     0 1 1 2 1
>  an_top_test_padq_en                                   0x0     TOP                  0x1c288  16     0 1 1 2 1
>  an_top_test_padi_en                                   0x0     TOP                  0x1c288  17     0 1 1 2 1
>  an_top_testiq_rsel                                    0x0     TOP                  0x1c288  18     0 1 1 2 1
612,615c628,631
<  an_xtal_xtal_highz                                    0x0     XTAL                 0x1c290  13     0 1 1 2 1
<  an_xtal_xtal_drvpnr                                   0x0     XTAL                 0x1c290  15:14  0 1 1 2 1
<  an_xtal_xtal_capoutdac                                0x0     XTAL                 0x1c290  22:16  0 1 1 2 1
<  an_xtal_xtal_capindac                                 0x0     XTAL                 0x1c290  29:23  0 1 1 2 1
---
>  an_xtal_xtal_shrtxin                                  0x0     XTAL                 0x1c290  13     0 1 1 2 1
>  an_xtal_xtal_drvstr                                   0x0     XTAL                 0x1c290  15:14  0 1 1 2 1
>  an_xtal_xtal_capoutdac                                0x35    XTAL                 0x1c290  22:16  0 1 1 2 1
>  an_xtal_xtal_capindac                                 0x35    XTAL                 0x1c290  29:23  0 1 1 2 1

==== //depot/chips/venus/dev/doc/headers/analog_intf_athr_wlan_reg.h#12 (ktext) ====

104,133c104,133
< #define PHY_ANALOG_RXRF_BIAS2_PWD_IR25AGC5GH_MSB                                                             10
< #define PHY_ANALOG_RXRF_BIAS2_PWD_IR25AGC5GH_LSB                                                              8
< #define PHY_ANALOG_RXRF_BIAS2_PWD_IR25AGC5GH_MASK                                                    0x00000700
< #define PHY_ANALOG_RXRF_BIAS2_PWD_IR25AGC5GH_GET(x)                                   (((x) & 0x00000700) >> 8)
< #define PHY_ANALOG_RXRF_BIAS2_PWD_IR25AGC5GH_SET(x)                                   (((x) << 8) & 0x00000700)
< #define PHY_ANALOG_RXRF_BIAS2_PWD_IR25AGC5G_MSB                                                              13
< #define PHY_ANALOG_RXRF_BIAS2_PWD_IR25AGC5G_LSB                                                              11
< #define PHY_ANALOG_RXRF_BIAS2_PWD_IR25AGC5G_MASK                                                     0x00003800
< #define PHY_ANALOG_RXRF_BIAS2_PWD_IR25AGC5G_GET(x)                                   (((x) & 0x00003800) >> 11)
< #define PHY_ANALOG_RXRF_BIAS2_PWD_IR25AGC5G_SET(x)                                   (((x) << 11) & 0x00003800)
< #define PHY_ANALOG_RXRF_BIAS2_PWD_IC25AGC5G_MSB                                                              16
< #define PHY_ANALOG_RXRF_BIAS2_PWD_IC25AGC5G_LSB                                                              14
< #define PHY_ANALOG_RXRF_BIAS2_PWD_IC25AGC5G_MASK                                                     0x0001c000
< #define PHY_ANALOG_RXRF_BIAS2_PWD_IC25AGC5G_GET(x)                                   (((x) & 0x0001c000) >> 14)
< #define PHY_ANALOG_RXRF_BIAS2_PWD_IC25AGC5G_SET(x)                                   (((x) << 14) & 0x0001c000)
< #define PHY_ANALOG_RXRF_BIAS2_PWD_IR25AGC2GH_MSB                                                             19
< #define PHY_ANALOG_RXRF_BIAS2_PWD_IR25AGC2GH_LSB                                                             17
< #define PHY_ANALOG_RXRF_BIAS2_PWD_IR25AGC2GH_MASK                                                    0x000e0000
< #define PHY_ANALOG_RXRF_BIAS2_PWD_IR25AGC2GH_GET(x)                                  (((x) & 0x000e0000) >> 17)
< #define PHY_ANALOG_RXRF_BIAS2_PWD_IR25AGC2GH_SET(x)                                  (((x) << 17) & 0x000e0000)
< #define PHY_ANALOG_RXRF_BIAS2_PWD_IR25AGC2G_MSB                                                              22
< #define PHY_ANALOG_RXRF_BIAS2_PWD_IR25AGC2G_LSB                                                              20
< #define PHY_ANALOG_RXRF_BIAS2_PWD_IR25AGC2G_MASK                                                     0x00700000
< #define PHY_ANALOG_RXRF_BIAS2_PWD_IR25AGC2G_GET(x)                                   (((x) & 0x00700000) >> 20)
< #define PHY_ANALOG_RXRF_BIAS2_PWD_IR25AGC2G_SET(x)                                   (((x) << 20) & 0x00700000)
< #define PHY_ANALOG_RXRF_BIAS2_PWD_IC25AGC2G_MSB                                                              25
< #define PHY_ANALOG_RXRF_BIAS2_PWD_IC25AGC2G_LSB                                                              23
< #define PHY_ANALOG_RXRF_BIAS2_PWD_IC25AGC2G_MASK                                                     0x03800000
< #define PHY_ANALOG_RXRF_BIAS2_PWD_IC25AGC2G_GET(x)                                   (((x) & 0x03800000) >> 23)
< #define PHY_ANALOG_RXRF_BIAS2_PWD_IC25AGC2G_SET(x)                                   (((x) << 23) & 0x03800000)
---
> #define PHY_ANALOG_RXRF_BIAS2_PWD_IR25SPAREH_MSB                                                             10
> #define PHY_ANALOG_RXRF_BIAS2_PWD_IR25SPAREH_LSB                                                              8
> #define PHY_ANALOG_RXRF_BIAS2_PWD_IR25SPAREH_MASK                                                    0x00000700
> #define PHY_ANALOG_RXRF_BIAS2_PWD_IR25SPAREH_GET(x)                                   (((x) & 0x00000700) >> 8)
> #define PHY_ANALOG_RXRF_BIAS2_PWD_IR25SPAREH_SET(x)                                   (((x) << 8) & 0x00000700)
> #define PHY_ANALOG_RXRF_BIAS2_PWD_IR25SPARE_MSB                                                              13
> #define PHY_ANALOG_RXRF_BIAS2_PWD_IR25SPARE_LSB                                                              11
> #define PHY_ANALOG_RXRF_BIAS2_PWD_IR25SPARE_MASK                                                     0x00003800
> #define PHY_ANALOG_RXRF_BIAS2_PWD_IR25SPARE_GET(x)                                   (((x) & 0x00003800) >> 11)
> #define PHY_ANALOG_RXRF_BIAS2_PWD_IR25SPARE_SET(x)                                   (((x) << 11) & 0x00003800)
> #define PHY_ANALOG_RXRF_BIAS2_PWD_IC25LNABUF_MSB                                                             16
> #define PHY_ANALOG_RXRF_BIAS2_PWD_IC25LNABUF_LSB                                                             14
> #define PHY_ANALOG_RXRF_BIAS2_PWD_IC25LNABUF_MASK                                                    0x0001c000
> #define PHY_ANALOG_RXRF_BIAS2_PWD_IC25LNABUF_GET(x)                                  (((x) & 0x0001c000) >> 14)
> #define PHY_ANALOG_RXRF_BIAS2_PWD_IC25LNABUF_SET(x)                                  (((x) << 14) & 0x0001c000)
> #define PHY_ANALOG_RXRF_BIAS2_PWD_IR25AGCH_MSB                                                               19
> #define PHY_ANALOG_RXRF_BIAS2_PWD_IR25AGCH_LSB                                                               17
> #define PHY_ANALOG_RXRF_BIAS2_PWD_IR25AGCH_MASK                                                      0x000e0000
> #define PHY_ANALOG_RXRF_BIAS2_PWD_IR25AGCH_GET(x)                                    (((x) & 0x000e0000) >> 17)
> #define PHY_ANALOG_RXRF_BIAS2_PWD_IR25AGCH_SET(x)                                    (((x) << 17) & 0x000e0000)
> #define PHY_ANALOG_RXRF_BIAS2_PWD_IR25AGC_MSB                                                                22
> #define PHY_ANALOG_RXRF_BIAS2_PWD_IR25AGC_LSB                                                                20
> #define PHY_ANALOG_RXRF_BIAS2_PWD_IR25AGC_MASK                                                       0x00700000
> #define PHY_ANALOG_RXRF_BIAS2_PWD_IR25AGC_GET(x)                                     (((x) & 0x00700000) >> 20)
> #define PHY_ANALOG_RXRF_BIAS2_PWD_IR25AGC_SET(x)                                     (((x) << 20) & 0x00700000)
> #define PHY_ANALOG_RXRF_BIAS2_PWD_IC25AGC_MSB                                                                25
> #define PHY_ANALOG_RXRF_BIAS2_PWD_IC25AGC_LSB                                                                23
> #define PHY_ANALOG_RXRF_BIAS2_PWD_IC25AGC_MASK                                                       0x03800000
> #define PHY_ANALOG_RXRF_BIAS2_PWD_IC25AGC_GET(x)                                     (((x) & 0x03800000) >> 23)
> #define PHY_ANALOG_RXRF_BIAS2_PWD_IC25AGC_SET(x)                                     (((x) << 23) & 0x03800000)
257,261c257,285
< #define PHY_ANALOG_RXRF_AGC_SPARE_MSB                                                                         5
< #define PHY_ANALOG_RXRF_AGC_SPARE_LSB                                                                         0
< #define PHY_ANALOG_RXRF_AGC_SPARE_MASK                                                               0x0000003f
< #define PHY_ANALOG_RXRF_AGC_SPARE_GET(x)                                              (((x) & 0x0000003f) >> 0)
< #define PHY_ANALOG_RXRF_AGC_SPARE_SET(x)                                              (((x) << 0) & 0x0000003f)
---
> #define PHY_ANALOG_RXRF_AGC_RF5G_ON_DURING_CALPA_MSB                                                          0
> #define PHY_ANALOG_RXRF_AGC_RF5G_ON_DURING_CALPA_LSB                                                          0
> #define PHY_ANALOG_RXRF_AGC_RF5G_ON_DURING_CALPA_MASK                                                0x00000001
> #define PHY_ANALOG_RXRF_AGC_RF5G_ON_DURING_CALPA_GET(x)                               (((x) & 0x00000001) >> 0)
> #define PHY_ANALOG_RXRF_AGC_RF5G_ON_DURING_CALPA_SET(x)                               (((x) << 0) & 0x00000001)
> #define PHY_ANALOG_RXRF_AGC_RF2G_ON_DURING_CALPA_MSB                                                          1
> #define PHY_ANALOG_RXRF_AGC_RF2G_ON_DURING_CALPA_LSB                                                          1
> #define PHY_ANALOG_RXRF_AGC_RF2G_ON_DURING_CALPA_MASK                                                0x00000002
> #define PHY_ANALOG_RXRF_AGC_RF2G_ON_DURING_CALPA_GET(x)                               (((x) & 0x00000002) >> 1)
> #define PHY_ANALOG_RXRF_AGC_RF2G_ON_DURING_CALPA_SET(x)                               (((x) << 1) & 0x00000002)
> #define PHY_ANALOG_RXRF_AGC_AGC_OUT_MSB                                                                       2
> #define PHY_ANALOG_RXRF_AGC_AGC_OUT_LSB                                                                       2
> #define PHY_ANALOG_RXRF_AGC_AGC_OUT_MASK                                                             0x00000004
> #define PHY_ANALOG_RXRF_AGC_AGC_OUT_GET(x)                                            (((x) & 0x00000004) >> 2)
> #define PHY_ANALOG_RXRF_AGC_LNABUFGAIN2X_MSB                                                                  3
> #define PHY_ANALOG_RXRF_AGC_LNABUFGAIN2X_LSB                                                                  3
> #define PHY_ANALOG_RXRF_AGC_LNABUFGAIN2X_MASK                                                        0x00000008
> #define PHY_ANALOG_RXRF_AGC_LNABUFGAIN2X_GET(x)                                       (((x) & 0x00000008) >> 3)
> #define PHY_ANALOG_RXRF_AGC_LNABUFGAIN2X_SET(x)                                       (((x) << 3) & 0x00000008)
> #define PHY_ANALOG_RXRF_AGC_LNABUF_PWD_OVR_MSB                                                                4
> #define PHY_ANALOG_RXRF_AGC_LNABUF_PWD_OVR_LSB                                                                4
> #define PHY_ANALOG_RXRF_AGC_LNABUF_PWD_OVR_MASK                                                      0x00000010
> #define PHY_ANALOG_RXRF_AGC_LNABUF_PWD_OVR_GET(x)                                     (((x) & 0x00000010) >> 4)
> #define PHY_ANALOG_RXRF_AGC_LNABUF_PWD_OVR_SET(x)                                     (((x) << 4) & 0x00000010)
> #define PHY_ANALOG_RXRF_AGC_PWD_LNABUF_MSB                                                                    5
> #define PHY_ANALOG_RXRF_AGC_PWD_LNABUF_LSB                                                                    5
> #define PHY_ANALOG_RXRF_AGC_PWD_LNABUF_MASK                                                          0x00000020
> #define PHY_ANALOG_RXRF_AGC_PWD_LNABUF_GET(x)                                         (((x) & 0x00000020) >> 5)
> #define PHY_ANALOG_RXRF_AGC_PWD_LNABUF_SET(x)                                         (((x) << 5) & 0x00000020)
306,355c330,394
< #define PHY_ANALOG_TXRF1_DCAS2G_MSB                                                                           2
< #define PHY_ANALOG_TXRF1_DCAS2G_LSB                                                                           0
< #define PHY_ANALOG_TXRF1_DCAS2G_MASK                                                                 0x00000007
< #define PHY_ANALOG_TXRF1_DCAS2G_GET(x)                                                (((x) & 0x00000007) >> 0)
< #define PHY_ANALOG_TXRF1_DCAS2G_SET(x)                                                (((x) << 0) & 0x00000007)
< #define PHY_ANALOG_TXRF1_OB2G_PALOFF_MSB                                                                      5
< #define PHY_ANALOG_TXRF1_OB2G_PALOFF_LSB                                                                      3
< #define PHY_ANALOG_TXRF1_OB2G_PALOFF_MASK                                                            0x00000038
< #define PHY_ANALOG_TXRF1_OB2G_PALOFF_GET(x)                                           (((x) & 0x00000038) >> 3)
< #define PHY_ANALOG_TXRF1_OB2G_PALOFF_SET(x)                                           (((x) << 3) & 0x00000038)
< #define PHY_ANALOG_TXRF1_OB2G_QAM_MSB                                                                         8
< #define PHY_ANALOG_TXRF1_OB2G_QAM_LSB                                                                         6
< #define PHY_ANALOG_TXRF1_OB2G_QAM_MASK                                                               0x000001c0
< #define PHY_ANALOG_TXRF1_OB2G_QAM_GET(x)                                              (((x) & 0x000001c0) >> 6)
< #define PHY_ANALOG_TXRF1_OB2G_QAM_SET(x)                                              (((x) << 6) & 0x000001c0)
< #define PHY_ANALOG_TXRF1_OB2G_PSK_MSB                                                                        11
< #define PHY_ANALOG_TXRF1_OB2G_PSK_LSB                                                                         9
< #define PHY_ANALOG_TXRF1_OB2G_PSK_MASK                                                               0x00000e00
< #define PHY_ANALOG_TXRF1_OB2G_PSK_GET(x)                                              (((x) & 0x00000e00) >> 9)
< #define PHY_ANALOG_TXRF1_OB2G_PSK_SET(x)                                              (((x) << 9) & 0x00000e00)
< #define PHY_ANALOG_TXRF1_OB2G_CCK_MSB                                                                        14
< #define PHY_ANALOG_TXRF1_OB2G_CCK_LSB                                                                        12
< #define PHY_ANALOG_TXRF1_OB2G_CCK_MASK                                                               0x00007000
< #define PHY_ANALOG_TXRF1_OB2G_CCK_GET(x)                                             (((x) & 0x00007000) >> 12)
< #define PHY_ANALOG_TXRF1_OB2G_CCK_SET(x)                                             (((x) << 12) & 0x00007000)
< #define PHY_ANALOG_TXRF1_DB2G_MSB                                                                            17
< #define PHY_ANALOG_TXRF1_DB2G_LSB                                                                            15
< #define PHY_ANALOG_TXRF1_DB2G_MASK                                                                   0x00038000
< #define PHY_ANALOG_TXRF1_DB2G_GET(x)                                                 (((x) & 0x00038000) >> 15)
< #define PHY_ANALOG_TXRF1_DB2G_SET(x)                                                 (((x) << 15) & 0x00038000)
< #define PHY_ANALOG_TXRF1_PDOUT2G_MSB                                                                         18
< #define PHY_ANALOG_TXRF1_PDOUT2G_LSB                                                                         18
< #define PHY_ANALOG_TXRF1_PDOUT2G_MASK                                                                0x00040000
< #define PHY_ANALOG_TXRF1_PDOUT2G_GET(x)                                              (((x) & 0x00040000) >> 18)
< #define PHY_ANALOG_TXRF1_PDOUT2G_SET(x)                                              (((x) << 18) & 0x00040000)
< #define PHY_ANALOG_TXRF1_PDDR2G_MSB                                                                          19
< #define PHY_ANALOG_TXRF1_PDDR2G_LSB                                                                          19
< #define PHY_ANALOG_TXRF1_PDDR2G_MASK                                                                 0x00080000
< #define PHY_ANALOG_TXRF1_PDDR2G_GET(x)                                               (((x) & 0x00080000) >> 19)
< #define PHY_ANALOG_TXRF1_PDDR2G_SET(x)                                               (((x) << 19) & 0x00080000)
< #define PHY_ANALOG_TXRF1_PDMXR2G_MSB                                                                         20
< #define PHY_ANALOG_TXRF1_PDMXR2G_LSB                                                                         20
< #define PHY_ANALOG_TXRF1_PDMXR2G_MASK                                                                0x00100000
< #define PHY_ANALOG_TXRF1_PDMXR2G_GET(x)                                              (((x) & 0x00100000) >> 20)
< #define PHY_ANALOG_TXRF1_PDMXR2G_SET(x)                                              (((x) << 20) & 0x00100000)
< #define PHY_ANALOG_TXRF1_PDLO2G_MSB                                                                          21
< #define PHY_ANALOG_TXRF1_PDLO2G_LSB                                                                          21
< #define PHY_ANALOG_TXRF1_PDLO2G_MASK                                                                 0x00200000
< #define PHY_ANALOG_TXRF1_PDLO2G_GET(x)                                               (((x) & 0x00200000) >> 21)
< #define PHY_ANALOG_TXRF1_PDLO2G_SET(x)                                               (((x) << 21) & 0x00200000)
---
> #define PHY_ANALOG_TXRF1_PDLOBUF5G_MSB                                                                        0
> #define PHY_ANALOG_TXRF1_PDLOBUF5G_LSB                                                                        0
> #define PHY_ANALOG_TXRF1_PDLOBUF5G_MASK                                                              0x00000001
> #define PHY_ANALOG_TXRF1_PDLOBUF5G_GET(x)                                             (((x) & 0x00000001) >> 0)
> #define PHY_ANALOG_TXRF1_PDLOBUF5G_SET(x)                                             (((x) << 0) & 0x00000001)
> #define PHY_ANALOG_TXRF1_PDLODIV5G_MSB                                                                        1
> #define PHY_ANALOG_TXRF1_PDLODIV5G_LSB                                                                        1
> #define PHY_ANALOG_TXRF1_PDLODIV5G_MASK                                                              0x00000002
> #define PHY_ANALOG_TXRF1_PDLODIV5G_GET(x)                                             (((x) & 0x00000002) >> 1)
> #define PHY_ANALOG_TXRF1_PDLODIV5G_SET(x)                                             (((x) << 1) & 0x00000002)
> #define PHY_ANALOG_TXRF1_LOBUF5GFORCED_MSB                                                                    2
> #define PHY_ANALOG_TXRF1_LOBUF5GFORCED_LSB                                                                    2
> #define PHY_ANALOG_TXRF1_LOBUF5GFORCED_MASK                                                          0x00000004
> #define PHY_ANALOG_TXRF1_LOBUF5GFORCED_GET(x)                                         (((x) & 0x00000004) >> 2)
> #define PHY_ANALOG_TXRF1_LOBUF5GFORCED_SET(x)                                         (((x) << 2) & 0x00000004)
> #define PHY_ANALOG_TXRF1_LODIV5GFORCED_MSB                                                                    3
> #define PHY_ANALOG_TXRF1_LODIV5GFORCED_LSB                                                                    3
> #define PHY_ANALOG_TXRF1_LODIV5GFORCED_MASK                                                          0x00000008
> #define PHY_ANALOG_TXRF1_LODIV5GFORCED_GET(x)                                         (((x) & 0x00000008) >> 3)
> #define PHY_ANALOG_TXRF1_LODIV5GFORCED_SET(x)                                         (((x) << 3) & 0x00000008)
> #define PHY_ANALOG_TXRF1_PADRV2GN5G_MSB                                                                       7
> #define PHY_ANALOG_TXRF1_PADRV2GN5G_LSB                                                                       4
> #define PHY_ANALOG_TXRF1_PADRV2GN5G_MASK                                                             0x000000f0
> #define PHY_ANALOG_TXRF1_PADRV2GN5G_GET(x)                                            (((x) & 0x000000f0) >> 4)
> #define PHY_ANALOG_TXRF1_PADRV2GN5G_SET(x)                                            (((x) << 4) & 0x000000f0)
> #define PHY_ANALOG_TXRF1_PADRV3GN5G_MSB                                                                      11
> #define PHY_ANALOG_TXRF1_PADRV3GN5G_LSB                                                                       8
> #define PHY_ANALOG_TXRF1_PADRV3GN5G_MASK                                                             0x00000f00
> #define PHY_ANALOG_TXRF1_PADRV3GN5G_GET(x)                                            (((x) & 0x00000f00) >> 8)
> #define PHY_ANALOG_TXRF1_PADRV3GN5G_SET(x)                                            (((x) << 8) & 0x00000f00)
> #define PHY_ANALOG_TXRF1_PADRV4GN5G_MSB                                                                      15
> #define PHY_ANALOG_TXRF1_PADRV4GN5G_LSB                                                                      12
> #define PHY_ANALOG_TXRF1_PADRV4GN5G_MASK                                                             0x0000f000
> #define PHY_ANALOG_TXRF1_PADRV4GN5G_GET(x)                                           (((x) & 0x0000f000) >> 12)
> #define PHY_ANALOG_TXRF1_PADRV4GN5G_SET(x)                                           (((x) << 12) & 0x0000f000)
> #define PHY_ANALOG_TXRF1_LOCALTXGAIN5G_MSB                                                                   16
> #define PHY_ANALOG_TXRF1_LOCALTXGAIN5G_LSB                                                                   16
> #define PHY_ANALOG_TXRF1_LOCALTXGAIN5G_MASK                                                          0x00010000
> #define PHY_ANALOG_TXRF1_LOCALTXGAIN5G_GET(x)                                        (((x) & 0x00010000) >> 16)
> #define PHY_ANALOG_TXRF1_LOCALTXGAIN5G_SET(x)                                        (((x) << 16) & 0x00010000)
> #define PHY_ANALOG_TXRF1_PDOUT2G_MSB                                                                         17
> #define PHY_ANALOG_TXRF1_PDOUT2G_LSB                                                                         17
> #define PHY_ANALOG_TXRF1_PDOUT2G_MASK                                                                0x00020000
> #define PHY_ANALOG_TXRF1_PDOUT2G_GET(x)                                              (((x) & 0x00020000) >> 17)
> #define PHY_ANALOG_TXRF1_PDOUT2G_SET(x)                                              (((x) << 17) & 0x00020000)
> #define PHY_ANALOG_TXRF1_PDDR2G_MSB                                                                          18
> #define PHY_ANALOG_TXRF1_PDDR2G_LSB                                                                          18
> #define PHY_ANALOG_TXRF1_PDDR2G_MASK                                                                 0x00040000
> #define PHY_ANALOG_TXRF1_PDDR2G_GET(x)                                               (((x) & 0x00040000) >> 18)
> #define PHY_ANALOG_TXRF1_PDDR2G_SET(x)                                               (((x) << 18) & 0x00040000)
> #define PHY_ANALOG_TXRF1_PDMXR2G_MSB                                                                         19
> #define PHY_ANALOG_TXRF1_PDMXR2G_LSB                                                                         19
> #define PHY_ANALOG_TXRF1_PDMXR2G_MASK                                                                0x00080000
> #define PHY_ANALOG_TXRF1_PDMXR2G_GET(x)                                              (((x) & 0x00080000) >> 19)
> #define PHY_ANALOG_TXRF1_PDMXR2G_SET(x)                                              (((x) << 19) & 0x00080000)
> #define PHY_ANALOG_TXRF1_PDLOBUF2G_MSB                                                                       20
> #define PHY_ANALOG_TXRF1_PDLOBUF2G_LSB                                                                       20
> #define PHY_ANALOG_TXRF1_PDLOBUF2G_MASK                                                              0x00100000
> #define PHY_ANALOG_TXRF1_PDLOBUF2G_GET(x)                                            (((x) & 0x00100000) >> 20)
> #define PHY_ANALOG_TXRF1_PDLOBUF2G_SET(x)                                            (((x) << 20) & 0x00100000)
> #define PHY_ANALOG_TXRF1_PDLODIV2G_MSB                                                                       21
> #define PHY_ANALOG_TXRF1_PDLODIV2G_LSB                                                                       21
> #define PHY_ANALOG_TXRF1_PDLODIV2G_MASK                                                              0x00200000
> #define PHY_ANALOG_TXRF1_PDLODIV2G_GET(x)                                            (((x) & 0x00200000) >> 21)
> #define PHY_ANALOG_TXRF1_PDLODIV2G_SET(x)                                            (((x) << 21) & 0x00200000)
380,449c419,473
< #define PHY_ANALOG_TXRF2_SPARE2_MSB                                                                           0
< #define PHY_ANALOG_TXRF2_SPARE2_LSB                                                                           0
< #define PHY_ANALOG_TXRF2_SPARE2_MASK                                                                 0x00000001
< #define PHY_ANALOG_TXRF2_SPARE2_GET(x)                                                (((x) & 0x00000001) >> 0)
< #define PHY_ANALOG_TXRF2_SPARE2_SET(x)                                                (((x) << 0) & 0x00000001)
< #define PHY_ANALOG_TXRF2_D3B5G_MSB                                                                            3
< #define PHY_ANALOG_TXRF2_D3B5G_LSB                                                                            1
< #define PHY_ANALOG_TXRF2_D3B5G_MASK                                                                  0x0000000e
< #define PHY_ANALOG_TXRF2_D3B5G_GET(x)                                                 (((x) & 0x0000000e) >> 1)
< #define PHY_ANALOG_TXRF2_D3B5G_SET(x)                                                 (((x) << 1) & 0x0000000e)
< #define PHY_ANALOG_TXRF2_D4B5G_MSB                                                                            6
< #define PHY_ANALOG_TXRF2_D4B5G_LSB                                                                            4
< #define PHY_ANALOG_TXRF2_D4B5G_MASK                                                                  0x00000070
< #define PHY_ANALOG_TXRF2_D4B5G_GET(x)                                                 (((x) & 0x00000070) >> 4)
< #define PHY_ANALOG_TXRF2_D4B5G_SET(x)                                                 (((x) << 4) & 0x00000070)
< #define PHY_ANALOG_TXRF2_PDOUT5G_MSB                                                                         10
< #define PHY_ANALOG_TXRF2_PDOUT5G_LSB                                                                          7
< #define PHY_ANALOG_TXRF2_PDOUT5G_MASK                                                                0x00000780
< #define PHY_ANALOG_TXRF2_PDOUT5G_GET(x)                                               (((x) & 0x00000780) >> 7)
< #define PHY_ANALOG_TXRF2_PDOUT5G_SET(x)                                               (((x) << 7) & 0x00000780)
< #define PHY_ANALOG_TXRF2_PDMXR5G_MSB                                                                         11
< #define PHY_ANALOG_TXRF2_PDMXR5G_LSB                                                                         11
< #define PHY_ANALOG_TXRF2_PDMXR5G_MASK                                                                0x00000800
< #define PHY_ANALOG_TXRF2_PDMXR5G_GET(x)                                              (((x) & 0x00000800) >> 11)
< #define PHY_ANALOG_TXRF2_PDMXR5G_SET(x)                                              (((x) << 11) & 0x00000800)
< #define PHY_ANALOG_TXRF2_PDLOBUF5G_MSB                                                                       12
< #define PHY_ANALOG_TXRF2_PDLOBUF5G_LSB                                                                       12
< #define PHY_ANALOG_TXRF2_PDLOBUF5G_MASK                                                              0x00001000
< #define PHY_ANALOG_TXRF2_PDLOBUF5G_GET(x)                                            (((x) & 0x00001000) >> 12)
< #define PHY_ANALOG_TXRF2_PDLOBUF5G_SET(x)                                            (((x) << 12) & 0x00001000)
< #define PHY_ANALOG_TXRF2_PDLODIV5G_MSB                                                                       13
< #define PHY_ANALOG_TXRF2_PDLODIV5G_LSB                                                                       13
< #define PHY_ANALOG_TXRF2_PDLODIV5G_MASK                                                              0x00002000
< #define PHY_ANALOG_TXRF2_PDLODIV5G_GET(x)                                            (((x) & 0x00002000) >> 13)
< #define PHY_ANALOG_TXRF2_PDLODIV5G_SET(x)                                            (((x) << 13) & 0x00002000)
< #define PHY_ANALOG_TXRF2_LOBUF5GFORCED_MSB                                                                   14
< #define PHY_ANALOG_TXRF2_LOBUF5GFORCED_LSB                                                                   14
< #define PHY_ANALOG_TXRF2_LOBUF5GFORCED_MASK                                                          0x00004000
< #define PHY_ANALOG_TXRF2_LOBUF5GFORCED_GET(x)                                        (((x) & 0x00004000) >> 14)
< #define PHY_ANALOG_TXRF2_LOBUF5GFORCED_SET(x)                                        (((x) << 14) & 0x00004000)
< #define PHY_ANALOG_TXRF2_LODIV5GFORCED_MSB                                                                   15
< #define PHY_ANALOG_TXRF2_LODIV5GFORCED_LSB                                                                   15
< #define PHY_ANALOG_TXRF2_LODIV5GFORCED_MASK                                                          0x00008000
< #define PHY_ANALOG_TXRF2_LODIV5GFORCED_GET(x)                                        (((x) & 0x00008000) >> 15)
< #define PHY_ANALOG_TXRF2_LODIV5GFORCED_SET(x)                                        (((x) << 15) & 0x00008000)
< #define PHY_ANALOG_TXRF2_PADRV2GN5G_MSB                                                                      19
< #define PHY_ANALOG_TXRF2_PADRV2GN5G_LSB                                                                      16
< #define PHY_ANALOG_TXRF2_PADRV2GN5G_MASK                                                             0x000f0000
< #define PHY_ANALOG_TXRF2_PADRV2GN5G_GET(x)                                           (((x) & 0x000f0000) >> 16)
< #define PHY_ANALOG_TXRF2_PADRV2GN5G_SET(x)                                           (((x) << 16) & 0x000f0000)
< #define PHY_ANALOG_TXRF2_PADRV3GN5G_MSB                                                                      23
< #define PHY_ANALOG_TXRF2_PADRV3GN5G_LSB                                                                      20
< #define PHY_ANALOG_TXRF2_PADRV3GN5G_MASK                                                             0x00f00000
< #define PHY_ANALOG_TXRF2_PADRV3GN5G_GET(x)                                           (((x) & 0x00f00000) >> 20)
< #define PHY_ANALOG_TXRF2_PADRV3GN5G_SET(x)                                           (((x) << 20) & 0x00f00000)
< #define PHY_ANALOG_TXRF2_PADRV4GN5G_MSB                                                                      27
< #define PHY_ANALOG_TXRF2_PADRV4GN5G_LSB                                                                      24
< #define PHY_ANALOG_TXRF2_PADRV4GN5G_MASK                                                             0x0f000000
< #define PHY_ANALOG_TXRF2_PADRV4GN5G_GET(x)                                           (((x) & 0x0f000000) >> 24)
< #define PHY_ANALOG_TXRF2_PADRV4GN5G_SET(x)                                           (((x) << 24) & 0x0f000000)
< #define PHY_ANALOG_TXRF2_LOCALTXGAIN5G_MSB                                                                   28
< #define PHY_ANALOG_TXRF2_LOCALTXGAIN5G_LSB                                                                   28
< #define PHY_ANALOG_TXRF2_LOCALTXGAIN5G_MASK                                                          0x10000000
< #define PHY_ANALOG_TXRF2_LOCALTXGAIN5G_GET(x)                                        (((x) & 0x10000000) >> 28)
< #define PHY_ANALOG_TXRF2_LOCALTXGAIN5G_SET(x)                                        (((x) << 28) & 0x10000000)
< #define PHY_ANALOG_TXRF2_OCAS2G_MSB                                                                          31
< #define PHY_ANALOG_TXRF2_OCAS2G_LSB                                                                          29
< #define PHY_ANALOG_TXRF2_OCAS2G_MASK                                                                 0xe0000000
< #define PHY_ANALOG_TXRF2_OCAS2G_GET(x)                                               (((x) & 0xe0000000) >> 29)
< #define PHY_ANALOG_TXRF2_OCAS2G_SET(x)                                               (((x) << 29) & 0xe0000000)
---
> #define PHY_ANALOG_TXRF2_D3B5G_MSB                                                                            2
> #define PHY_ANALOG_TXRF2_D3B5G_LSB                                                                            0
> #define PHY_ANALOG_TXRF2_D3B5G_MASK                                                                  0x00000007
> #define PHY_ANALOG_TXRF2_D3B5G_GET(x)                                                 (((x) & 0x00000007) >> 0)
> #define PHY_ANALOG_TXRF2_D3B5G_SET(x)                                                 (((x) << 0) & 0x00000007)
> #define PHY_ANALOG_TXRF2_D4B5G_MSB                                                                            5
> #define PHY_ANALOG_TXRF2_D4B5G_LSB                                                                            3
> #define PHY_ANALOG_TXRF2_D4B5G_MASK                                                                  0x00000038
> #define PHY_ANALOG_TXRF2_D4B5G_GET(x)                                                 (((x) & 0x00000038) >> 3)
> #define PHY_ANALOG_TXRF2_D4B5G_SET(x)                                                 (((x) << 3) & 0x00000038)
> #define PHY_ANALOG_TXRF2_OCAS2G_MSB                                                                           8
> #define PHY_ANALOG_TXRF2_OCAS2G_LSB                                                                           6
> #define PHY_ANALOG_TXRF2_OCAS2G_MASK                                                                 0x000001c0
> #define PHY_ANALOG_TXRF2_OCAS2G_GET(x)                                                (((x) & 0x000001c0) >> 6)
> #define PHY_ANALOG_TXRF2_OCAS2G_SET(x)                                                (((x) << 6) & 0x000001c0)
> #define PHY_ANALOG_TXRF2_DCAS2G_MSB                                                                          11
> #define PHY_ANALOG_TXRF2_DCAS2G_LSB                                                                           9
> #define PHY_ANALOG_TXRF2_DCAS2G_MASK                                                                 0x00000e00
> #define PHY_ANALOG_TXRF2_DCAS2G_GET(x)                                                (((x) & 0x00000e00) >> 9)
> #define PHY_ANALOG_TXRF2_DCAS2G_SET(x)                                                (((x) << 9) & 0x00000e00)
> #define PHY_ANALOG_TXRF2_OB2G_PALOFF_MSB                                                                     14
> #define PHY_ANALOG_TXRF2_OB2G_PALOFF_LSB                                                                     12
> #define PHY_ANALOG_TXRF2_OB2G_PALOFF_MASK                                                            0x00007000
> #define PHY_ANALOG_TXRF2_OB2G_PALOFF_GET(x)                                          (((x) & 0x00007000) >> 12)
> #define PHY_ANALOG_TXRF2_OB2G_PALOFF_SET(x)                                          (((x) << 12) & 0x00007000)
> #define PHY_ANALOG_TXRF2_OB2G_QAM_MSB                                                                        17
> #define PHY_ANALOG_TXRF2_OB2G_QAM_LSB                                                                        15
> #define PHY_ANALOG_TXRF2_OB2G_QAM_MASK                                                               0x00038000
> #define PHY_ANALOG_TXRF2_OB2G_QAM_GET(x)                                             (((x) & 0x00038000) >> 15)
> #define PHY_ANALOG_TXRF2_OB2G_QAM_SET(x)                                             (((x) << 15) & 0x00038000)
> #define PHY_ANALOG_TXRF2_OB2G_PSK_MSB                                                                        20
> #define PHY_ANALOG_TXRF2_OB2G_PSK_LSB                                                                        18
> #define PHY_ANALOG_TXRF2_OB2G_PSK_MASK                                                               0x001c0000
> #define PHY_ANALOG_TXRF2_OB2G_PSK_GET(x)                                             (((x) & 0x001c0000) >> 18)
> #define PHY_ANALOG_TXRF2_OB2G_PSK_SET(x)                                             (((x) << 18) & 0x001c0000)
> #define PHY_ANALOG_TXRF2_OB2G_CCK_MSB                                                                        23
> #define PHY_ANALOG_TXRF2_OB2G_CCK_LSB                                                                        21
> #define PHY_ANALOG_TXRF2_OB2G_CCK_MASK                                                               0x00e00000
> #define PHY_ANALOG_TXRF2_OB2G_CCK_GET(x)                                             (((x) & 0x00e00000) >> 21)
> #define PHY_ANALOG_TXRF2_OB2G_CCK_SET(x)                                             (((x) << 21) & 0x00e00000)
> #define PHY_ANALOG_TXRF2_DB2G_MSB                                                                            26
> #define PHY_ANALOG_TXRF2_DB2G_LSB                                                                            24
> #define PHY_ANALOG_TXRF2_DB2G_MASK                                                                   0x07000000
> #define PHY_ANALOG_TXRF2_DB2G_GET(x)                                                 (((x) & 0x07000000) >> 24)
> #define PHY_ANALOG_TXRF2_DB2G_SET(x)                                                 (((x) << 24) & 0x07000000)
> #define PHY_ANALOG_TXRF2_PDOUT5G_MSB                                                                         30
> #define PHY_ANALOG_TXRF2_PDOUT5G_LSB                                                                         27
> #define PHY_ANALOG_TXRF2_PDOUT5G_MASK                                                                0x78000000
> #define PHY_ANALOG_TXRF2_PDOUT5G_GET(x)                                              (((x) & 0x78000000) >> 27)
> #define PHY_ANALOG_TXRF2_PDOUT5G_SET(x)                                              (((x) << 27) & 0x78000000)
> #define PHY_ANALOG_TXRF2_PDMXR5G_MSB                                                                         31
> #define PHY_ANALOG_TXRF2_PDMXR5G_LSB                                                                         31
> #define PHY_ANALOG_TXRF2_PDMXR5G_MASK                                                                0x80000000
> #define PHY_ANALOG_TXRF2_PDMXR5G_GET(x)                                              (((x) & 0x80000000) >> 31)
> #define PHY_ANALOG_TXRF2_PDMXR5G_SET(x)                                              (((x) << 31) & 0x80000000)
454,463c478,542
< #define PHY_ANALOG_TXRF3_SPARE3_MSB                                                                          22
< #define PHY_ANALOG_TXRF3_SPARE3_LSB                                                                           0
< #define PHY_ANALOG_TXRF3_SPARE3_MASK                                                                 0x007fffff
< #define PHY_ANALOG_TXRF3_SPARE3_GET(x)                                                (((x) & 0x007fffff) >> 0)
< #define PHY_ANALOG_TXRF3_SPARE3_SET(x)                                                (((x) << 0) & 0x007fffff)
< #define PHY_ANALOG_TXRF3_CAS5G_MSB                                                                           25
< #define PHY_ANALOG_TXRF3_CAS5G_LSB                                                                           23
< #define PHY_ANALOG_TXRF3_CAS5G_MASK                                                                  0x03800000
< #define PHY_ANALOG_TXRF3_CAS5G_GET(x)                                                (((x) & 0x03800000) >> 23)
< #define PHY_ANALOG_TXRF3_CAS5G_SET(x)                                                (((x) << 23) & 0x03800000)
---
> #define PHY_ANALOG_TXRF3_FILTR2G_MSB                                                                          1
> #define PHY_ANALOG_TXRF3_FILTR2G_LSB                                                                          0
> #define PHY_ANALOG_TXRF3_FILTR2G_MASK                                                                0x00000003
> #define PHY_ANALOG_TXRF3_FILTR2G_GET(x)                                               (((x) & 0x00000003) >> 0)
> #define PHY_ANALOG_TXRF3_FILTR2G_SET(x)                                               (((x) << 0) & 0x00000003)
> #define PHY_ANALOG_TXRF3_PWDFB2_2G_MSB                                                                        2
> #define PHY_ANALOG_TXRF3_PWDFB2_2G_LSB                                                                        2
> #define PHY_ANALOG_TXRF3_PWDFB2_2G_MASK                                                              0x00000004
> #define PHY_ANALOG_TXRF3_PWDFB2_2G_GET(x)                                             (((x) & 0x00000004) >> 2)
> #define PHY_ANALOG_TXRF3_PWDFB2_2G_SET(x)                                             (((x) << 2) & 0x00000004)
> #define PHY_ANALOG_TXRF3_PWDFB1_2G_MSB                                                                        3
> #define PHY_ANALOG_TXRF3_PWDFB1_2G_LSB                                                                        3
> #define PHY_ANALOG_TXRF3_PWDFB1_2G_MASK                                                              0x00000008
> #define PHY_ANALOG_TXRF3_PWDFB1_2G_GET(x)                                             (((x) & 0x00000008) >> 3)
> #define PHY_ANALOG_TXRF3_PWDFB1_2G_SET(x)                                             (((x) << 3) & 0x00000008)
> #define PHY_ANALOG_TXRF3_PDFB2G_MSB                                                                           4
> #define PHY_ANALOG_TXRF3_PDFB2G_LSB                                                                           4
> #define PHY_ANALOG_TXRF3_PDFB2G_MASK                                                                 0x00000010
> #define PHY_ANALOG_TXRF3_PDFB2G_GET(x)                                                (((x) & 0x00000010) >> 4)
> #define PHY_ANALOG_TXRF3_PDFB2G_SET(x)                                                (((x) << 4) & 0x00000010)
> #define PHY_ANALOG_TXRF3_RDIV5G_MSB                                                                           6
> #define PHY_ANALOG_TXRF3_RDIV5G_LSB                                                                           5
> #define PHY_ANALOG_TXRF3_RDIV5G_MASK                                                                 0x00000060
> #define PHY_ANALOG_TXRF3_RDIV5G_GET(x)                                                (((x) & 0x00000060) >> 5)
> #define PHY_ANALOG_TXRF3_RDIV5G_SET(x)                                                (((x) << 5) & 0x00000060)
> #define PHY_ANALOG_TXRF3_CAPDIV5G_MSB                                                                         9
> #define PHY_ANALOG_TXRF3_CAPDIV5G_LSB                                                                         7
> #define PHY_ANALOG_TXRF3_CAPDIV5G_MASK                                                               0x00000380
> #define PHY_ANALOG_TXRF3_CAPDIV5G_GET(x)                                              (((x) & 0x00000380) >> 7)
> #define PHY_ANALOG_TXRF3_CAPDIV5G_SET(x)                                              (((x) << 7) & 0x00000380)
> #define PHY_ANALOG_TXRF3_PDPREDIST5G_MSB                                                                     10
> #define PHY_ANALOG_TXRF3_PDPREDIST5G_LSB                                                                     10
> #define PHY_ANALOG_TXRF3_PDPREDIST5G_MASK                                                            0x00000400
> #define PHY_ANALOG_TXRF3_PDPREDIST5G_GET(x)                                          (((x) & 0x00000400) >> 10)
> #define PHY_ANALOG_TXRF3_PDPREDIST5G_SET(x)                                          (((x) << 10) & 0x00000400)
> #define PHY_ANALOG_TXRF3_RDIV2G_MSB                                                                          12
> #define PHY_ANALOG_TXRF3_RDIV2G_LSB                                                                          11
> #define PHY_ANALOG_TXRF3_RDIV2G_MASK                                                                 0x00001800
> #define PHY_ANALOG_TXRF3_RDIV2G_GET(x)                                               (((x) & 0x00001800) >> 11)
> #define PHY_ANALOG_TXRF3_RDIV2G_SET(x)                                               (((x) << 11) & 0x00001800)
> #define PHY_ANALOG_TXRF3_PDPREDIST2G_MSB                                                                     13
> #define PHY_ANALOG_TXRF3_PDPREDIST2G_LSB                                                                     13
> #define PHY_ANALOG_TXRF3_PDPREDIST2G_MASK                                                            0x00002000
> #define PHY_ANALOG_TXRF3_PDPREDIST2G_GET(x)                                          (((x) & 0x00002000) >> 13)
> #define PHY_ANALOG_TXRF3_PDPREDIST2G_SET(x)                                          (((x) << 13) & 0x00002000)
> #define PHY_ANALOG_TXRF3_OCAS5G_MSB                                                                          16
> #define PHY_ANALOG_TXRF3_OCAS5G_LSB                                                                          14
> #define PHY_ANALOG_TXRF3_OCAS5G_MASK                                                                 0x0001c000
> #define PHY_ANALOG_TXRF3_OCAS5G_GET(x)                                               (((x) & 0x0001c000) >> 14)
> #define PHY_ANALOG_TXRF3_OCAS5G_SET(x)                                               (((x) << 14) & 0x0001c000)
> #define PHY_ANALOG_TXRF3_D2CAS5G_MSB                                                                         19
> #define PHY_ANALOG_TXRF3_D2CAS5G_LSB                                                                         17
> #define PHY_ANALOG_TXRF3_D2CAS5G_MASK                                                                0x000e0000
> #define PHY_ANALOG_TXRF3_D2CAS5G_GET(x)                                              (((x) & 0x000e0000) >> 17)
> #define PHY_ANALOG_TXRF3_D2CAS5G_SET(x)                                              (((x) << 17) & 0x000e0000)
> #define PHY_ANALOG_TXRF3_D3CAS5G_MSB                                                                         22
> #define PHY_ANALOG_TXRF3_D3CAS5G_LSB                                                                         20
> #define PHY_ANALOG_TXRF3_D3CAS5G_MASK                                                                0x00700000
> #define PHY_ANALOG_TXRF3_D3CAS5G_GET(x)                                              (((x) & 0x00700000) >> 20)
> #define PHY_ANALOG_TXRF3_D3CAS5G_SET(x)                                              (((x) << 20) & 0x00700000)
> #define PHY_ANALOG_TXRF3_D4CAS5G_MSB                                                                         25
> #define PHY_ANALOG_TXRF3_D4CAS5G_LSB                                                                         23
> #define PHY_ANALOG_TXRF3_D4CAS5G_MASK                                                                0x03800000
> #define PHY_ANALOG_TXRF3_D4CAS5G_GET(x)                                              (((x) & 0x03800000) >> 23)
> #define PHY_ANALOG_TXRF3_D4CAS5G_SET(x)                                              (((x) << 23) & 0x03800000)
478,552c557,611
< #define PHY_ANALOG_TXRF4_COMP2G_PSK_MSB                                                                       2
< #define PHY_ANALOG_TXRF4_COMP2G_PSK_LSB                                                                       0
< #define PHY_ANALOG_TXRF4_COMP2G_PSK_MASK                                                             0x00000007
< #define PHY_ANALOG_TXRF4_COMP2G_PSK_GET(x)                                            (((x) & 0x00000007) >> 0)
< #define PHY_ANALOG_TXRF4_COMP2G_PSK_SET(x)                                            (((x) << 0) & 0x00000007)
< #define PHY_ANALOG_TXRF4_COMP2G_CCK_MSB                                                                       5
< #define PHY_ANALOG_TXRF4_COMP2G_CCK_LSB                                                                       3
< #define PHY_ANALOG_TXRF4_COMP2G_CCK_MASK                                                             0x00000038
< #define PHY_ANALOG_TXRF4_COMP2G_CCK_GET(x)                                            (((x) & 0x00000038) >> 3)
< #define PHY_ANALOG_TXRF4_COMP2G_CCK_SET(x)                                            (((x) << 3) & 0x00000038)
< #define PHY_ANALOG_TXRF4_AMP2B2G_QAM_MSB                                                                      8
< #define PHY_ANALOG_TXRF4_AMP2B2G_QAM_LSB                                                                      6
< #define PHY_ANALOG_TXRF4_AMP2B2G_QAM_MASK                                                            0x000001c0
< #define PHY_ANALOG_TXRF4_AMP2B2G_QAM_GET(x)                                           (((x) & 0x000001c0) >> 6)
< #define PHY_ANALOG_TXRF4_AMP2B2G_QAM_SET(x)                                           (((x) << 6) & 0x000001c0)
< #define PHY_ANALOG_TXRF4_AMP2B2G_PSK_MSB                                                                     11
< #define PHY_ANALOG_TXRF4_AMP2B2G_PSK_LSB                                                                      9
< #define PHY_ANALOG_TXRF4_AMP2B2G_PSK_MASK                                                            0x00000e00
< #define PHY_ANALOG_TXRF4_AMP2B2G_PSK_GET(x)                                           (((x) & 0x00000e00) >> 9)
< #define PHY_ANALOG_TXRF4_AMP2B2G_PSK_SET(x)                                           (((x) << 9) & 0x00000e00)
< #define PHY_ANALOG_TXRF4_AMP2B2G_CCK_MSB                                                                     14
< #define PHY_ANALOG_TXRF4_AMP2B2G_CCK_LSB                                                                     12
< #define PHY_ANALOG_TXRF4_AMP2B2G_CCK_MASK                                                            0x00007000
< #define PHY_ANALOG_TXRF4_AMP2B2G_CCK_GET(x)                                          (((x) & 0x00007000) >> 12)
< #define PHY_ANALOG_TXRF4_AMP2B2G_CCK_SET(x)                                          (((x) << 12) & 0x00007000)
< #define PHY_ANALOG_TXRF4_AMP2CAS2G_MSB                                                                       17
< #define PHY_ANALOG_TXRF4_AMP2CAS2G_LSB                                                                       15
< #define PHY_ANALOG_TXRF4_AMP2CAS2G_MASK                                                              0x00038000
< #define PHY_ANALOG_TXRF4_AMP2CAS2G_GET(x)                                            (((x) & 0x00038000) >> 15)
< #define PHY_ANALOG_TXRF4_AMP2CAS2G_SET(x)                                            (((x) << 15) & 0x00038000)
< #define PHY_ANALOG_TXRF4_FILTR2G_MSB                                                                         19
< #define PHY_ANALOG_TXRF4_FILTR2G_LSB                                                                         18
< #define PHY_ANALOG_TXRF4_FILTR2G_MASK                                                                0x000c0000
< #define PHY_ANALOG_TXRF4_FILTR2G_GET(x)                                              (((x) & 0x000c0000) >> 18)
< #define PHY_ANALOG_TXRF4_FILTR2G_SET(x)                                              (((x) << 18) & 0x000c0000)
< #define PHY_ANALOG_TXRF4_PWDFB2_2G_MSB                                                                       20
< #define PHY_ANALOG_TXRF4_PWDFB2_2G_LSB                                                                       20
< #define PHY_ANALOG_TXRF4_PWDFB2_2G_MASK                                                              0x00100000
< #define PHY_ANALOG_TXRF4_PWDFB2_2G_GET(x)                                            (((x) & 0x00100000) >> 20)
< #define PHY_ANALOG_TXRF4_PWDFB2_2G_SET(x)                                            (((x) << 20) & 0x00100000)
< #define PHY_ANALOG_TXRF4_PWDFB1_2G_MSB                                                                       21
< #define PHY_ANALOG_TXRF4_PWDFB1_2G_LSB                                                                       21
< #define PHY_ANALOG_TXRF4_PWDFB1_2G_MASK                                                              0x00200000
< #define PHY_ANALOG_TXRF4_PWDFB1_2G_GET(x)                                            (((x) & 0x00200000) >> 21)
< #define PHY_ANALOG_TXRF4_PWDFB1_2G_SET(x)                                            (((x) << 21) & 0x00200000)
< #define PHY_ANALOG_TXRF4_PDFB2G_MSB                                                                          22
< #define PHY_ANALOG_TXRF4_PDFB2G_LSB                                                                          22
< #define PHY_ANALOG_TXRF4_PDFB2G_MASK                                                                 0x00400000
< #define PHY_ANALOG_TXRF4_PDFB2G_GET(x)                                               (((x) & 0x00400000) >> 22)
< #define PHY_ANALOG_TXRF4_PDFB2G_SET(x)                                               (((x) << 22) & 0x00400000)
< #define PHY_ANALOG_TXRF4_RDIV5G_MSB                                                                          24
< #define PHY_ANALOG_TXRF4_RDIV5G_LSB                                                                          23
< #define PHY_ANALOG_TXRF4_RDIV5G_MASK                                                                 0x01800000
< #define PHY_ANALOG_TXRF4_RDIV5G_GET(x)                                               (((x) & 0x01800000) >> 23)
< #define PHY_ANALOG_TXRF4_RDIV5G_SET(x)                                               (((x) << 23) & 0x01800000)
< #define PHY_ANALOG_TXRF4_CAPDIV5G_MSB                                                                        27
< #define PHY_ANALOG_TXRF4_CAPDIV5G_LSB                                                                        25
< #define PHY_ANALOG_TXRF4_CAPDIV5G_MASK                                                               0x0e000000
< #define PHY_ANALOG_TXRF4_CAPDIV5G_GET(x)                                             (((x) & 0x0e000000) >> 25)
< #define PHY_ANALOG_TXRF4_CAPDIV5G_SET(x)                                             (((x) << 25) & 0x0e000000)
< #define PHY_ANALOG_TXRF4_PDPREDIST5G_MSB                                                                     28
< #define PHY_ANALOG_TXRF4_PDPREDIST5G_LSB                                                                     28
< #define PHY_ANALOG_TXRF4_PDPREDIST5G_MASK                                                            0x10000000
< #define PHY_ANALOG_TXRF4_PDPREDIST5G_GET(x)                                          (((x) & 0x10000000) >> 28)
< #define PHY_ANALOG_TXRF4_PDPREDIST5G_SET(x)                                          (((x) << 28) & 0x10000000)
< #define PHY_ANALOG_TXRF4_RDIV2G_MSB                                                                          30
< #define PHY_ANALOG_TXRF4_RDIV2G_LSB                                                                          29
< #define PHY_ANALOG_TXRF4_RDIV2G_MASK                                                                 0x60000000
< #define PHY_ANALOG_TXRF4_RDIV2G_GET(x)                                               (((x) & 0x60000000) >> 29)
< #define PHY_ANALOG_TXRF4_RDIV2G_SET(x)                                               (((x) << 29) & 0x60000000)
< #define PHY_ANALOG_TXRF4_PDPREDIST2G_MSB                                                                     31
< #define PHY_ANALOG_TXRF4_PDPREDIST2G_LSB                                                                     31
< #define PHY_ANALOG_TXRF4_PDPREDIST2G_MASK                                                            0x80000000
< #define PHY_ANALOG_TXRF4_PDPREDIST2G_GET(x)                                          (((x) & 0x80000000) >> 31)
< #define PHY_ANALOG_TXRF4_PDPREDIST2G_SET(x)                                          (((x) << 31) & 0x80000000)
---
> #define PHY_ANALOG_TXRF4_PK1B2G_CCK_MSB                                                                       1
> #define PHY_ANALOG_TXRF4_PK1B2G_CCK_LSB                                                                       0
> #define PHY_ANALOG_TXRF4_PK1B2G_CCK_MASK                                                             0x00000003
> #define PHY_ANALOG_TXRF4_PK1B2G_CCK_GET(x)                                            (((x) & 0x00000003) >> 0)
> #define PHY_ANALOG_TXRF4_PK1B2G_CCK_SET(x)                                            (((x) << 0) & 0x00000003)
> #define PHY_ANALOG_TXRF4_MIOB2G_QAM_MSB                                                                       4
> #define PHY_ANALOG_TXRF4_MIOB2G_QAM_LSB                                                                       2
> #define PHY_ANALOG_TXRF4_MIOB2G_QAM_MASK                                                             0x0000001c
> #define PHY_ANALOG_TXRF4_MIOB2G_QAM_GET(x)                                            (((x) & 0x0000001c) >> 2)
> #define PHY_ANALOG_TXRF4_MIOB2G_QAM_SET(x)                                            (((x) << 2) & 0x0000001c)
> #define PHY_ANALOG_TXRF4_MIOB2G_PSK_MSB                                                                       7
> #define PHY_ANALOG_TXRF4_MIOB2G_PSK_LSB                                                                       5
> #define PHY_ANALOG_TXRF4_MIOB2G_PSK_MASK                                                             0x000000e0
> #define PHY_ANALOG_TXRF4_MIOB2G_PSK_GET(x)                                            (((x) & 0x000000e0) >> 5)
> #define PHY_ANALOG_TXRF4_MIOB2G_PSK_SET(x)                                            (((x) << 5) & 0x000000e0)
> #define PHY_ANALOG_TXRF4_MIOB2G_CCK_MSB                                                                      10
> #define PHY_ANALOG_TXRF4_MIOB2G_CCK_LSB                                                                       8
> #define PHY_ANALOG_TXRF4_MIOB2G_CCK_MASK                                                             0x00000700
> #define PHY_ANALOG_TXRF4_MIOB2G_CCK_GET(x)                                            (((x) & 0x00000700) >> 8)
> #define PHY_ANALOG_TXRF4_MIOB2G_CCK_SET(x)                                            (((x) << 8) & 0x00000700)
> #define PHY_ANALOG_TXRF4_COMP2G_QAM_MSB                                                                      13
> #define PHY_ANALOG_TXRF4_COMP2G_QAM_LSB                                                                      11
> #define PHY_ANALOG_TXRF4_COMP2G_QAM_MASK                                                             0x00003800
> #define PHY_ANALOG_TXRF4_COMP2G_QAM_GET(x)                                           (((x) & 0x00003800) >> 11)
> #define PHY_ANALOG_TXRF4_COMP2G_QAM_SET(x)                                           (((x) << 11) & 0x00003800)
> #define PHY_ANALOG_TXRF4_COMP2G_PSK_MSB                                                                      16
> #define PHY_ANALOG_TXRF4_COMP2G_PSK_LSB                                                                      14
> #define PHY_ANALOG_TXRF4_COMP2G_PSK_MASK                                                             0x0001c000
> #define PHY_ANALOG_TXRF4_COMP2G_PSK_GET(x)                                           (((x) & 0x0001c000) >> 14)
> #define PHY_ANALOG_TXRF4_COMP2G_PSK_SET(x)                                           (((x) << 14) & 0x0001c000)
> #define PHY_ANALOG_TXRF4_COMP2G_CCK_MSB                                                                      19
> #define PHY_ANALOG_TXRF4_COMP2G_CCK_LSB                                                                      17
> #define PHY_ANALOG_TXRF4_COMP2G_CCK_MASK                                                             0x000e0000
> #define PHY_ANALOG_TXRF4_COMP2G_CCK_GET(x)                                           (((x) & 0x000e0000) >> 17)
> #define PHY_ANALOG_TXRF4_COMP2G_CCK_SET(x)                                           (((x) << 17) & 0x000e0000)
> #define PHY_ANALOG_TXRF4_AMP2B2G_QAM_MSB                                                                     22
> #define PHY_ANALOG_TXRF4_AMP2B2G_QAM_LSB                                                                     20
> #define PHY_ANALOG_TXRF4_AMP2B2G_QAM_MASK                                                            0x00700000
> #define PHY_ANALOG_TXRF4_AMP2B2G_QAM_GET(x)                                          (((x) & 0x00700000) >> 20)
> #define PHY_ANALOG_TXRF4_AMP2B2G_QAM_SET(x)                                          (((x) << 20) & 0x00700000)
> #define PHY_ANALOG_TXRF4_AMP2B2G_PSK_MSB                                                                     25
> #define PHY_ANALOG_TXRF4_AMP2B2G_PSK_LSB                                                                     23
> #define PHY_ANALOG_TXRF4_AMP2B2G_PSK_MASK                                                            0x03800000
> #define PHY_ANALOG_TXRF4_AMP2B2G_PSK_GET(x)                                          (((x) & 0x03800000) >> 23)
> #define PHY_ANALOG_TXRF4_AMP2B2G_PSK_SET(x)                                          (((x) << 23) & 0x03800000)
> #define PHY_ANALOG_TXRF4_AMP2B2G_CCK_MSB                                                                     28
> #define PHY_ANALOG_TXRF4_AMP2B2G_CCK_LSB                                                                     26
> #define PHY_ANALOG_TXRF4_AMP2B2G_CCK_MASK                                                            0x1c000000
> #define PHY_ANALOG_TXRF4_AMP2B2G_CCK_GET(x)                                          (((x) & 0x1c000000) >> 26)
> #define PHY_ANALOG_TXRF4_AMP2B2G_CCK_SET(x)                                          (((x) << 26) & 0x1c000000)
> #define PHY_ANALOG_TXRF4_AMP2CAS2G_MSB                                                                       31
> #define PHY_ANALOG_TXRF4_AMP2CAS2G_LSB                                                                       29
> #define PHY_ANALOG_TXRF4_AMP2CAS2G_MASK                                                              0xe0000000
> #define PHY_ANALOG_TXRF4_AMP2CAS2G_GET(x)                                            (((x) & 0xe0000000) >> 29)
> #define PHY_ANALOG_TXRF4_AMP2CAS2G_SET(x)                                            (((x) << 29) & 0xe0000000)
557,624c616,692
< #define PHY_ANALOG_TXRF5_FBHI2G_MSB                                                                           0
< #define PHY_ANALOG_TXRF5_FBHI2G_LSB                                                                           0
< #define PHY_ANALOG_TXRF5_FBHI2G_MASK                                                                 0x00000001
< #define PHY_ANALOG_TXRF5_FBHI2G_GET(x)                                                (((x) & 0x00000001) >> 0)
< #define PHY_ANALOG_TXRF5_FBLO2G_MSB                                                                           1
< #define PHY_ANALOG_TXRF5_FBLO2G_LSB                                                                           1
< #define PHY_ANALOG_TXRF5_FBLO2G_MASK                                                                 0x00000002
< #define PHY_ANALOG_TXRF5_FBLO2G_GET(x)                                                (((x) & 0x00000002) >> 1)
< #define PHY_ANALOG_TXRF5_REFHI2G_MSB                                                                          4
< #define PHY_ANALOG_TXRF5_REFHI2G_LSB                                                                          2
< #define PHY_ANALOG_TXRF5_REFHI2G_MASK                                                                0x0000001c
< #define PHY_ANALOG_TXRF5_REFHI2G_GET(x)                                               (((x) & 0x0000001c) >> 2)
< #define PHY_ANALOG_TXRF5_REFHI2G_SET(x)                                               (((x) << 2) & 0x0000001c)
< #define PHY_ANALOG_TXRF5_REFLO2G_MSB                                                                          7
< #define PHY_ANALOG_TXRF5_REFLO2G_LSB                                                                          5
< #define PHY_ANALOG_TXRF5_REFLO2G_MASK                                                                0x000000e0
< #define PHY_ANALOG_TXRF5_REFLO2G_GET(x)                                               (((x) & 0x000000e0) >> 5)
< #define PHY_ANALOG_TXRF5_REFLO2G_SET(x)                                               (((x) << 5) & 0x000000e0)
< #define PHY_ANALOG_TXRF5_PK2B2G_QAM_MSB                                                                       9
< #define PHY_ANALOG_TXRF5_PK2B2G_QAM_LSB                                                                       8
< #define PHY_ANALOG_TXRF5_PK2B2G_QAM_MASK                                                             0x00000300
< #define PHY_ANALOG_TXRF5_PK2B2G_QAM_GET(x)                                            (((x) & 0x00000300) >> 8)
< #define PHY_ANALOG_TXRF5_PK2B2G_QAM_SET(x)                                            (((x) << 8) & 0x00000300)
< #define PHY_ANALOG_TXRF5_PK2B2G_PSK_MSB                                                                      11
< #define PHY_ANALOG_TXRF5_PK2B2G_PSK_LSB                                                                      10
< #define PHY_ANALOG_TXRF5_PK2B2G_PSK_MASK                                                             0x00000c00
< #define PHY_ANALOG_TXRF5_PK2B2G_PSK_GET(x)                                           (((x) & 0x00000c00) >> 10)
< #define PHY_ANALOG_TXRF5_PK2B2G_PSK_SET(x)                                           (((x) << 10) & 0x00000c00)
< #define PHY_ANALOG_TXRF5_PK2B2G_CCK_MSB                                                                      13
< #define PHY_ANALOG_TXRF5_PK2B2G_CCK_LSB                                                                      12
< #define PHY_ANALOG_TXRF5_PK2B2G_CCK_MASK                                                             0x00003000
< #define PHY_ANALOG_TXRF5_PK2B2G_CCK_GET(x)                                           (((x) & 0x00003000) >> 12)
< #define PHY_ANALOG_TXRF5_PK2B2G_CCK_SET(x)                                           (((x) << 12) & 0x00003000)
< #define PHY_ANALOG_TXRF5_PK1B2G_QAM_MSB                                                                      15
< #define PHY_ANALOG_TXRF5_PK1B2G_QAM_LSB                                                                      14
< #define PHY_ANALOG_TXRF5_PK1B2G_QAM_MASK                                                             0x0000c000
< #define PHY_ANALOG_TXRF5_PK1B2G_QAM_GET(x)                                           (((x) & 0x0000c000) >> 14)
< #define PHY_ANALOG_TXRF5_PK1B2G_QAM_SET(x)                                           (((x) << 14) & 0x0000c000)
< #define PHY_ANALOG_TXRF5_PK1B2G_PSK_MSB                                                                      17
< #define PHY_ANALOG_TXRF5_PK1B2G_PSK_LSB                                                                      16
< #define PHY_ANALOG_TXRF5_PK1B2G_PSK_MASK                                                             0x00030000
< #define PHY_ANALOG_TXRF5_PK1B2G_PSK_GET(x)                                           (((x) & 0x00030000) >> 16)
< #define PHY_ANALOG_TXRF5_PK1B2G_PSK_SET(x)                                           (((x) << 16) & 0x00030000)
< #define PHY_ANALOG_TXRF5_PK1B2G_CCK_MSB                                                                      19
< #define PHY_ANALOG_TXRF5_PK1B2G_CCK_LSB                                                                      18
< #define PHY_ANALOG_TXRF5_PK1B2G_CCK_MASK                                                             0x000c0000
< #define PHY_ANALOG_TXRF5_PK1B2G_CCK_GET(x)                                           (((x) & 0x000c0000) >> 18)
< #define PHY_ANALOG_TXRF5_PK1B2G_CCK_SET(x)                                           (((x) << 18) & 0x000c0000)
< #define PHY_ANALOG_TXRF5_MIOB2G_QAM_MSB                                                                      22
< #define PHY_ANALOG_TXRF5_MIOB2G_QAM_LSB                                                                      20
< #define PHY_ANALOG_TXRF5_MIOB2G_QAM_MASK                                                             0x00700000
< #define PHY_ANALOG_TXRF5_MIOB2G_QAM_GET(x)                                           (((x) & 0x00700000) >> 20)
< #define PHY_ANALOG_TXRF5_MIOB2G_QAM_SET(x)                                           (((x) << 20) & 0x00700000)
< #define PHY_ANALOG_TXRF5_MIOB2G_PSK_MSB                                                                      25
< #define PHY_ANALOG_TXRF5_MIOB2G_PSK_LSB                                                                      23
< #define PHY_ANALOG_TXRF5_MIOB2G_PSK_MASK                                                             0x03800000
< #define PHY_ANALOG_TXRF5_MIOB2G_PSK_GET(x)                                           (((x) & 0x03800000) >> 23)
< #define PHY_ANALOG_TXRF5_MIOB2G_PSK_SET(x)                                           (((x) << 23) & 0x03800000)
< #define PHY_ANALOG_TXRF5_MIOB2G_CCK_MSB                                                                      28
< #define PHY_ANALOG_TXRF5_MIOB2G_CCK_LSB                                                                      26
< #define PHY_ANALOG_TXRF5_MIOB2G_CCK_MASK                                                             0x1c000000
< #define PHY_ANALOG_TXRF5_MIOB2G_CCK_GET(x)                                           (((x) & 0x1c000000) >> 26)
< #define PHY_ANALOG_TXRF5_MIOB2G_CCK_SET(x)                                           (((x) << 26) & 0x1c000000)
< #define PHY_ANALOG_TXRF5_COMP2G_QAM_MSB                                                                      31
< #define PHY_ANALOG_TXRF5_COMP2G_QAM_LSB                                                                      29
< #define PHY_ANALOG_TXRF5_COMP2G_QAM_MASK                                                             0xe0000000
< #define PHY_ANALOG_TXRF5_COMP2G_QAM_GET(x)                                           (((x) & 0xe0000000) >> 29)
< #define PHY_ANALOG_TXRF5_COMP2G_QAM_SET(x)                                           (((x) << 29) & 0xe0000000)
---
> #define PHY_ANALOG_TXRF5_SPARE5_MSB                                                                           0
> #define PHY_ANALOG_TXRF5_SPARE5_LSB                                                                           0
> #define PHY_ANALOG_TXRF5_SPARE5_MASK                                                                 0x00000001
> #define PHY_ANALOG_TXRF5_SPARE5_GET(x)                                                (((x) & 0x00000001) >> 0)
> #define PHY_ANALOG_TXRF5_SPARE5_SET(x)                                                (((x) << 0) & 0x00000001)
> #define PHY_ANALOG_TXRF5_PAL_LOCKED_MSB                                                                       1
> #define PHY_ANALOG_TXRF5_PAL_LOCKED_LSB                                                                       1
> #define PHY_ANALOG_TXRF5_PAL_LOCKED_MASK                                                             0x00000002
> #define PHY_ANALOG_TXRF5_PAL_LOCKED_GET(x)                                            (((x) & 0x00000002) >> 1)
> #define PHY_ANALOG_TXRF5_FBHI2G_MSB                                                                           2
> #define PHY_ANALOG_TXRF5_FBHI2G_LSB                                                                           2
> #define PHY_ANALOG_TXRF5_FBHI2G_MASK                                                                 0x00000004
> #define PHY_ANALOG_TXRF5_FBHI2G_GET(x)                                                (((x) & 0x00000004) >> 2)
> #define PHY_ANALOG_TXRF5_FBLO2G_MSB                                                                           3
> #define PHY_ANALOG_TXRF5_FBLO2G_LSB                                                                           3
> #define PHY_ANALOG_TXRF5_FBLO2G_MASK                                                                 0x00000008
> #define PHY_ANALOG_TXRF5_FBLO2G_GET(x)                                                (((x) & 0x00000008) >> 3)
> #define PHY_ANALOG_TXRF5_NOPALGAIN2G_MSB                                                                      4
> #define PHY_ANALOG_TXRF5_NOPALGAIN2G_LSB                                                                      4
> #define PHY_ANALOG_TXRF5_NOPALGAIN2G_MASK                                                            0x00000010
> #define PHY_ANALOG_TXRF5_NOPALGAIN2G_GET(x)                                           (((x) & 0x00000010) >> 4)
> #define PHY_ANALOG_TXRF5_NOPALGAIN2G_SET(x)                                           (((x) << 4) & 0x00000010)
> #define PHY_ANALOG_TXRF5_ENPACAL2G_MSB                                                                        5
> #define PHY_ANALOG_TXRF5_ENPACAL2G_LSB                                                                        5
> #define PHY_ANALOG_TXRF5_ENPACAL2G_MASK                                                              0x00000020
> #define PHY_ANALOG_TXRF5_ENPACAL2G_GET(x)                                             (((x) & 0x00000020) >> 5)
> #define PHY_ANALOG_TXRF5_ENPACAL2G_SET(x)                                             (((x) << 5) & 0x00000020)
> #define PHY_ANALOG_TXRF5_OFFSET2G_MSB                                                                        12
> #define PHY_ANALOG_TXRF5_OFFSET2G_LSB                                                                         6
> #define PHY_ANALOG_TXRF5_OFFSET2G_MASK                                                               0x00001fc0
> #define PHY_ANALOG_TXRF5_OFFSET2G_GET(x)                                              (((x) & 0x00001fc0) >> 6)
> #define PHY_ANALOG_TXRF5_OFFSET2G_SET(x)                                              (((x) << 6) & 0x00001fc0)
> #define PHY_ANALOG_TXRF5_ENOFFSETCAL2G_MSB                                                                   13
> #define PHY_ANALOG_TXRF5_ENOFFSETCAL2G_LSB                                                                   13
> #define PHY_ANALOG_TXRF5_ENOFFSETCAL2G_MASK                                                          0x00002000
> #define PHY_ANALOG_TXRF5_ENOFFSETCAL2G_GET(x)                                        (((x) & 0x00002000) >> 13)
> #define PHY_ANALOG_TXRF5_ENOFFSETCAL2G_SET(x)                                        (((x) << 13) & 0x00002000)
> #define PHY_ANALOG_TXRF5_REFHI2G_MSB                                                                         16
> #define PHY_ANALOG_TXRF5_REFHI2G_LSB                                                                         14
> #define PHY_ANALOG_TXRF5_REFHI2G_MASK                                                                0x0001c000
> #define PHY_ANALOG_TXRF5_REFHI2G_GET(x)                                              (((x) & 0x0001c000) >> 14)
> #define PHY_ANALOG_TXRF5_REFHI2G_SET(x)                                              (((x) << 14) & 0x0001c000)
> #define PHY_ANALOG_TXRF5_REFLO2G_MSB                                                                         19
> #define PHY_ANALOG_TXRF5_REFLO2G_LSB                                                                         17
> #define PHY_ANALOG_TXRF5_REFLO2G_MASK                                                                0x000e0000
> #define PHY_ANALOG_TXRF5_REFLO2G_GET(x)                                              (((x) & 0x000e0000) >> 17)
> #define PHY_ANALOG_TXRF5_REFLO2G_SET(x)                                              (((x) << 17) & 0x000e0000)
> #define PHY_ANALOG_TXRF5_PALCLAMP2G_MSB                                                                      21
> #define PHY_ANALOG_TXRF5_PALCLAMP2G_LSB                                                                      20
> #define PHY_ANALOG_TXRF5_PALCLAMP2G_MASK                                                             0x00300000
> #define PHY_ANALOG_TXRF5_PALCLAMP2G_GET(x)                                           (((x) & 0x00300000) >> 20)
> #define PHY_ANALOG_TXRF5_PALCLAMP2G_SET(x)                                           (((x) << 20) & 0x00300000)
> #define PHY_ANALOG_TXRF5_PK2B2G_QAM_MSB                                                                      23
> #define PHY_ANALOG_TXRF5_PK2B2G_QAM_LSB                                                                      22
> #define PHY_ANALOG_TXRF5_PK2B2G_QAM_MASK                                                             0x00c00000
> #define PHY_ANALOG_TXRF5_PK2B2G_QAM_GET(x)                                           (((x) & 0x00c00000) >> 22)
> #define PHY_ANALOG_TXRF5_PK2B2G_QAM_SET(x)                                           (((x) << 22) & 0x00c00000)
> #define PHY_ANALOG_TXRF5_PK2B2G_PSK_MSB                                                                      25
> #define PHY_ANALOG_TXRF5_PK2B2G_PSK_LSB                                                                      24
> #define PHY_ANALOG_TXRF5_PK2B2G_PSK_MASK                                                             0x03000000
> #define PHY_ANALOG_TXRF5_PK2B2G_PSK_GET(x)                                           (((x) & 0x03000000) >> 24)
> #define PHY_ANALOG_TXRF5_PK2B2G_PSK_SET(x)                                           (((x) << 24) & 0x03000000)
> #define PHY_ANALOG_TXRF5_PK2B2G_CCK_MSB                                                                      27
> #define PHY_ANALOG_TXRF5_PK2B2G_CCK_LSB                                                                      26
> #define PHY_ANALOG_TXRF5_PK2B2G_CCK_MASK                                                             0x0c000000
> #define PHY_ANALOG_TXRF5_PK2B2G_CCK_GET(x)                                           (((x) & 0x0c000000) >> 26)
> #define PHY_ANALOG_TXRF5_PK2B2G_CCK_SET(x)                                           (((x) << 26) & 0x0c000000)
> #define PHY_ANALOG_TXRF5_PK1B2G_QAM_MSB                                                                      29
> #define PHY_ANALOG_TXRF5_PK1B2G_QAM_LSB                                                                      28
> #define PHY_ANALOG_TXRF5_PK1B2G_QAM_MASK                                                             0x30000000
> #define PHY_ANALOG_TXRF5_PK1B2G_QAM_GET(x)                                           (((x) & 0x30000000) >> 28)
> #define PHY_ANALOG_TXRF5_PK1B2G_QAM_SET(x)                                           (((x) << 28) & 0x30000000)
> #define PHY_ANALOG_TXRF5_PK1B2G_PSK_MSB                                                                      31
> #define PHY_ANALOG_TXRF5_PK1B2G_PSK_LSB                                                                      30
> #define PHY_ANALOG_TXRF5_PK1B2G_PSK_MASK                                                             0xc0000000
> #define PHY_ANALOG_TXRF5_PK1B2G_PSK_GET(x)                                           (((x) & 0xc0000000) >> 30)
> #define PHY_ANALOG_TXRF5_PK1B2G_PSK_SET(x)                                           (((x) << 30) & 0xc0000000)
629,686c697,751
< #define PHY_ANALOG_TXRF6_SPARE6_MSB                                                                           0
< #define PHY_ANALOG_TXRF6_SPARE6_LSB                                                                           0
< #define PHY_ANALOG_TXRF6_SPARE6_MASK                                                                 0x00000001
< #define PHY_ANALOG_TXRF6_SPARE6_GET(x)                                                (((x) & 0x00000001) >> 0)
< #define PHY_ANALOG_TXRF6_SPARE6_SET(x)                                                (((x) << 0) & 0x00000001)
< #define PHY_ANALOG_TXRF6_PAL_LOCKED_MSB                                                                       1
< #define PHY_ANALOG_TXRF6_PAL_LOCKED_LSB                                                                       1
< #define PHY_ANALOG_TXRF6_PAL_LOCKED_MASK                                                             0x00000002
< #define PHY_ANALOG_TXRF6_PAL_LOCKED_GET(x)                                            (((x) & 0x00000002) >> 1)
< #define PHY_ANALOG_TXRF6_PADRVGN2G_SMOUT_MSB                                                                  7
< #define PHY_ANALOG_TXRF6_PADRVGN2G_SMOUT_LSB                                                                  2
< #define PHY_ANALOG_TXRF6_PADRVGN2G_SMOUT_MASK                                                        0x000000fc
< #define PHY_ANALOG_TXRF6_PADRVGN2G_SMOUT_GET(x)                                       (((x) & 0x000000fc) >> 2)
< #define PHY_ANALOG_TXRF6_GAINSTEP2G_MSB                                                                      10
< #define PHY_ANALOG_TXRF6_GAINSTEP2G_LSB                                                                       8
< #define PHY_ANALOG_TXRF6_GAINSTEP2G_MASK                                                             0x00000700
< #define PHY_ANALOG_TXRF6_GAINSTEP2G_GET(x)                                            (((x) & 0x00000700) >> 8)
< #define PHY_ANALOG_TXRF6_GAINSTEP2G_SET(x)                                            (((x) << 8) & 0x00000700)
< #define PHY_ANALOG_TXRF6_USE_GAIN_DELTA2G_MSB                                                                11
< #define PHY_ANALOG_TXRF6_USE_GAIN_DELTA2G_LSB                                                                11
< #define PHY_ANALOG_TXRF6_USE_GAIN_DELTA2G_MASK                                                       0x00000800
< #define PHY_ANALOG_TXRF6_USE_GAIN_DELTA2G_GET(x)                                     (((x) & 0x00000800) >> 11)
< #define PHY_ANALOG_TXRF6_USE_GAIN_DELTA2G_SET(x)                                     (((x) << 11) & 0x00000800)
< #define PHY_ANALOG_TXRF6_PADRVGN_INDEX_I2G_MSB                                                               15
< #define PHY_ANALOG_TXRF6_PADRVGN_INDEX_I2G_LSB                                                               12
< #define PHY_ANALOG_TXRF6_PADRVGN_INDEX_I2G_MASK                                                      0x0000f000
< #define PHY_ANALOG_TXRF6_PADRVGN_INDEX_I2G_GET(x)                                    (((x) & 0x0000f000) >> 12)
< #define PHY_ANALOG_TXRF6_PADRVGN_INDEX_I2G_SET(x)                                    (((x) << 12) & 0x0000f000)
< #define PHY_ANALOG_TXRF6_VCMONDELAY2G_MSB                                                                    18
< #define PHY_ANALOG_TXRF6_VCMONDELAY2G_LSB                                                                    16
< #define PHY_ANALOG_TXRF6_VCMONDELAY2G_MASK                                                           0x00070000
< #define PHY_ANALOG_TXRF6_VCMONDELAY2G_GET(x)                                         (((x) & 0x00070000) >> 16)
< #define PHY_ANALOG_TXRF6_VCMONDELAY2G_SET(x)                                         (((x) << 16) & 0x00070000)
< #define PHY_ANALOG_TXRF6_CAPDIV2G_MSB                                                                        21
< #define PHY_ANALOG_TXRF6_CAPDIV2G_LSB                                                                        19
< #define PHY_ANALOG_TXRF6_CAPDIV2G_MASK                                                               0x00380000
< #define PHY_ANALOG_TXRF6_CAPDIV2G_GET(x)                                             (((x) & 0x00380000) >> 19)
< #define PHY_ANALOG_TXRF6_CAPDIV2G_SET(x)                                             (((x) << 19) & 0x00380000)
< #define PHY_ANALOG_TXRF6_CAPDIV2GOVR_MSB                                                                     22
< #define PHY_ANALOG_TXRF6_CAPDIV2GOVR_LSB                                                                     22
< #define PHY_ANALOG_TXRF6_CAPDIV2GOVR_MASK                                                            0x00400000
< #define PHY_ANALOG_TXRF6_CAPDIV2GOVR_GET(x)                                          (((x) & 0x00400000) >> 22)
< #define PHY_ANALOG_TXRF6_CAPDIV2GOVR_SET(x)                                          (((x) << 22) & 0x00400000)
< #define PHY_ANALOG_TXRF6_ENPACAL2G_MSB                                                                       23
< #define PHY_ANALOG_TXRF6_ENPACAL2G_LSB                                                                       23
< #define PHY_ANALOG_TXRF6_ENPACAL2G_MASK                                                              0x00800000
< #define PHY_ANALOG_TXRF6_ENPACAL2G_GET(x)                                            (((x) & 0x00800000) >> 23)
< #define PHY_ANALOG_TXRF6_ENPACAL2G_SET(x)                                            (((x) << 23) & 0x00800000)
< #define PHY_ANALOG_TXRF6_OFFSET2G_MSB                                                                        30
< #define PHY_ANALOG_TXRF6_OFFSET2G_LSB                                                                        24
< #define PHY_ANALOG_TXRF6_OFFSET2G_MASK                                                               0x7f000000
< #define PHY_ANALOG_TXRF6_OFFSET2G_GET(x)                                             (((x) & 0x7f000000) >> 24)
< #define PHY_ANALOG_TXRF6_OFFSET2G_SET(x)                                             (((x) << 24) & 0x7f000000)
< #define PHY_ANALOG_TXRF6_ENOFFSETCAL2G_MSB                                                                   31
< #define PHY_ANALOG_TXRF6_ENOFFSETCAL2G_LSB                                                                   31
< #define PHY_ANALOG_TXRF6_ENOFFSETCAL2G_MASK                                                          0x80000000
< #define PHY_ANALOG_TXRF6_ENOFFSETCAL2G_GET(x)                                        (((x) & 0x80000000) >> 31)
< #define PHY_ANALOG_TXRF6_ENOFFSETCAL2G_SET(x)                                        (((x) << 31) & 0x80000000)
---
> #define PHY_ANALOG_TXRF6_PALCLKGATE2G_MSB                                                                     0
> #define PHY_ANALOG_TXRF6_PALCLKGATE2G_LSB                                                                     0
> #define PHY_ANALOG_TXRF6_PALCLKGATE2G_MASK                                                           0x00000001
> #define PHY_ANALOG_TXRF6_PALCLKGATE2G_GET(x)                                          (((x) & 0x00000001) >> 0)
> #define PHY_ANALOG_TXRF6_PALCLKGATE2G_SET(x)                                          (((x) << 0) & 0x00000001)
> #define PHY_ANALOG_TXRF6_PALFLUCTCOUNT2G_MSB                                                                  8
> #define PHY_ANALOG_TXRF6_PALFLUCTCOUNT2G_LSB                                                                  1
> #define PHY_ANALOG_TXRF6_PALFLUCTCOUNT2G_MASK                                                        0x000001fe
> #define PHY_ANALOG_TXRF6_PALFLUCTCOUNT2G_GET(x)                                       (((x) & 0x000001fe) >> 1)
> #define PHY_ANALOG_TXRF6_PALFLUCTCOUNT2G_SET(x)                                       (((x) << 1) & 0x000001fe)
> #define PHY_ANALOG_TXRF6_PALFLUCTGAIN2G_MSB                                                                  10
> #define PHY_ANALOG_TXRF6_PALFLUCTGAIN2G_LSB                                                                   9
> #define PHY_ANALOG_TXRF6_PALFLUCTGAIN2G_MASK                                                         0x00000600
> #define PHY_ANALOG_TXRF6_PALFLUCTGAIN2G_GET(x)                                        (((x) & 0x00000600) >> 9)
> #define PHY_ANALOG_TXRF6_PALFLUCTGAIN2G_SET(x)                                        (((x) << 9) & 0x00000600)
> #define PHY_ANALOG_TXRF6_PALNOFLUCT2G_MSB                                                                    11
> #define PHY_ANALOG_TXRF6_PALNOFLUCT2G_LSB                                                                    11
> #define PHY_ANALOG_TXRF6_PALNOFLUCT2G_MASK                                                           0x00000800
> #define PHY_ANALOG_TXRF6_PALNOFLUCT2G_GET(x)                                         (((x) & 0x00000800) >> 11)
> #define PHY_ANALOG_TXRF6_PALNOFLUCT2G_SET(x)                                         (((x) << 11) & 0x00000800)
> #define PHY_ANALOG_TXRF6_GAINSTEP2G_MSB                                                                      14
> #define PHY_ANALOG_TXRF6_GAINSTEP2G_LSB                                                                      12
> #define PHY_ANALOG_TXRF6_GAINSTEP2G_MASK                                                             0x00007000
> #define PHY_ANALOG_TXRF6_GAINSTEP2G_GET(x)                                           (((x) & 0x00007000) >> 12)
> #define PHY_ANALOG_TXRF6_GAINSTEP2G_SET(x)                                           (((x) << 12) & 0x00007000)
> #define PHY_ANALOG_TXRF6_USE_GAIN_DELTA2G_MSB                                                                15
> #define PHY_ANALOG_TXRF6_USE_GAIN_DELTA2G_LSB                                                                15
> #define PHY_ANALOG_TXRF6_USE_GAIN_DELTA2G_MASK                                                       0x00008000
> #define PHY_ANALOG_TXRF6_USE_GAIN_DELTA2G_GET(x)                                     (((x) & 0x00008000) >> 15)
> #define PHY_ANALOG_TXRF6_USE_GAIN_DELTA2G_SET(x)                                     (((x) << 15) & 0x00008000)
> #define PHY_ANALOG_TXRF6_CAPDIV_I2G_MSB                                                                      19
> #define PHY_ANALOG_TXRF6_CAPDIV_I2G_LSB                                                                      16
> #define PHY_ANALOG_TXRF6_CAPDIV_I2G_MASK                                                             0x000f0000
> #define PHY_ANALOG_TXRF6_CAPDIV_I2G_GET(x)                                           (((x) & 0x000f0000) >> 16)
> #define PHY_ANALOG_TXRF6_CAPDIV_I2G_SET(x)                                           (((x) << 16) & 0x000f0000)
> #define PHY_ANALOG_TXRF6_PADRVGN_INDEX_I2G_MSB                                                               23
> #define PHY_ANALOG_TXRF6_PADRVGN_INDEX_I2G_LSB                                                               20
> #define PHY_ANALOG_TXRF6_PADRVGN_INDEX_I2G_MASK                                                      0x00f00000
> #define PHY_ANALOG_TXRF6_PADRVGN_INDEX_I2G_GET(x)                                    (((x) & 0x00f00000) >> 20)
> #define PHY_ANALOG_TXRF6_PADRVGN_INDEX_I2G_SET(x)                                    (((x) << 20) & 0x00f00000)
> #define PHY_ANALOG_TXRF6_VCMONDELAY2G_MSB                                                                    26
> #define PHY_ANALOG_TXRF6_VCMONDELAY2G_LSB                                                                    24
> #define PHY_ANALOG_TXRF6_VCMONDELAY2G_MASK                                                           0x07000000
> #define PHY_ANALOG_TXRF6_VCMONDELAY2G_GET(x)                                         (((x) & 0x07000000) >> 24)
> #define PHY_ANALOG_TXRF6_VCMONDELAY2G_SET(x)                                         (((x) << 24) & 0x07000000)
> #define PHY_ANALOG_TXRF6_CAPDIV2G_MSB                                                                        30
> #define PHY_ANALOG_TXRF6_CAPDIV2G_LSB                                                                        27
> #define PHY_ANALOG_TXRF6_CAPDIV2G_MASK                                                               0x78000000
> #define PHY_ANALOG_TXRF6_CAPDIV2G_GET(x)                                             (((x) & 0x78000000) >> 27)
> #define PHY_ANALOG_TXRF6_CAPDIV2G_SET(x)                                             (((x) << 27) & 0x78000000)
> #define PHY_ANALOG_TXRF6_CAPDIV2GOVR_MSB                                                                     31
> #define PHY_ANALOG_TXRF6_CAPDIV2GOVR_LSB                                                                     31
> #define PHY_ANALOG_TXRF6_CAPDIV2GOVR_MASK                                                            0x80000000
> #define PHY_ANALOG_TXRF6_CAPDIV2GOVR_GET(x)                                          (((x) & 0x80000000) >> 31)
> #define PHY_ANALOG_TXRF6_CAPDIV2GOVR_SET(x)                                          (((x) << 31) & 0x80000000)
793c858
< #define PHY_ANALOG_TXRF10_SPARE10_MSB                                                                        12
---
> #define PHY_ANALOG_TXRF10_SPARE10_MSB                                                                         2
795,832c860,905
< #define PHY_ANALOG_TXRF10_SPARE10_MASK                                                               0x00001fff
< #define PHY_ANALOG_TXRF10_SPARE10_GET(x)                                              (((x) & 0x00001fff) >> 0)
< #define PHY_ANALOG_TXRF10_SPARE10_SET(x)                                              (((x) << 0) & 0x00001fff)
< #define PHY_ANALOG_TXRF10_PDOUT5G_3CALTX_MSB                                                                 13
< #define PHY_ANALOG_TXRF10_PDOUT5G_3CALTX_LSB                                                                 13
< #define PHY_ANALOG_TXRF10_PDOUT5G_3CALTX_MASK                                                        0x00002000
< #define PHY_ANALOG_TXRF10_PDOUT5G_3CALTX_GET(x)                                      (((x) & 0x00002000) >> 13)
< #define PHY_ANALOG_TXRF10_PDOUT5G_3CALTX_SET(x)                                      (((x) << 13) & 0x00002000)
< #define PHY_ANALOG_TXRF10_D3B5GCALTX_MSB                                                                     16
< #define PHY_ANALOG_TXRF10_D3B5GCALTX_LSB                                                                     14
< #define PHY_ANALOG_TXRF10_D3B5GCALTX_MASK                                                            0x0001c000
< #define PHY_ANALOG_TXRF10_D3B5GCALTX_GET(x)                                          (((x) & 0x0001c000) >> 14)
< #define PHY_ANALOG_TXRF10_D3B5GCALTX_SET(x)                                          (((x) << 14) & 0x0001c000)
< #define PHY_ANALOG_TXRF10_D4B5GCALTX_MSB                                                                     19
< #define PHY_ANALOG_TXRF10_D4B5GCALTX_LSB                                                                     17
< #define PHY_ANALOG_TXRF10_D4B5GCALTX_MASK                                                            0x000e0000
< #define PHY_ANALOG_TXRF10_D4B5GCALTX_GET(x)                                          (((x) & 0x000e0000) >> 17)
< #define PHY_ANALOG_TXRF10_D4B5GCALTX_SET(x)                                          (((x) << 17) & 0x000e0000)
< #define PHY_ANALOG_TXRF10_PADRVGN2GCALTX_MSB                                                                 26
< #define PHY_ANALOG_TXRF10_PADRVGN2GCALTX_LSB                                                                 20
< #define PHY_ANALOG_TXRF10_PADRVGN2GCALTX_MASK                                                        0x07f00000
< #define PHY_ANALOG_TXRF10_PADRVGN2GCALTX_GET(x)                                      (((x) & 0x07f00000) >> 20)
< #define PHY_ANALOG_TXRF10_PADRVGN2GCALTX_SET(x)                                      (((x) << 20) & 0x07f00000)
< #define PHY_ANALOG_TXRF10_DB2GCALTX_MSB                                                                      29
< #define PHY_ANALOG_TXRF10_DB2GCALTX_LSB                                                                      27
< #define PHY_ANALOG_TXRF10_DB2GCALTX_MASK                                                             0x38000000
< #define PHY_ANALOG_TXRF10_DB2GCALTX_GET(x)                                           (((x) & 0x38000000) >> 27)
< #define PHY_ANALOG_TXRF10_DB2GCALTX_SET(x)                                           (((x) << 27) & 0x38000000)
< #define PHY_ANALOG_TXRF10_CALTXSHIFT_MSB                                                                     30
< #define PHY_ANALOG_TXRF10_CALTXSHIFT_LSB                                                                     30
< #define PHY_ANALOG_TXRF10_CALTXSHIFT_MASK                                                            0x40000000
< #define PHY_ANALOG_TXRF10_CALTXSHIFT_GET(x)                                          (((x) & 0x40000000) >> 30)
< #define PHY_ANALOG_TXRF10_CALTXSHIFT_SET(x)                                          (((x) << 30) & 0x40000000)
< #define PHY_ANALOG_TXRF10_CALTXSHIFTOVR_MSB                                                                  31
< #define PHY_ANALOG_TXRF10_CALTXSHIFTOVR_LSB                                                                  31
< #define PHY_ANALOG_TXRF10_CALTXSHIFTOVR_MASK                                                         0x80000000
< #define PHY_ANALOG_TXRF10_CALTXSHIFTOVR_GET(x)                                       (((x) & 0x80000000) >> 31)
< #define PHY_ANALOG_TXRF10_CALTXSHIFTOVR_SET(x)                                       (((x) << 31) & 0x80000000)
---
> #define PHY_ANALOG_TXRF10_SPARE10_MASK                                                               0x00000007
> #define PHY_ANALOG_TXRF10_SPARE10_GET(x)                                              (((x) & 0x00000007) >> 0)
> #define PHY_ANALOG_TXRF10_SPARE10_SET(x)                                              (((x) << 0) & 0x00000007)
> #define PHY_ANALOG_TXRF10_PDOUT5G_3CALTX_MSB                                                                  3
> #define PHY_ANALOG_TXRF10_PDOUT5G_3CALTX_LSB                                                                  3
> #define PHY_ANALOG_TXRF10_PDOUT5G_3CALTX_MASK                                                        0x00000008
> #define PHY_ANALOG_TXRF10_PDOUT5G_3CALTX_GET(x)                                       (((x) & 0x00000008) >> 3)
> #define PHY_ANALOG_TXRF10_PDOUT5G_3CALTX_SET(x)                                       (((x) << 3) & 0x00000008)
> #define PHY_ANALOG_TXRF10_D3B5GCALTX_MSB                                                                      6
> #define PHY_ANALOG_TXRF10_D3B5GCALTX_LSB                                                                      4
> #define PHY_ANALOG_TXRF10_D3B5GCALTX_MASK                                                            0x00000070
> #define PHY_ANALOG_TXRF10_D3B5GCALTX_GET(x)                                           (((x) & 0x00000070) >> 4)
> #define PHY_ANALOG_TXRF10_D3B5GCALTX_SET(x)                                           (((x) << 4) & 0x00000070)
> #define PHY_ANALOG_TXRF10_D4B5GCALTX_MSB                                                                      9
> #define PHY_ANALOG_TXRF10_D4B5GCALTX_LSB                                                                      7
> #define PHY_ANALOG_TXRF10_D4B5GCALTX_MASK                                                            0x00000380
> #define PHY_ANALOG_TXRF10_D4B5GCALTX_GET(x)                                           (((x) & 0x00000380) >> 7)
> #define PHY_ANALOG_TXRF10_D4B5GCALTX_SET(x)                                           (((x) << 7) & 0x00000380)
> #define PHY_ANALOG_TXRF10_PADRVGN2GCALTX_MSB                                                                 16
> #define PHY_ANALOG_TXRF10_PADRVGN2GCALTX_LSB                                                                 10
> #define PHY_ANALOG_TXRF10_PADRVGN2GCALTX_MASK                                                        0x0001fc00
> #define PHY_ANALOG_TXRF10_PADRVGN2GCALTX_GET(x)                                      (((x) & 0x0001fc00) >> 10)
> #define PHY_ANALOG_TXRF10_PADRVGN2GCALTX_SET(x)                                      (((x) << 10) & 0x0001fc00)
> #define PHY_ANALOG_TXRF10_DB2GCALTX_MSB                                                                      19
> #define PHY_ANALOG_TXRF10_DB2GCALTX_LSB                                                                      17
> #define PHY_ANALOG_TXRF10_DB2GCALTX_MASK                                                             0x000e0000
> #define PHY_ANALOG_TXRF10_DB2GCALTX_GET(x)                                           (((x) & 0x000e0000) >> 17)
> #define PHY_ANALOG_TXRF10_DB2GCALTX_SET(x)                                           (((x) << 17) & 0x000e0000)
> #define PHY_ANALOG_TXRF10_CALTXSHIFT_MSB                                                                     20
> #define PHY_ANALOG_TXRF10_CALTXSHIFT_LSB                                                                     20
> #define PHY_ANALOG_TXRF10_CALTXSHIFT_MASK                                                            0x00100000
> #define PHY_ANALOG_TXRF10_CALTXSHIFT_GET(x)                                          (((x) & 0x00100000) >> 20)
> #define PHY_ANALOG_TXRF10_CALTXSHIFT_SET(x)                                          (((x) << 20) & 0x00100000)
> #define PHY_ANALOG_TXRF10_CALTXSHIFTOVR_MSB                                                                  21
> #define PHY_ANALOG_TXRF10_CALTXSHIFTOVR_LSB                                                                  21
> #define PHY_ANALOG_TXRF10_CALTXSHIFTOVR_MASK                                                         0x00200000
> #define PHY_ANALOG_TXRF10_CALTXSHIFTOVR_GET(x)                                       (((x) & 0x00200000) >> 21)
> #define PHY_ANALOG_TXRF10_CALTXSHIFTOVR_SET(x)                                       (((x) << 21) & 0x00200000)
> #define PHY_ANALOG_TXRF10_PADRVGN2G_SMOUT_MSB                                                                27
> #define PHY_ANALOG_TXRF10_PADRVGN2G_SMOUT_LSB                                                                22
> #define PHY_ANALOG_TXRF10_PADRVGN2G_SMOUT_MASK                                                       0x0fc00000
> #define PHY_ANALOG_TXRF10_PADRVGN2G_SMOUT_GET(x)                                     (((x) & 0x0fc00000) >> 22)
> #define PHY_ANALOG_TXRF10_PADRVGN_INDEX2G_SMOUT_MSB                                                          31
> #define PHY_ANALOG_TXRF10_PADRVGN_INDEX2G_SMOUT_LSB                                                          28
> #define PHY_ANALOG_TXRF10_PADRVGN_INDEX2G_SMOUT_MASK                                                 0xf0000000
> #define PHY_ANALOG_TXRF10_PADRVGN_INDEX2G_SMOUT_GET(x)                               (((x) & 0xf0000000) >> 28)
842,871c915,944
< #define PHY_ANALOG_TXRF11_PWD_IR25MIXBIAS5G_MSB                                                               4
< #define PHY_ANALOG_TXRF11_PWD_IR25MIXBIAS5G_LSB                                                               2
< #define PHY_ANALOG_TXRF11_PWD_IR25MIXBIAS5G_MASK                                                     0x0000001c
< #define PHY_ANALOG_TXRF11_PWD_IR25MIXBIAS5G_GET(x)                                    (((x) & 0x0000001c) >> 2)
< #define PHY_ANALOG_TXRF11_PWD_IR25MIXBIAS5G_SET(x)                                    (((x) << 2) & 0x0000001c)
< #define PHY_ANALOG_TXRF11_PWD_IR25MIXDIV5G_MSB                                                                7
< #define PHY_ANALOG_TXRF11_PWD_IR25MIXDIV5G_LSB                                                                5
< #define PHY_ANALOG_TXRF11_PWD_IR25MIXDIV5G_MASK                                                      0x000000e0
< #define PHY_ANALOG_TXRF11_PWD_IR25MIXDIV5G_GET(x)                                     (((x) & 0x000000e0) >> 5)
< #define PHY_ANALOG_TXRF11_PWD_IR25MIXDIV5G_SET(x)                                     (((x) << 5) & 0x000000e0)
< #define PHY_ANALOG_TXRF11_PWD_IR25PA2G_MSB                                                                   10
< #define PHY_ANALOG_TXRF11_PWD_IR25PA2G_LSB                                                                    8
< #define PHY_ANALOG_TXRF11_PWD_IR25PA2G_MASK                                                          0x00000700
< #define PHY_ANALOG_TXRF11_PWD_IR25PA2G_GET(x)                                         (((x) & 0x00000700) >> 8)
< #define PHY_ANALOG_TXRF11_PWD_IR25PA2G_SET(x)                                         (((x) << 8) & 0x00000700)
< #define PHY_ANALOG_TXRF11_PWD_IR25MIXBIAS2G_MSB                                                              13
< #define PHY_ANALOG_TXRF11_PWD_IR25MIXBIAS2G_LSB                                                              11
< #define PHY_ANALOG_TXRF11_PWD_IR25MIXBIAS2G_MASK                                                     0x00003800
< #define PHY_ANALOG_TXRF11_PWD_IR25MIXBIAS2G_GET(x)                                   (((x) & 0x00003800) >> 11)
< #define PHY_ANALOG_TXRF11_PWD_IR25MIXBIAS2G_SET(x)                                   (((x) << 11) & 0x00003800)
< #define PHY_ANALOG_TXRF11_PWD_IR25MIXDIV2G_MSB                                                               16
< #define PHY_ANALOG_TXRF11_PWD_IR25MIXDIV2G_LSB                                                               14
< #define PHY_ANALOG_TXRF11_PWD_IR25MIXDIV2G_MASK                                                      0x0001c000
< #define PHY_ANALOG_TXRF11_PWD_IR25MIXDIV2G_GET(x)                                    (((x) & 0x0001c000) >> 14)
< #define PHY_ANALOG_TXRF11_PWD_IR25MIXDIV2G_SET(x)                                    (((x) << 14) & 0x0001c000)
< #define PHY_ANALOG_TXRF11_PWD_ICSPARE_MSB                                                                    19
< #define PHY_ANALOG_TXRF11_PWD_ICSPARE_LSB                                                                    17
< #define PHY_ANALOG_TXRF11_PWD_ICSPARE_MASK                                                           0x000e0000
< #define PHY_ANALOG_TXRF11_PWD_ICSPARE_GET(x)                                         (((x) & 0x000e0000) >> 17)
< #define PHY_ANALOG_TXRF11_PWD_ICSPARE_SET(x)                                         (((x) << 17) & 0x000e0000)
---
> #define PHY_ANALOG_TXRF11_PWD_IR25MIXDIV5G_MSB                                                                4
> #define PHY_ANALOG_TXRF11_PWD_IR25MIXDIV5G_LSB                                                                2
> #define PHY_ANALOG_TXRF11_PWD_IR25MIXDIV5G_MASK                                                      0x0000001c
> #define PHY_ANALOG_TXRF11_PWD_IR25MIXDIV5G_GET(x)                                     (((x) & 0x0000001c) >> 2)
> #define PHY_ANALOG_TXRF11_PWD_IR25MIXDIV5G_SET(x)                                     (((x) << 2) & 0x0000001c)
> #define PHY_ANALOG_TXRF11_PWD_IR25PA2G_MSB                                                                    7
> #define PHY_ANALOG_TXRF11_PWD_IR25PA2G_LSB                                                                    5
> #define PHY_ANALOG_TXRF11_PWD_IR25PA2G_MASK                                                          0x000000e0
> #define PHY_ANALOG_TXRF11_PWD_IR25PA2G_GET(x)                                         (((x) & 0x000000e0) >> 5)
> #define PHY_ANALOG_TXRF11_PWD_IR25PA2G_SET(x)                                         (((x) << 5) & 0x000000e0)
> #define PHY_ANALOG_TXRF11_PWD_IR25MIXBIAS2G_MSB                                                              10
> #define PHY_ANALOG_TXRF11_PWD_IR25MIXBIAS2G_LSB                                                               8
> #define PHY_ANALOG_TXRF11_PWD_IR25MIXBIAS2G_MASK                                                     0x00000700
> #define PHY_ANALOG_TXRF11_PWD_IR25MIXBIAS2G_GET(x)                                    (((x) & 0x00000700) >> 8)
> #define PHY_ANALOG_TXRF11_PWD_IR25MIXBIAS2G_SET(x)                                    (((x) << 8) & 0x00000700)
> #define PHY_ANALOG_TXRF11_PWD_IR25MIXDIV2G_MSB                                                               13
> #define PHY_ANALOG_TXRF11_PWD_IR25MIXDIV2G_LSB                                                               11
> #define PHY_ANALOG_TXRF11_PWD_IR25MIXDIV2G_MASK                                                      0x00003800
> #define PHY_ANALOG_TXRF11_PWD_IR25MIXDIV2G_GET(x)                                    (((x) & 0x00003800) >> 11)
> #define PHY_ANALOG_TXRF11_PWD_IR25MIXDIV2G_SET(x)                                    (((x) << 11) & 0x00003800)
> #define PHY_ANALOG_TXRF11_PWD_ICSPARE_MSB                                                                    16
> #define PHY_ANALOG_TXRF11_PWD_ICSPARE_LSB                                                                    14
> #define PHY_ANALOG_TXRF11_PWD_ICSPARE_MASK                                                           0x0001c000
> #define PHY_ANALOG_TXRF11_PWD_ICSPARE_GET(x)                                         (((x) & 0x0001c000) >> 14)
> #define PHY_ANALOG_TXRF11_PWD_ICSPARE_SET(x)                                         (((x) << 14) & 0x0001c000)
> #define PHY_ANALOG_TXRF11_PWD_IC25TEMPSEN_MSB                                                                19
> #define PHY_ANALOG_TXRF11_PWD_IC25TEMPSEN_LSB                                                                17
> #define PHY_ANALOG_TXRF11_PWD_IC25TEMPSEN_MASK                                                       0x000e0000
> #define PHY_ANALOG_TXRF11_PWD_IC25TEMPSEN_GET(x)                                     (((x) & 0x000e0000) >> 17)
> #define PHY_ANALOG_TXRF11_PWD_IC25TEMPSEN_SET(x)                                     (((x) << 17) & 0x000e0000)
900c973
< #define PHY_ANALOG_TXRF12_SPARE12_1_MSB                                                                      15
---
> #define PHY_ANALOG_TXRF12_SPARE12_1_MSB                                                                       9
902,929c975,1012
< #define PHY_ANALOG_TXRF12_SPARE12_1_MASK                                                             0x0000ff00
< #define PHY_ANALOG_TXRF12_SPARE12_1_GET(x)                                            (((x) & 0x0000ff00) >> 8)
< #define PHY_ANALOG_TXRF12_SPARE12_1_SET(x)                                            (((x) << 8) & 0x0000ff00)
< #define PHY_ANALOG_TXRF12_ATBSEL5G_MSB                                                                       19
< #define PHY_ANALOG_TXRF12_ATBSEL5G_LSB                                                                       16
< #define PHY_ANALOG_TXRF12_ATBSEL5G_MASK                                                              0x000f0000
< #define PHY_ANALOG_TXRF12_ATBSEL5G_GET(x)                                            (((x) & 0x000f0000) >> 16)
< #define PHY_ANALOG_TXRF12_ATBSEL5G_SET(x)                                            (((x) << 16) & 0x000f0000)
< #define PHY_ANALOG_TXRF12_ATBSEL2G_MSB                                                                       22
< #define PHY_ANALOG_TXRF12_ATBSEL2G_LSB                                                                       20
< #define PHY_ANALOG_TXRF12_ATBSEL2G_MASK                                                              0x00700000
< #define PHY_ANALOG_TXRF12_ATBSEL2G_GET(x)                                            (((x) & 0x00700000) >> 20)
< #define PHY_ANALOG_TXRF12_ATBSEL2G_SET(x)                                            (((x) << 20) & 0x00700000)
< #define PHY_ANALOG_TXRF12_PWD_IRSPARE_MSB                                                                    25
< #define PHY_ANALOG_TXRF12_PWD_IRSPARE_LSB                                                                    23
< #define PHY_ANALOG_TXRF12_PWD_IRSPARE_MASK                                                           0x03800000
< #define PHY_ANALOG_TXRF12_PWD_IRSPARE_GET(x)                                         (((x) & 0x03800000) >> 23)
< #define PHY_ANALOG_TXRF12_PWD_IRSPARE_SET(x)                                         (((x) << 23) & 0x03800000)
< #define PHY_ANALOG_TXRF12_PWD_IR25PA5G2_MSB                                                                  28
< #define PHY_ANALOG_TXRF12_PWD_IR25PA5G2_LSB                                                                  26
< #define PHY_ANALOG_TXRF12_PWD_IR25PA5G2_MASK                                                         0x1c000000
< #define PHY_ANALOG_TXRF12_PWD_IR25PA5G2_GET(x)                                       (((x) & 0x1c000000) >> 26)
< #define PHY_ANALOG_TXRF12_PWD_IR25PA5G2_SET(x)                                       (((x) << 26) & 0x1c000000)
< #define PHY_ANALOG_TXRF12_PWD_IR25PA5G1_MSB                                                                  31
< #define PHY_ANALOG_TXRF12_PWD_IR25PA5G1_LSB                                                                  29
< #define PHY_ANALOG_TXRF12_PWD_IR25PA5G1_MASK                                                         0xe0000000
< #define PHY_ANALOG_TXRF12_PWD_IR25PA5G1_GET(x)                                       (((x) & 0xe0000000) >> 29)
< #define PHY_ANALOG_TXRF12_PWD_IR25PA5G1_SET(x)                                       (((x) << 29) & 0xe0000000)
---
> #define PHY_ANALOG_TXRF12_SPARE12_1_MASK                                                             0x00000300
> #define PHY_ANALOG_TXRF12_SPARE12_1_GET(x)                                            (((x) & 0x00000300) >> 8)
> #define PHY_ANALOG_TXRF12_SPARE12_1_SET(x)                                            (((x) << 8) & 0x00000300)
> #define PHY_ANALOG_TXRF12_ATBSEL5G_MSB                                                                       13
> #define PHY_ANALOG_TXRF12_ATBSEL5G_LSB                                                                       10
> #define PHY_ANALOG_TXRF12_ATBSEL5G_MASK                                                              0x00003c00
> #define PHY_ANALOG_TXRF12_ATBSEL5G_GET(x)                                            (((x) & 0x00003c00) >> 10)
> #define PHY_ANALOG_TXRF12_ATBSEL5G_SET(x)                                            (((x) << 10) & 0x00003c00)
> #define PHY_ANALOG_TXRF12_ATBSEL2G_MSB                                                                       16
> #define PHY_ANALOG_TXRF12_ATBSEL2G_LSB                                                                       14
> #define PHY_ANALOG_TXRF12_ATBSEL2G_MASK                                                              0x0001c000
> #define PHY_ANALOG_TXRF12_ATBSEL2G_GET(x)                                            (((x) & 0x0001c000) >> 14)
> #define PHY_ANALOG_TXRF12_ATBSEL2G_SET(x)                                            (((x) << 14) & 0x0001c000)
> #define PHY_ANALOG_TXRF12_PWD_IRSPARE_MSB                                                                    19
> #define PHY_ANALOG_TXRF12_PWD_IRSPARE_LSB                                                                    17
> #define PHY_ANALOG_TXRF12_PWD_IRSPARE_MASK                                                           0x000e0000
> #define PHY_ANALOG_TXRF12_PWD_IRSPARE_GET(x)                                         (((x) & 0x000e0000) >> 17)
> #define PHY_ANALOG_TXRF12_PWD_IRSPARE_SET(x)                                         (((x) << 17) & 0x000e0000)
> #define PHY_ANALOG_TXRF12_PWD_IR25TEMPSEN_MSB                                                                22
> #define PHY_ANALOG_TXRF12_PWD_IR25TEMPSEN_LSB                                                                20
> #define PHY_ANALOG_TXRF12_PWD_IR25TEMPSEN_MASK                                                       0x00700000
> #define PHY_ANALOG_TXRF12_PWD_IR25TEMPSEN_GET(x)                                     (((x) & 0x00700000) >> 20)
> #define PHY_ANALOG_TXRF12_PWD_IR25TEMPSEN_SET(x)                                     (((x) << 20) & 0x00700000)
> #define PHY_ANALOG_TXRF12_PWD_IR25PA5G2_MSB                                                                  25
> #define PHY_ANALOG_TXRF12_PWD_IR25PA5G2_LSB                                                                  23
> #define PHY_ANALOG_TXRF12_PWD_IR25PA5G2_MASK                                                         0x03800000
> #define PHY_ANALOG_TXRF12_PWD_IR25PA5G2_GET(x)                                       (((x) & 0x03800000) >> 23)
> #define PHY_ANALOG_TXRF12_PWD_IR25PA5G2_SET(x)                                       (((x) << 23) & 0x03800000)
> #define PHY_ANALOG_TXRF12_PWD_IR25PA5G1_MSB                                                                  28
> #define PHY_ANALOG_TXRF12_PWD_IR25PA5G1_LSB                                                                  26
> #define PHY_ANALOG_TXRF12_PWD_IR25PA5G1_MASK                                                         0x1c000000
> #define PHY_ANALOG_TXRF12_PWD_IR25PA5G1_GET(x)                                       (((x) & 0x1c000000) >> 26)
> #define PHY_ANALOG_TXRF12_PWD_IR25PA5G1_SET(x)                                       (((x) << 26) & 0x1c000000)
> #define PHY_ANALOG_TXRF12_PWD_IR25MIXBIAS5G_MSB                                                              31
> #define PHY_ANALOG_TXRF12_PWD_IR25MIXBIAS5G_LSB                                                              29
> #define PHY_ANALOG_TXRF12_PWD_IR25MIXBIAS5G_MASK                                                     0xe0000000
> #define PHY_ANALOG_TXRF12_PWD_IR25MIXBIAS5G_GET(x)                                   (((x) & 0xe0000000) >> 29)
> #define PHY_ANALOG_TXRF12_PWD_IR25MIXBIAS5G_SET(x)                                   (((x) << 29) & 0xe0000000)
2551c2634
< #define PHY_ANALOG_PLLCLKMODA2_SPARE_MSB                                                                      0
---
> #define PHY_ANALOG_PLLCLKMODA2_SPARE_MSB                                                                      3
2553,2630c2636,2713
< #define PHY_ANALOG_PLLCLKMODA2_SPARE_MASK                                                            0x00000001
< #define PHY_ANALOG_PLLCLKMODA2_SPARE_GET(x)                                           (((x) & 0x00000001) >> 0)
< #define PHY_ANALOG_PLLCLKMODA2_SPARE_SET(x)                                           (((x) << 0) & 0x00000001)
< #define PHY_ANALOG_PLLCLKMODA2_DACPWD_MSB                                                                     1
< #define PHY_ANALOG_PLLCLKMODA2_DACPWD_LSB                                                                     1
< #define PHY_ANALOG_PLLCLKMODA2_DACPWD_MASK                                                           0x00000002
< #define PHY_ANALOG_PLLCLKMODA2_DACPWD_GET(x)                                          (((x) & 0x00000002) >> 1)
< #define PHY_ANALOG_PLLCLKMODA2_DACPWD_SET(x)                                          (((x) << 1) & 0x00000002)
< #define PHY_ANALOG_PLLCLKMODA2_ADCPWD_MSB                                                                     2
< #define PHY_ANALOG_PLLCLKMODA2_ADCPWD_LSB                                                                     2
< #define PHY_ANALOG_PLLCLKMODA2_ADCPWD_MASK                                                           0x00000004
< #define PHY_ANALOG_PLLCLKMODA2_ADCPWD_GET(x)                                          (((x) & 0x00000004) >> 2)
< #define PHY_ANALOG_PLLCLKMODA2_ADCPWD_SET(x)                                          (((x) << 2) & 0x00000004)
< #define PHY_ANALOG_PLLCLKMODA2_LOCAL_ADDAC_MSB                                                                3
< #define PHY_ANALOG_PLLCLKMODA2_LOCAL_ADDAC_LSB                                                                3
< #define PHY_ANALOG_PLLCLKMODA2_LOCAL_ADDAC_MASK                                                      0x00000008
< #define PHY_ANALOG_PLLCLKMODA2_LOCAL_ADDAC_GET(x)                                     (((x) & 0x00000008) >> 3)
< #define PHY_ANALOG_PLLCLKMODA2_LOCAL_ADDAC_SET(x)                                     (((x) << 3) & 0x00000008)
< #define PHY_ANALOG_PLLCLKMODA2_DAC_CLK_SEL_MSB                                                                5
< #define PHY_ANALOG_PLLCLKMODA2_DAC_CLK_SEL_LSB                                                                4
< #define PHY_ANALOG_PLLCLKMODA2_DAC_CLK_SEL_MASK                                                      0x00000030
< #define PHY_ANALOG_PLLCLKMODA2_DAC_CLK_SEL_GET(x)                                     (((x) & 0x00000030) >> 4)
< #define PHY_ANALOG_PLLCLKMODA2_DAC_CLK_SEL_SET(x)                                     (((x) << 4) & 0x00000030)
< #define PHY_ANALOG_PLLCLKMODA2_ADC_CLK_SEL_MSB                                                                9
< #define PHY_ANALOG_PLLCLKMODA2_ADC_CLK_SEL_LSB                                                                6
< #define PHY_ANALOG_PLLCLKMODA2_ADC_CLK_SEL_MASK                                                      0x000003c0
< #define PHY_ANALOG_PLLCLKMODA2_ADC_CLK_SEL_GET(x)                                     (((x) & 0x000003c0) >> 6)
< #define PHY_ANALOG_PLLCLKMODA2_ADC_CLK_SEL_SET(x)                                     (((x) << 6) & 0x000003c0)
< #define PHY_ANALOG_PLLCLKMODA2_LOCAL_CLKMODA_MSB                                                             10
< #define PHY_ANALOG_PLLCLKMODA2_LOCAL_CLKMODA_LSB                                                             10
< #define PHY_ANALOG_PLLCLKMODA2_LOCAL_CLKMODA_MASK                                                    0x00000400
< #define PHY_ANALOG_PLLCLKMODA2_LOCAL_CLKMODA_GET(x)                                  (((x) & 0x00000400) >> 10)
< #define PHY_ANALOG_PLLCLKMODA2_LOCAL_CLKMODA_SET(x)                                  (((x) << 10) & 0x00000400)
< #define PHY_ANALOG_PLLCLKMODA2_PLLBYPASS_MSB                                                                 11
< #define PHY_ANALOG_PLLCLKMODA2_PLLBYPASS_LSB                                                                 11
< #define PHY_ANALOG_PLLCLKMODA2_PLLBYPASS_MASK                                                        0x00000800
< #define PHY_ANALOG_PLLCLKMODA2_PLLBYPASS_GET(x)                                      (((x) & 0x00000800) >> 11)
< #define PHY_ANALOG_PLLCLKMODA2_PLLBYPASS_SET(x)                                      (((x) << 11) & 0x00000800)
< #define PHY_ANALOG_PLLCLKMODA2_LOCAL_PLLBYPASS_MSB                                                           12
< #define PHY_ANALOG_PLLCLKMODA2_LOCAL_PLLBYPASS_LSB                                                           12
< #define PHY_ANALOG_PLLCLKMODA2_LOCAL_PLLBYPASS_MASK                                                  0x00001000
< #define PHY_ANALOG_PLLCLKMODA2_LOCAL_PLLBYPASS_GET(x)                                (((x) & 0x00001000) >> 12)
< #define PHY_ANALOG_PLLCLKMODA2_LOCAL_PLLBYPASS_SET(x)                                (((x) << 12) & 0x00001000)
< #define PHY_ANALOG_PLLCLKMODA2_PLLATB_MSB                                                                    14
< #define PHY_ANALOG_PLLCLKMODA2_PLLATB_LSB                                                                    13
< #define PHY_ANALOG_PLLCLKMODA2_PLLATB_MASK                                                           0x00006000
< #define PHY_ANALOG_PLLCLKMODA2_PLLATB_GET(x)                                         (((x) & 0x00006000) >> 13)
< #define PHY_ANALOG_PLLCLKMODA2_PLLATB_SET(x)                                         (((x) << 13) & 0x00006000)
< #define PHY_ANALOG_PLLCLKMODA2_PLL_SVREG_MSB                                                                 15
< #define PHY_ANALOG_PLLCLKMODA2_PLL_SVREG_LSB                                                                 15
< #define PHY_ANALOG_PLLCLKMODA2_PLL_SVREG_MASK                                                        0x00008000
< #define PHY_ANALOG_PLLCLKMODA2_PLL_SVREG_GET(x)                                      (((x) & 0x00008000) >> 15)
< #define PHY_ANALOG_PLLCLKMODA2_PLL_SVREG_SET(x)                                      (((x) << 15) & 0x00008000)
< #define PHY_ANALOG_PLLCLKMODA2_HI_FREQ_EN_MSB                                                                16
< #define PHY_ANALOG_PLLCLKMODA2_HI_FREQ_EN_LSB                                                                16
< #define PHY_ANALOG_PLLCLKMODA2_HI_FREQ_EN_MASK                                                       0x00010000
< #define PHY_ANALOG_PLLCLKMODA2_HI_FREQ_EN_GET(x)                                     (((x) & 0x00010000) >> 16)
< #define PHY_ANALOG_PLLCLKMODA2_HI_FREQ_EN_SET(x)                                     (((x) << 16) & 0x00010000)
< #define PHY_ANALOG_PLLCLKMODA2_RST_WARM_INT_L_MSB                                                            17
< #define PHY_ANALOG_PLLCLKMODA2_RST_WARM_INT_L_LSB                                                            17
< #define PHY_ANALOG_PLLCLKMODA2_RST_WARM_INT_L_MASK                                                   0x00020000
< #define PHY_ANALOG_PLLCLKMODA2_RST_WARM_INT_L_GET(x)                                 (((x) & 0x00020000) >> 17)
< #define PHY_ANALOG_PLLCLKMODA2_RST_WARM_INT_L_SET(x)                                 (((x) << 17) & 0x00020000)
< #define PHY_ANALOG_PLLCLKMODA2_RST_WARM_OVR_MSB                                                              18
< #define PHY_ANALOG_PLLCLKMODA2_RST_WARM_OVR_LSB                                                              18
< #define PHY_ANALOG_PLLCLKMODA2_RST_WARM_OVR_MASK                                                     0x00040000
< #define PHY_ANALOG_PLLCLKMODA2_RST_WARM_OVR_GET(x)                                   (((x) & 0x00040000) >> 18)
< #define PHY_ANALOG_PLLCLKMODA2_RST_WARM_OVR_SET(x)                                   (((x) << 18) & 0x00040000)
< #define PHY_ANALOG_PLLCLKMODA2_PLL_KVCO_MSB                                                                  20
< #define PHY_ANALOG_PLLCLKMODA2_PLL_KVCO_LSB                                                                  19
< #define PHY_ANALOG_PLLCLKMODA2_PLL_KVCO_MASK                                                         0x00180000
< #define PHY_ANALOG_PLLCLKMODA2_PLL_KVCO_GET(x)                                       (((x) & 0x00180000) >> 19)
< #define PHY_ANALOG_PLLCLKMODA2_PLL_KVCO_SET(x)                                       (((x) << 19) & 0x00180000)
< #define PHY_ANALOG_PLLCLKMODA2_PLLICP_MSB                                                                    23
< #define PHY_ANALOG_PLLCLKMODA2_PLLICP_LSB                                                                    21
< #define PHY_ANALOG_PLLCLKMODA2_PLLICP_MASK                                                           0x00e00000
< #define PHY_ANALOG_PLLCLKMODA2_PLLICP_GET(x)                                         (((x) & 0x00e00000) >> 21)
< #define PHY_ANALOG_PLLCLKMODA2_PLLICP_SET(x)                                         (((x) << 21) & 0x00e00000)
---
> #define PHY_ANALOG_PLLCLKMODA2_SPARE_MASK                                                            0x0000000f
> #define PHY_ANALOG_PLLCLKMODA2_SPARE_GET(x)                                           (((x) & 0x0000000f) >> 0)
> #define PHY_ANALOG_PLLCLKMODA2_SPARE_SET(x)                                           (((x) << 0) & 0x0000000f)
> #define PHY_ANALOG_PLLCLKMODA2_DACPWD_MSB                                                                     4
> #define PHY_ANALOG_PLLCLKMODA2_DACPWD_LSB                                                                     4
> #define PHY_ANALOG_PLLCLKMODA2_DACPWD_MASK                                                           0x00000010
> #define PHY_ANALOG_PLLCLKMODA2_DACPWD_GET(x)                                          (((x) & 0x00000010) >> 4)
> #define PHY_ANALOG_PLLCLKMODA2_DACPWD_SET(x)                                          (((x) << 4) & 0x00000010)
> #define PHY_ANALOG_PLLCLKMODA2_ADCPWD_MSB                                                                     5
> #define PHY_ANALOG_PLLCLKMODA2_ADCPWD_LSB                                                                     5
> #define PHY_ANALOG_PLLCLKMODA2_ADCPWD_MASK                                                           0x00000020
> #define PHY_ANALOG_PLLCLKMODA2_ADCPWD_GET(x)                                          (((x) & 0x00000020) >> 5)
> #define PHY_ANALOG_PLLCLKMODA2_ADCPWD_SET(x)                                          (((x) << 5) & 0x00000020)
> #define PHY_ANALOG_PLLCLKMODA2_LOCAL_ADDAC_MSB                                                                6
> #define PHY_ANALOG_PLLCLKMODA2_LOCAL_ADDAC_LSB                                                                6
> #define PHY_ANALOG_PLLCLKMODA2_LOCAL_ADDAC_MASK                                                      0x00000040
> #define PHY_ANALOG_PLLCLKMODA2_LOCAL_ADDAC_GET(x)                                     (((x) & 0x00000040) >> 6)
> #define PHY_ANALOG_PLLCLKMODA2_LOCAL_ADDAC_SET(x)                                     (((x) << 6) & 0x00000040)
> #define PHY_ANALOG_PLLCLKMODA2_DAC_CLK_SEL_MSB                                                                8
> #define PHY_ANALOG_PLLCLKMODA2_DAC_CLK_SEL_LSB                                                                7
> #define PHY_ANALOG_PLLCLKMODA2_DAC_CLK_SEL_MASK                                                      0x00000180
> #define PHY_ANALOG_PLLCLKMODA2_DAC_CLK_SEL_GET(x)                                     (((x) & 0x00000180) >> 7)
> #define PHY_ANALOG_PLLCLKMODA2_DAC_CLK_SEL_SET(x)                                     (((x) << 7) & 0x00000180)
> #define PHY_ANALOG_PLLCLKMODA2_ADC_CLK_SEL_MSB                                                               12
> #define PHY_ANALOG_PLLCLKMODA2_ADC_CLK_SEL_LSB                                                                9
> #define PHY_ANALOG_PLLCLKMODA2_ADC_CLK_SEL_MASK                                                      0x00001e00
> #define PHY_ANALOG_PLLCLKMODA2_ADC_CLK_SEL_GET(x)                                     (((x) & 0x00001e00) >> 9)
> #define PHY_ANALOG_PLLCLKMODA2_ADC_CLK_SEL_SET(x)                                     (((x) << 9) & 0x00001e00)
> #define PHY_ANALOG_PLLCLKMODA2_LOCAL_CLKMODA_MSB                                                             13
> #define PHY_ANALOG_PLLCLKMODA2_LOCAL_CLKMODA_LSB                                                             13
> #define PHY_ANALOG_PLLCLKMODA2_LOCAL_CLKMODA_MASK                                                    0x00002000
> #define PHY_ANALOG_PLLCLKMODA2_LOCAL_CLKMODA_GET(x)                                  (((x) & 0x00002000) >> 13)
> #define PHY_ANALOG_PLLCLKMODA2_LOCAL_CLKMODA_SET(x)                                  (((x) << 13) & 0x00002000)
> #define PHY_ANALOG_PLLCLKMODA2_PLLBYPASS_MSB                                                                 14
> #define PHY_ANALOG_PLLCLKMODA2_PLLBYPASS_LSB                                                                 14
> #define PHY_ANALOG_PLLCLKMODA2_PLLBYPASS_MASK                                                        0x00004000
> #define PHY_ANALOG_PLLCLKMODA2_PLLBYPASS_GET(x)                                      (((x) & 0x00004000) >> 14)
> #define PHY_ANALOG_PLLCLKMODA2_PLLBYPASS_SET(x)                                      (((x) << 14) & 0x00004000)
> #define PHY_ANALOG_PLLCLKMODA2_LOCAL_PLLBYPASS_MSB                                                           15
> #define PHY_ANALOG_PLLCLKMODA2_LOCAL_PLLBYPASS_LSB                                                           15
> #define PHY_ANALOG_PLLCLKMODA2_LOCAL_PLLBYPASS_MASK                                                  0x00008000
> #define PHY_ANALOG_PLLCLKMODA2_LOCAL_PLLBYPASS_GET(x)                                (((x) & 0x00008000) >> 15)
> #define PHY_ANALOG_PLLCLKMODA2_LOCAL_PLLBYPASS_SET(x)                                (((x) << 15) & 0x00008000)
> #define PHY_ANALOG_PLLCLKMODA2_PLLATB_MSB                                                                    17
> #define PHY_ANALOG_PLLCLKMODA2_PLLATB_LSB                                                                    16
> #define PHY_ANALOG_PLLCLKMODA2_PLLATB_MASK                                                           0x00030000
> #define PHY_ANALOG_PLLCLKMODA2_PLLATB_GET(x)                                         (((x) & 0x00030000) >> 16)
> #define PHY_ANALOG_PLLCLKMODA2_PLLATB_SET(x)                                         (((x) << 16) & 0x00030000)
> #define PHY_ANALOG_PLLCLKMODA2_PLL_SVREG_MSB                                                                 18
> #define PHY_ANALOG_PLLCLKMODA2_PLL_SVREG_LSB                                                                 18
> #define PHY_ANALOG_PLLCLKMODA2_PLL_SVREG_MASK                                                        0x00040000
> #define PHY_ANALOG_PLLCLKMODA2_PLL_SVREG_GET(x)                                      (((x) & 0x00040000) >> 18)
> #define PHY_ANALOG_PLLCLKMODA2_PLL_SVREG_SET(x)                                      (((x) << 18) & 0x00040000)
> #define PHY_ANALOG_PLLCLKMODA2_HI_FREQ_EN_MSB                                                                19
> #define PHY_ANALOG_PLLCLKMODA2_HI_FREQ_EN_LSB                                                                19
> #define PHY_ANALOG_PLLCLKMODA2_HI_FREQ_EN_MASK                                                       0x00080000
> #define PHY_ANALOG_PLLCLKMODA2_HI_FREQ_EN_GET(x)                                     (((x) & 0x00080000) >> 19)
> #define PHY_ANALOG_PLLCLKMODA2_HI_FREQ_EN_SET(x)                                     (((x) << 19) & 0x00080000)
> #define PHY_ANALOG_PLLCLKMODA2_RST_WARM_INT_L_MSB                                                            20
> #define PHY_ANALOG_PLLCLKMODA2_RST_WARM_INT_L_LSB                                                            20
> #define PHY_ANALOG_PLLCLKMODA2_RST_WARM_INT_L_MASK                                                   0x00100000
> #define PHY_ANALOG_PLLCLKMODA2_RST_WARM_INT_L_GET(x)                                 (((x) & 0x00100000) >> 20)
> #define PHY_ANALOG_PLLCLKMODA2_RST_WARM_INT_L_SET(x)                                 (((x) << 20) & 0x00100000)
> #define PHY_ANALOG_PLLCLKMODA2_RST_WARM_OVR_MSB                                                              21
> #define PHY_ANALOG_PLLCLKMODA2_RST_WARM_OVR_LSB                                                              21
> #define PHY_ANALOG_PLLCLKMODA2_RST_WARM_OVR_MASK                                                     0x00200000
> #define PHY_ANALOG_PLLCLKMODA2_RST_WARM_OVR_GET(x)                                   (((x) & 0x00200000) >> 21)
> #define PHY_ANALOG_PLLCLKMODA2_RST_WARM_OVR_SET(x)                                   (((x) << 21) & 0x00200000)
> #define PHY_ANALOG_PLLCLKMODA2_PLL_KVCO_MSB                                                                  23
> #define PHY_ANALOG_PLLCLKMODA2_PLL_KVCO_LSB                                                                  22
> #define PHY_ANALOG_PLLCLKMODA2_PLL_KVCO_MASK                                                         0x00c00000
> #define PHY_ANALOG_PLLCLKMODA2_PLL_KVCO_GET(x)                                       (((x) & 0x00c00000) >> 22)
> #define PHY_ANALOG_PLLCLKMODA2_PLL_KVCO_SET(x)                                       (((x) << 22) & 0x00c00000)
> #define PHY_ANALOG_PLLCLKMODA2_PLLICP_MSB                                                                    26
> #define PHY_ANALOG_PLLCLKMODA2_PLLICP_LSB                                                                    24
> #define PHY_ANALOG_PLLCLKMODA2_PLLICP_MASK                                                           0x07000000
> #define PHY_ANALOG_PLLCLKMODA2_PLLICP_GET(x)                                         (((x) & 0x07000000) >> 24)
> #define PHY_ANALOG_PLLCLKMODA2_PLLICP_SET(x)                                         (((x) << 24) & 0x07000000)
2632,2635c2715,2718
< #define PHY_ANALOG_PLLCLKMODA2_PLLFILTER_LSB                                                                 24
< #define PHY_ANALOG_PLLCLKMODA2_PLLFILTER_MASK                                                        0xff000000
< #define PHY_ANALOG_PLLCLKMODA2_PLLFILTER_GET(x)                                      (((x) & 0xff000000) >> 24)
< #define PHY_ANALOG_PLLCLKMODA2_PLLFILTER_SET(x)                                      (((x) << 24) & 0xff000000)
---
> #define PHY_ANALOG_PLLCLKMODA2_PLLFILTER_LSB                                                                 27
> #define PHY_ANALOG_PLLCLKMODA2_PLLFILTER_MASK                                                        0xf8000000
> #define PHY_ANALOG_PLLCLKMODA2_PLLFILTER_GET(x)                                      (((x) & 0xf8000000) >> 27)
> #define PHY_ANALOG_PLLCLKMODA2_PLLFILTER_SET(x)                                      (((x) << 27) & 0xf8000000)
2640c2723
< #define PHY_ANALOG_TOP_SPARE_MSB                                                                              1
---
> #define PHY_ANALOG_TOP_SPARE_MSB                                                                              2
2642,2714c2725,2792
< #define PHY_ANALOG_TOP_SPARE_MASK                                                                    0x00000003
< #define PHY_ANALOG_TOP_SPARE_GET(x)                                                   (((x) & 0x00000003) >> 0)
< #define PHY_ANALOG_TOP_SPARE_SET(x)                                                   (((x) << 0) & 0x00000003)
< #define PHY_ANALOG_TOP_TEST_PADQ_EN_MSB                                                                       2
< #define PHY_ANALOG_TOP_TEST_PADQ_EN_LSB                                                                       2
< #define PHY_ANALOG_TOP_TEST_PADQ_EN_MASK                                                             0x00000004
< #define PHY_ANALOG_TOP_TEST_PADQ_EN_GET(x)                                            (((x) & 0x00000004) >> 2)
< #define PHY_ANALOG_TOP_TEST_PADQ_EN_SET(x)                                            (((x) << 2) & 0x00000004)
< #define PHY_ANALOG_TOP_AREG_LVL_MSB                                                                           5
< #define PHY_ANALOG_TOP_AREG_LVL_LSB                                                                           3
< #define PHY_ANALOG_TOP_AREG_LVL_MASK                                                                 0x00000038
< #define PHY_ANALOG_TOP_AREG_LVL_GET(x)                                                (((x) & 0x00000038) >> 3)
< #define PHY_ANALOG_TOP_AREG_LVL_SET(x)                                                (((x) << 3) & 0x00000038)
< #define PHY_ANALOG_TOP_XPAON2_MSB                                                                             6
< #define PHY_ANALOG_TOP_XPAON2_LSB                                                                             6
< #define PHY_ANALOG_TOP_XPAON2_MASK                                                                   0x00000040
< #define PHY_ANALOG_TOP_XPAON2_GET(x)                                                  (((x) & 0x00000040) >> 6)
< #define PHY_ANALOG_TOP_XPAON2_SET(x)                                                  (((x) << 6) & 0x00000040)
< #define PHY_ANALOG_TOP_XPAON5_MSB                                                                             7
< #define PHY_ANALOG_TOP_XPAON5_LSB                                                                             7
< #define PHY_ANALOG_TOP_XPAON5_MASK                                                                   0x00000080
< #define PHY_ANALOG_TOP_XPAON5_GET(x)                                                  (((x) & 0x00000080) >> 7)
< #define PHY_ANALOG_TOP_XPAON5_SET(x)                                                  (((x) << 7) & 0x00000080)
< #define PHY_ANALOG_TOP_TESTIQ_RSEL_MSB                                                                        8
< #define PHY_ANALOG_TOP_TESTIQ_RSEL_LSB                                                                        8
< #define PHY_ANALOG_TOP_TESTIQ_RSEL_MASK                                                              0x00000100
< #define PHY_ANALOG_TOP_TESTIQ_RSEL_GET(x)                                             (((x) & 0x00000100) >> 8)
< #define PHY_ANALOG_TOP_TESTIQ_RSEL_SET(x)                                             (((x) << 8) & 0x00000100)
< #define PHY_ANALOG_TOP_TEST_PADI_EN_MSB                                                                       9
< #define PHY_ANALOG_TOP_TEST_PADI_EN_LSB                                                                       9
< #define PHY_ANALOG_TOP_TEST_PADI_EN_MASK                                                             0x00000200
< #define PHY_ANALOG_TOP_TEST_PADI_EN_GET(x)                                            (((x) & 0x00000200) >> 9)
< #define PHY_ANALOG_TOP_TEST_PADI_EN_SET(x)                                            (((x) << 9) & 0x00000200)
< #define PHY_ANALOG_TOP_PWDV2I_MSB                                                                            10
< #define PHY_ANALOG_TOP_PWDV2I_LSB                                                                            10
< #define PHY_ANALOG_TOP_PWDV2I_MASK                                                                   0x00000400
< #define PHY_ANALOG_TOP_PWDV2I_GET(x)                                                 (((x) & 0x00000400) >> 10)
< #define PHY_ANALOG_TOP_PWDV2I_SET(x)                                                 (((x) << 10) & 0x00000400)
< #define PHY_ANALOG_TOP_PWDBIAS_MSB                                                                           11
< #define PHY_ANALOG_TOP_PWDBIAS_LSB                                                                           11
< #define PHY_ANALOG_TOP_PWDBIAS_MASK                                                                  0x00000800
< #define PHY_ANALOG_TOP_PWDBIAS_GET(x)                                                (((x) & 0x00000800) >> 11)
< #define PHY_ANALOG_TOP_PWDBIAS_SET(x)                                                (((x) << 11) & 0x00000800)
< #define PHY_ANALOG_TOP_PWDBG_MSB                                                                             12
< #define PHY_ANALOG_TOP_PWDBG_LSB                                                                             12
< #define PHY_ANALOG_TOP_PWDBG_MASK                                                                    0x00001000
< #define PHY_ANALOG_TOP_PWDBG_GET(x)                                                  (((x) & 0x00001000) >> 12)
< #define PHY_ANALOG_TOP_PWDBG_SET(x)                                                  (((x) << 12) & 0x00001000)
< #define PHY_ANALOG_TOP_XPABIASLVL_MSB                                                                        14
< #define PHY_ANALOG_TOP_XPABIASLVL_LSB                                                                        13
< #define PHY_ANALOG_TOP_XPABIASLVL_MASK                                                               0x00006000
< #define PHY_ANALOG_TOP_XPABIASLVL_GET(x)                                             (((x) & 0x00006000) >> 13)
< #define PHY_ANALOG_TOP_XPABIASLVL_SET(x)                                             (((x) << 13) & 0x00006000)
< #define PHY_ANALOG_TOP_FORCE_XPAON_MSB                                                                       15
< #define PHY_ANALOG_TOP_FORCE_XPAON_LSB                                                                       15
< #define PHY_ANALOG_TOP_FORCE_XPAON_MASK                                                              0x00008000
< #define PHY_ANALOG_TOP_FORCE_XPAON_GET(x)                                            (((x) & 0x00008000) >> 15)
< #define PHY_ANALOG_TOP_FORCE_XPAON_SET(x)                                            (((x) << 15) & 0x00008000)
< #define PHY_ANALOG_TOP_ATBSELECT_MSB                                                                         16
< #define PHY_ANALOG_TOP_ATBSELECT_LSB                                                                         16
< #define PHY_ANALOG_TOP_ATBSELECT_MASK                                                                0x00010000
< #define PHY_ANALOG_TOP_ATBSELECT_GET(x)                                              (((x) & 0x00010000) >> 16)
< #define PHY_ANALOG_TOP_ATBSELECT_SET(x)                                              (((x) << 16) & 0x00010000)
< #define PHY_ANALOG_TOP_LOCAL_XPA_MSB                                                                         17
< #define PHY_ANALOG_TOP_LOCAL_XPA_LSB                                                                         17
< #define PHY_ANALOG_TOP_LOCAL_XPA_MASK                                                                0x00020000
< #define PHY_ANALOG_TOP_LOCAL_XPA_GET(x)                                              (((x) & 0x00020000) >> 17)
< #define PHY_ANALOG_TOP_LOCAL_XPA_SET(x)                                              (((x) << 17) & 0x00020000)
< #define PHY_ANALOG_TOP_XPABIAS_BYPASS_MSB                                                                    18
< #define PHY_ANALOG_TOP_XPABIAS_BYPASS_LSB                                                                    18
< #define PHY_ANALOG_TOP_XPABIAS_BYPASS_MASK                                                           0x00040000
< #define PHY_ANALOG_TOP_XPABIAS_BYPASS_GET(x)                                         (((x) & 0x00040000) >> 18)
< #define PHY_ANALOG_TOP_XPABIAS_BYPASS_SET(x)                                         (((x) << 18) & 0x00040000)
---
> #define PHY_ANALOG_TOP_SPARE_MASK                                                                    0x00000007
> #define PHY_ANALOG_TOP_SPARE_GET(x)                                                   (((x) & 0x00000007) >> 0)
> #define PHY_ANALOG_TOP_SPARE_SET(x)                                                   (((x) << 0) & 0x00000007)
> #define PHY_ANALOG_TOP_PWDBIAS_MSB                                                                            3
> #define PHY_ANALOG_TOP_PWDBIAS_LSB                                                                            3
> #define PHY_ANALOG_TOP_PWDBIAS_MASK                                                                  0x00000008
> #define PHY_ANALOG_TOP_PWDBIAS_GET(x)                                                 (((x) & 0x00000008) >> 3)
> #define PHY_ANALOG_TOP_PWDBIAS_SET(x)                                                 (((x) << 3) & 0x00000008)
> #define PHY_ANALOG_TOP_FLIP_XPABIAS_MSB                                                                       4
> #define PHY_ANALOG_TOP_FLIP_XPABIAS_LSB                                                                       4
> #define PHY_ANALOG_TOP_FLIP_XPABIAS_MASK                                                             0x00000010
> #define PHY_ANALOG_TOP_FLIP_XPABIAS_GET(x)                                            (((x) & 0x00000010) >> 4)
> #define PHY_ANALOG_TOP_FLIP_XPABIAS_SET(x)                                            (((x) << 4) & 0x00000010)
> #define PHY_ANALOG_TOP_XPAON2_MSB                                                                             5
> #define PHY_ANALOG_TOP_XPAON2_LSB                                                                             5
> #define PHY_ANALOG_TOP_XPAON2_MASK                                                                   0x00000020
> #define PHY_ANALOG_TOP_XPAON2_GET(x)                                                  (((x) & 0x00000020) >> 5)
> #define PHY_ANALOG_TOP_XPAON2_SET(x)                                                  (((x) << 5) & 0x00000020)
> #define PHY_ANALOG_TOP_XPAON5_MSB                                                                             6
> #define PHY_ANALOG_TOP_XPAON5_LSB                                                                             6
> #define PHY_ANALOG_TOP_XPAON5_MASK                                                                   0x00000040
> #define PHY_ANALOG_TOP_XPAON5_GET(x)                                                  (((x) & 0x00000040) >> 6)
> #define PHY_ANALOG_TOP_XPAON5_SET(x)                                                  (((x) << 6) & 0x00000040)
> #define PHY_ANALOG_TOP_XPASHORT2GND_MSB                                                                       7
> #define PHY_ANALOG_TOP_XPASHORT2GND_LSB                                                                       7
> #define PHY_ANALOG_TOP_XPASHORT2GND_MASK                                                             0x00000080
> #define PHY_ANALOG_TOP_XPASHORT2GND_GET(x)                                            (((x) & 0x00000080) >> 7)
> #define PHY_ANALOG_TOP_XPASHORT2GND_SET(x)                                            (((x) << 7) & 0x00000080)
> #define PHY_ANALOG_TOP_XPABIASLVL_MSB                                                                        11
> #define PHY_ANALOG_TOP_XPABIASLVL_LSB                                                                         8
> #define PHY_ANALOG_TOP_XPABIASLVL_MASK                                                               0x00000f00
> #define PHY_ANALOG_TOP_XPABIASLVL_GET(x)                                              (((x) & 0x00000f00) >> 8)
> #define PHY_ANALOG_TOP_XPABIASLVL_SET(x)                                              (((x) << 8) & 0x00000f00)
> #define PHY_ANALOG_TOP_XPABIAS_EN_MSB                                                                        12
> #define PHY_ANALOG_TOP_XPABIAS_EN_LSB                                                                        12
> #define PHY_ANALOG_TOP_XPABIAS_EN_MASK                                                               0x00001000
> #define PHY_ANALOG_TOP_XPABIAS_EN_GET(x)                                             (((x) & 0x00001000) >> 12)
> #define PHY_ANALOG_TOP_XPABIAS_EN_SET(x)                                             (((x) << 12) & 0x00001000)
> #define PHY_ANALOG_TOP_ATBSELECT_MSB                                                                         13
> #define PHY_ANALOG_TOP_ATBSELECT_LSB                                                                         13
> #define PHY_ANALOG_TOP_ATBSELECT_MASK                                                                0x00002000
> #define PHY_ANALOG_TOP_ATBSELECT_GET(x)                                              (((x) & 0x00002000) >> 13)
> #define PHY_ANALOG_TOP_ATBSELECT_SET(x)                                              (((x) << 13) & 0x00002000)
> #define PHY_ANALOG_TOP_LOCAL_XPA_MSB                                                                         14
> #define PHY_ANALOG_TOP_LOCAL_XPA_LSB                                                                         14
> #define PHY_ANALOG_TOP_LOCAL_XPA_MASK                                                                0x00004000
> #define PHY_ANALOG_TOP_LOCAL_XPA_GET(x)                                              (((x) & 0x00004000) >> 14)
> #define PHY_ANALOG_TOP_LOCAL_XPA_SET(x)                                              (((x) << 14) & 0x00004000)
> #define PHY_ANALOG_TOP_XPABIAS_BYPASS_MSB                                                                    15
> #define PHY_ANALOG_TOP_XPABIAS_BYPASS_LSB                                                                    15
> #define PHY_ANALOG_TOP_XPABIAS_BYPASS_MASK                                                           0x00008000
> #define PHY_ANALOG_TOP_XPABIAS_BYPASS_GET(x)                                         (((x) & 0x00008000) >> 15)
> #define PHY_ANALOG_TOP_XPABIAS_BYPASS_SET(x)                                         (((x) << 15) & 0x00008000)
> #define PHY_ANALOG_TOP_TEST_PADQ_EN_MSB                                                                      16
> #define PHY_ANALOG_TOP_TEST_PADQ_EN_LSB                                                                      16
> #define PHY_ANALOG_TOP_TEST_PADQ_EN_MASK                                                             0x00010000
> #define PHY_ANALOG_TOP_TEST_PADQ_EN_GET(x)                                           (((x) & 0x00010000) >> 16)
> #define PHY_ANALOG_TOP_TEST_PADQ_EN_SET(x)                                           (((x) << 16) & 0x00010000)
> #define PHY_ANALOG_TOP_TEST_PADI_EN_MSB                                                                      17
> #define PHY_ANALOG_TOP_TEST_PADI_EN_LSB                                                                      17
> #define PHY_ANALOG_TOP_TEST_PADI_EN_MASK                                                             0x00020000
> #define PHY_ANALOG_TOP_TEST_PADI_EN_GET(x)                                           (((x) & 0x00020000) >> 17)
> #define PHY_ANALOG_TOP_TEST_PADI_EN_SET(x)                                           (((x) << 17) & 0x00020000)
> #define PHY_ANALOG_TOP_TESTIQ_RSEL_MSB                                                                       18
> #define PHY_ANALOG_TOP_TESTIQ_RSEL_LSB                                                                       18
> #define PHY_ANALOG_TOP_TESTIQ_RSEL_MASK                                                              0x00040000
> #define PHY_ANALOG_TOP_TESTIQ_RSEL_GET(x)                                            (((x) & 0x00040000) >> 18)
> #define PHY_ANALOG_TOP_TESTIQ_RSEL_SET(x)                                            (((x) << 18) & 0x00040000)
2886,2895c2964,2973
< #define PHY_ANALOG_XTAL_XTAL_HIGHZ_MSB                                                                       13
< #define PHY_ANALOG_XTAL_XTAL_HIGHZ_LSB                                                                       13
< #define PHY_ANALOG_XTAL_XTAL_HIGHZ_MASK                                                              0x00002000
< #define PHY_ANALOG_XTAL_XTAL_HIGHZ_GET(x)                                            (((x) & 0x00002000) >> 13)
< #define PHY_ANALOG_XTAL_XTAL_HIGHZ_SET(x)                                            (((x) << 13) & 0x00002000)
< #define PHY_ANALOG_XTAL_XTAL_DRVPNR_MSB                                                                      15
< #define PHY_ANALOG_XTAL_XTAL_DRVPNR_LSB                                                                      14
< #define PHY_ANALOG_XTAL_XTAL_DRVPNR_MASK                                                             0x0000c000
< #define PHY_ANALOG_XTAL_XTAL_DRVPNR_GET(x)                                           (((x) & 0x0000c000) >> 14)
< #define PHY_ANALOG_XTAL_XTAL_DRVPNR_SET(x)                                           (((x) << 14) & 0x0000c000)
---
> #define PHY_ANALOG_XTAL_XTAL_SHRTXIN_MSB                                                                     13
> #define PHY_ANALOG_XTAL_XTAL_SHRTXIN_LSB                                                                     13
> #define PHY_ANALOG_XTAL_XTAL_SHRTXIN_MASK                                                            0x00002000
> #define PHY_ANALOG_XTAL_XTAL_SHRTXIN_GET(x)                                          (((x) & 0x00002000) >> 13)
> #define PHY_ANALOG_XTAL_XTAL_SHRTXIN_SET(x)                                          (((x) << 13) & 0x00002000)
> #define PHY_ANALOG_XTAL_XTAL_DRVSTR_MSB                                                                      15
> #define PHY_ANALOG_XTAL_XTAL_DRVSTR_LSB                                                                      14
> #define PHY_ANALOG_XTAL_XTAL_DRVSTR_MASK                                                             0x0000c000
> #define PHY_ANALOG_XTAL_XTAL_DRVSTR_GET(x)                                           (((x) & 0x0000c000) >> 14)
> #define PHY_ANALOG_XTAL_XTAL_DRVSTR_SET(x)                                           (((x) << 14) & 0x0000c000)
