package athrConfig;
use warnings;
use strict;
require Exporter;
require RegCodeGen;
our @ISA = qw(RegCodeGen Exporter);


##----------------------------------------------------------------------------
## initialize
##----------------------------------------------------------------------------
sub initialize {
  my( $this ) = @_;

  no strict 'refs';

  my $file_name = $this->component_to_type_name($this->{target}, 0);
  $this->create_handle($file_name, $file_name.".cfg", "/*", "*/");

  $this->{chandle}            = $file_name;
  $this->{shared_handle}      = undef;
  $this->{ctype}              = undef;
  $this->{dtypes}             = {};
  $this->{dtypes}->{order}    = [];
  $this->{reg_eff_width}      = 0;
  $this->{filename}           = "";

  $this->block_iterate("reg");

  $this->SUPER::initialize();
}

##----------------------------------------------------------------------------
## gen
##----------------------------------------------------------------------------
sub gen {
  my( $this ) = @_;

  $this->SUPER::gen();

  my $data_type_pad    = {};
  my $includes         = {};
  my $handled_includes = {};

  my $type_name  = $this->component_to_type_name($this->{target}, 0);
  $this->{ctype} = $this->{dtypes}->{$type_name};

  foreach my $dtype (@{$this->{dtypes}->{order}}) { # $this->{dtypes}->{order} = array of struct type info
    $this->{ctype} = $this->{dtypes}->{$dtype};     # $this->{dtypes}          = hash of struct type info
    my $h          = $this->{ctype}->{handle};
    $this->write($this->{ctype}->{body}, $h);
  }

  $this->write_output();

  if ($this->{filename} ne "" ) { #&& $this->{file_depth} <= 0) {
    my $file_name = $this->{filename}.$type_name;

    my $fullname = $file_name.".cfg";
    my $linkname = $this->{filename}.".cfg";
    my $outdir =  $this->{compiler}->output_path();
    system("cd $outdir; rm -rf $linkname; ln -s $fullname $linkname") if ($this->{filename} ne ""); # && (-f $linkname));
    print "generated [".ref($this)."] \"$linkname\" link to \"$fullname\" in ".$this->{compiler}->output_path()."\n";
  }

}

##----------------------------------------------------------------------------
## gen_component
##----------------------------------------------------------------------------
sub gen_component {
  my( $this, $comp, $assign, $path ) = @_;

  if( $comp->type() eq "reg" ) {
    $this->gen_local_instances($comp, $assign, $path);
    return;
  }

  return if( $comp->type() eq "signal" );
  return if( $comp->type() eq "field" );
  return if( $comp->type() eq "attribute" );
  my $type_name = $this->component_to_type_name($comp, 0);

  # Skip any component whose code has already been generated
  return if( exists $this->{dtypes}->{$type_name} );

  $this->{dtypes}->{$type_name}->{body}        = "";
  $this->{dtypes}->{$type_name}->{handle}      = $this->{chandle};
  $this->{dtypes}->{$type_name}->{addr}        = 0;
  $this->{dtypes}->{$type_name}->{comp}        = $comp;

  # this->{ctype} holder for currect struct being iterated
  my $save_ctype = $this->{ctype};
  $this->{ctype} = $this->{dtypes}->{$type_name};

  $this->SUPER::gen_component($comp, $assign, $path);

  push @{$this->{dtypes}->{order}}, $type_name;

  $this->{ctype}         = $save_ctype;
}

##----------------------------------------------------------------------------
## gen_reg_inst
##----------------------------------------------------------------------------
sub gen_reg_inst {
  my( $this, $assign, $path ) = @_;

  my $inst      = $path->instance();
  my $icomp     = $inst->type();

  my $reg_data_type = "volatile unsigned int";

  my $reset_val;
  foreach my $field_inst ($icomp->instances()) {
    if (defined($field_inst->reset())) {
      $reset_val = $this->vnum_to_dec($field_inst->reset());
      $reset_val = sprintf("0x%-5x", ($reset_val =~ /^0x/) ? hex($reset_val) : $reset_val);
    } else {
      $reset_val = 'NA     ';
    }
    my $line = sprintf(" %-50s %s %-20s 0x%-6x %-6s 0 %d %d 2 1\n",
      lc($inst->name()."_".$field_inst->name()),
      $reset_val,
      uc($inst->name()),
      (defined($this->{ctype}->{comp}->desc())) ? hex($this->{ctype}->{comp}->desc()) + $inst->addr() : $inst->addr(),
      $field_inst->msb().(($field_inst->num() > 1) ? ":".$field_inst->lsb() : ""),
      $field_inst->type()->sw_w(),
      $field_inst->type()->sw_r());
    $this->{ctype}->{body} .= $line;
  }
  $this->{ctype}->{body} .= "\n";
}

##----------------------------------------------------------------------------
## vnum_to_dec  -- verilog style number to decimal converter
##----------------------------------------------------------------------------
sub vnum_to_dec {
  my( $this, $vnum ) = @_;

  if( $vnum =~ /\'h/ ) {
    $vnum =~ s/([0-9])*\'h/0x/;
  } elsif( $vnum =~ /\'d/ ) {
    $vnum =~ s/([0-9])*\'d//;
  } elsif( $vnum =~ /\'b/ ) {
    $vnum =~ s/([0-9])*\'b//;
    $vnum =~ s/_//;
    my @vnum = split(//, $vnum);
    $vnum = 0;
    foreach my $n (@vnum) {
      $vnum <<= 1;
      $vnum++ if( $n == 1 );
    }
  }
  return lc($vnum);
}

##----------------------------------------------------------------------------
## component_to_type_name
##----------------------------------------------------------------------------
sub component_to_type_name {
  my( $this, $comp, $append_type ) = @_;

  $append_type = 1 if( !defined $append_type );

  my $type_name = $comp->name();
  $type_name   .= "__".$comp->type() if( $append_type );

  my $pcomp = $comp->parent();
  while( $pcomp ) {
    $type_name = $pcomp->name()."__".$type_name if ($pcomp->name() ne "BlueprintGlobalNameSpace");
    $pcomp = $pcomp->parent();
  }

  return $type_name;
}

1;

