package ansicReg;
use warnings;
use strict;
require Exporter;
require RegCodeGen;
our @ISA = qw(RegCodeGen Exporter);


##----------------------------------------------------------------------------
## initialize
##----------------------------------------------------------------------------
sub initialize {
  my( $this ) = @_;

  no strict 'refs';

  #comment /subswitch
  my $commstr = "main::CL_".ref($this)."_comment";
  $this->{comment} = defined $$commstr;


  # depth optional cmd line arg
  $this->{file_depth}    = 0;
  my $depthstr = "main::CL_".ref($this)."_depth";
  $this->{file_depth}    = $$depthstr->[0]
    if( defined $$depthstr  );

  # filename optional cmd line arg
  $this->{filename}   = "";
  my $filenamestr = "main::CL_".ref($this)."_filename";
  $this->{filename}   = $$filenamestr->[0]
    if( defined $$filenamestr );

  # effwidth optional cmd line arg
  $this->{reg_eff_width} = 0;
  my $effwidthstr = "main::CL_".ref($this)."_effwidth";
  if( defined $$effwidthstr ) {
      $this->{reg_eff_width} = $$effwidthstr->[0];
      my $n = int($this->{reg_eff_width} / 8);
      if( ($n * 8) != $this->{reg_eff_width} ) {
          printf("error: ansic was passed an effective width (-effwidth $this->{reg_eff_width}) that was not divisible by 8\n");
          exit(1);
      }
  }

  # trunc optional cmd line arg
  $this->{trunc}  = 0;
  my $truncstr    = "main::CL_".ref($this)."_trunc";
  $this->{trunc}  = $$truncstr->[0]
    if( defined $$truncstr  );
  $this->warning("define name uniqueness for components isn't guarenteed using this option.
                  user must guarentee this uniqueness by uniquifying addrmap/regfile/reg declaration names in RDL") if( defined $$truncstr  );


  # Initialize ANSI-C class variables

  my $type_name = $this->component_to_type_name($this->{target}, 0);
  my $file_name = $this->{filename}.$type_name;



  $this->create_handle($type_name, $file_name.".h", "/*", "*/");

  $this->{chandle}            = $type_name;
  $this->{shared_handle}      = undef;
  $this->{ctype}              = undef;
  $this->{dtypes}             = {};
  $this->{dtypes}->{order}    = [];

  $this->block_iterate("addrmap", "regfile", "reg", "field");

  $this->SUPER::initialize();
}

##----------------------------------------------------------------------------
## gen
##----------------------------------------------------------------------------
sub gen {
  my( $this ) = @_;

  $this->SUPER::gen();

  my $data_type_pad    = {};
  my $includes         = {};
  my $handled_includes = {};

  my $type_name  = $this->component_to_type_name($this->{target}, 0);
  $this->{ctype} = $this->{dtypes}->{$type_name};
  $this->{ctype}->{macro} .= "\n";
  $this->{ctype}->{reg_macros} = {};

  foreach my $dtype (@{$this->{dtypes}->{order}}) { # $this->{dtypes}->{order} = array of struct type info
    $this->{ctype} = $this->{dtypes}->{$dtype};     # $this->{dtypes}          = hash of struct type info
    my $h          = $this->{ctype}->{handle};

    $this->write($this->{ctype}->{macro}, $h);

    $this->write("\n#ifndef __ASSEMBLER__\n\n",$h);
    $this->write("typedef struct $dtype"."_reg_s {\n", $h);
    $this->write($this->{ctype}->{body}, $h);
    $this->write("} $dtype"."_reg_t;\n\n", $h);
    $this->write("#endif /* __ASSEMBLER__ */\n\n", $h);
  }

  $this->write_output();

  if ($this->{filename} ne "" ) { #&& $this->{file_depth} <= 0) {
    my $file_name = $this->{filename}.$type_name;

    my $fullname = $file_name.".h";
    my $linkname = $this->{filename}.".h";
    my $outdir =  $this->{compiler}->output_path();
    system("cd $outdir; rm -rf $linkname; ln -s $fullname $linkname") if ($this->{filename} ne ""); # && (-f $linkname));
    print "generated [".ref($this)."] \"$linkname\" link to \"$fullname\" in ".$this->{compiler}->output_path()."\n";
  }

}

##----------------------------------------------------------------------------
## gen_component
##----------------------------------------------------------------------------
sub gen_component {
  my( $this, $comp, $assign, $path ) = @_;

  if( $comp->type() eq "reg" ) {
    $this->gen_local_instances($comp, $assign, $path);
    return;
  }

  return if( $comp->type() eq "signal" );
  return if( $comp->type() eq "field" );
  return if( $comp->type() eq "attribute" );
  my $type_name = $this->component_to_type_name($comp, 0);

  # Skip any component whose code has already been generated
  return if( exists $this->{dtypes}->{$type_name} );

  $this->{dtypes}->{$type_name}->{body}        = "";
  $this->{dtypes}->{$type_name}->{macro}       = "";
  $this->{dtypes}->{$type_name}->{handle}      = $this->{chandle};
  $this->{dtypes}->{$type_name}->{addr}        = 0;
  $this->{dtypes}->{$type_name}->{pad_idx}     = 0;
  $this->{dtypes}->{$type_name}->{pad_ver}     = [0];
  $this->{dtypes}->{$type_name}->{requires}    = {};
  $this->{dtypes}->{$type_name}->{comp}        = $comp;
  $this->{dtypes}->{$type_name}->{reg_width}   = 0;

  # this->{ctype} holder for currect struct being iterated
  my $save_ctype = $this->{ctype};
  $this->{ctype} = $this->{dtypes}->{$type_name};

  $this->SUPER::gen_component($comp, $assign, $path);

  my $eff_width_pad = $comp->actual_addr_width() - $this->{ctype}->{addr};
  $this->gen_inst_line($eff_width_pad) if( $eff_width_pad > 0 );

  push @{$this->{dtypes}->{order}}, $type_name;

  $this->{ctype}         = $save_ctype;
}

##----------------------------------------------------------------------------
## gen_addrmap_inst
##----------------------------------------------------------------------------
sub gen_addrmap_inst {
  my( $this, $assign, $path ) = @_;

  my $iass       = $this->curr_inst_assignments($assign, $path);
  my $inst       = $path->instance();
  my $icomp      = $inst->type();
  my $type_name  = $this->component_to_type_name($icomp, 0);
  my $ctxt_hndl  = $this->{chandle};
  my $addr_width = $icomp->actual_addr_width();


  if( $this->{file_depth} >= $path->length() ) {
    if( !exists $this->{dtypes}->{$type_name} ) {
      my $file_name = $this->{filename}.$type_name;
      $this->create_handle($type_name, $file_name.".h", "/*", "*/");
      $this->create_handle($type_name."_macro",$file_name."_macro.h",
                           "/*", "*/");
    }

    $this->{chandle} = $type_name;
  }

  # Generate used global components

# if( !defined $icomp->parent() && !exists $this->{dtypes}->{$type_name} ) {
  if( $icomp->parent()->name() eq "BlueprintGlobalNameSpace"  && !exists $this->{dtypes}->{$type_name} ) {
    $this->gen_component($icomp, $assign, $path);
  }

  if( ($this->{dtypes}->{$type_name}->{handle} ne $this->{chandle}) &&
      ($this->{dtypes}->{$type_name}->{handle} ne $type_name) )
  {
    $this->create_global_data_type($type_name);
  }

  # encapsulating struct, $this->{ctype}, will require this struct
  $this->{ctype}->{requires}->{$type_name} = $this->{dtypes}->{$type_name};

  $this->{chandle} = $ctxt_hndl;

  # pad_cnt = reg inst address - prev address 
  #              ( prev address - 1st reg: address of comp encapsulating this inst 
  #                             - else:    address after prev pad/reg )
  my $pad_cnt = $inst->addr() - $this->{ctype}->{addr};

  $this->gen_inst_line($pad_cnt) if( $pad_cnt );

  my @icomp_insts = $icomp->instances();
  my $first_inst   = $icomp_insts[0];
  my $first_icomp  = $first_inst->type();
  my $last_inst   = $icomp_insts[scalar(@icomp_insts) - 1];
  my $last_icomp  = $last_inst->type();
  my $addr_adj;

  if( $inst->num() == 1 ) {
    $addr_adj       = $addr_width;

    if( $last_inst->num() > 1 && $last_icomp->type() ne "reg" ) {
      $addr_adj    += $last_inst->incr() - $last_icomp->actual_addr_width();
    }
  } else {
    $addr_adj = $inst->incr() * $inst->num();
  }

  if( !defined $icomp->parent() ) {
    $this->write_macro("RFILE_INST_".uc($path->str("__")."__ADDR"),
                       sprintf("0x%xULL", $this->{ctype}->{addr}));

    $this->write_macro("RFILE_INST_".uc($path->str("__")."__END_ADDR"),
                       sprintf("0x%xULL", ($this->{ctype}->{addr} +
                                          $addr_width)));
  }

  $this->write_macro("RFILE_INST_".uc($path->str("__")."__NUM"), $inst->num());

  my $pad_width = $inst->incr() - $addr_width;

  # subtract any explicit offset set on $first_inst since $addr_width does not include this
  $pad_width = $inst->incr() - ($addr_width + $first_inst->addr()) if ($first_inst->addrSetByUser());
  # if last_inst was a regfile/addrmap array get rid of the alignment padding of the last index
  $pad_width   -= $last_inst->incr() - $last_icomp->actual_addr_width()
      if( $last_inst->num() > 1 && $last_icomp->type() ne "reg" );
  my $align_pad         = 0;
  if( defined $this->{dtypes}->{$type_name}->{reg_width} ) {
      my $max_reg_width = $this->{dtypes}->{$type_name}->{reg_width};
      $align_pad        = ($addr_width % ($max_reg_width/8))
          if( $max_reg_width );
  }

  if( $inst->num() > 1 && $pad_width ) {
    $pad_width += $align_pad if( $align_pad != 0 );

    push @{$this->{dtypes}->{$type_name}->{pad_ver}}, $pad_width;
    $type_name = sprintf("%s__post_pad_0x%x", $type_name, $pad_width);
  } elsif( $align_pad != 0 ) {
    push @{$this->{dtypes}->{$type_name}->{pad_ver}}, $align_pad;
    $type_name = sprintf("%s__post_pad_0x%x", $type_name, $align_pad);
  }


  $this->gen_inst_line("struct ".$type_name, $inst->name(), $inst->num(),
                       $addr_adj + $align_pad );
}

##----------------------------------------------------------------------------
## gen_regfile_inst
##----------------------------------------------------------------------------
sub gen_regfile_inst {
  my( $this, $assign, $path ) = @_;
  $this->gen_addrmap_inst($assign, $path);
}

##----------------------------------------------------------------------------
## gen_reg_inst
##----------------------------------------------------------------------------
sub gen_reg_inst {
  my( $this, $assign, $path ) = @_;

  my $iass      = $this->curr_inst_assignments($assign, $path);
  my $inst      = $path->instance();
  my $icomp     = $inst->type();
  my $handle    = $this->{ctype}->{handle};
  my $type_name = $this->component_to_type_name($icomp, 0);
  my $reg_width = $this->reg_eff_width($icomp) / 8;

  my $reg_data_type = $this->reg_data_type($inst);

  # pad_cnt = reg inst address - prev address 
  #              ( prev address - 1st reg: address of comp encapsulating this inst 
  #                             - else:    address after prev pad/reg )
  my $pad_cnt = $inst->addr() - $this->{ctype}->{addr};

  $this->gen_inst_line($pad_cnt) if( $pad_cnt );

  my $addr_adj = $inst->incr() * $inst->num();
  $addr_adj    = $reg_width  if( $inst->num() == 1 );

  my $pre_pad  = 0;

  # Since this is a big-endian memory structure we need to pre-pad here
  if( $reg_width < ($icomp->width() / 8) ) {
    my @insts    = $icomp->instances();
    my $max_inst = $insts[scalar(@insts) - 1];
    my $msb_diff = $icomp->width() - $max_inst->msb();
    $pre_pad     = int($msb_diff / 8);
    $pre_pad     = ($icomp->width() / 8) - $reg_width
      if( (($icomp->width() / 8) - $reg_width) < $pre_pad );
  }

  # create a struct = { uint_x, pad } i.e. {arysize'{reg, gap}}
  #  to account for mem gaps between regs in an array
  if( ($reg_width < $inst->incr()) && ($inst->num() > 1) ) {
    my $pad_size   = $inst->incr() - $reg_width;
    my $post_pad   = $pad_size - $pre_pad;
    my $gbl_type   = $reg_data_type;
    $gbl_type     .= sprintf("__pre_pad_0x%x",  $pre_pad)  if($pre_pad);
    $gbl_type     .= sprintf("__post_pad_0x%x", $post_pad) if($post_pad > 0);

    if( !exists $this->{dtypes}->{$gbl_type} ) {
      $this->{dtypes}->{$gbl_type}->{body}     = "";
      $this->{dtypes}->{$gbl_type}->{macro}    = "";
      $this->{dtypes}->{$gbl_type}->{handle}   = $this->{chandle};
      $this->{dtypes}->{$gbl_type}->{addr}     = 0;
      $this->{dtypes}->{$gbl_type}->{pad_idx}  = 0;
      $this->{dtypes}->{$gbl_type}->{pad_ver}  = [0];
      $this->{dtypes}->{$gbl_type}->{requires} = {};


      $this->gen_inst_line($pre_pad)  if( $pre_pad );
      $this->gen_inst_line($reg_data_type, "data", 1, 0);
      $this->gen_inst_line($post_pad) if( $post_pad > 0 );

      $this->create_global_data_type($gbl_type);
      push @{$this->{dtypes}->{order}}, $gbl_type; # dtypes list also accounts for special
                                                   # struct of gap + reg (..or pad + uint)
      # encapsulating struct, $this->{ctype}, will require this struct
      $this->{ctype}->{requires}->{$gbl_type} = $this->{dtypes}->{$gbl_type};

    }

    $reg_data_type = "struct ".$gbl_type;

  } else {
    $this->gen_inst_line($pre_pad) if( $pre_pad );
    $reg_data_type = "volatile unsigned int";
  }

  if ( $this->{comment} ) {
    if ($inst->desc()) {
      $this->{ctype}->{macro} .= "\n/* macros for ".$path->str()."\n   desc = ".$inst->desc()." */\n";
    }   else {
      $this->{ctype}->{macro} .= "\n/* macros for ".$path->str()."\n   desc = NONE PROVIDED */\n";
    }
  } else {
    $this->{ctype}->{macro} .= "\n/* macros for ".$path->str()." */\n";
  };

  $this->gen_reg_macro($inst);

  $this->gen_inst_line($reg_data_type, $inst->name(), $inst->num(), $addr_adj);

  $this->gen_component($icomp, $assign, $path);
}

##----------------------------------------------------------------------------
## gen_field_inst
##----------------------------------------------------------------------------
sub gen_field_inst {
  my( $this, $assign, $path ) = @_;

  my $inst    = $path->instance();
  my $iass    = $this->curr_inst_assignments($assign, $path);
  my $encode  = $inst->encode($iass, $path);

  return if( !defined $encode );

  my $icomp   = $inst->type();
  my $handle  = $this->{chandle}."_macro";
  my $prefix  = uc($path->str("__")."__".$encode->name());

  $this->write_macro("FIELD_INST_".uc($path->str("__")."__NUM"), $inst->num());

  if(!exists $this->{done}->{"encoding_".$prefix} ) {
    $this->{done}->{"encoding_".$prefix} = 1;

  if ( $this->{comment} ) {
    $this->{ctype}->{macro} .= sprintf("\n/* encoding macros for %s\n   desc =",
                                       $path->str("::"));
    if ( $inst->desc() ) {
      $this->{ctype}->{macro} .= " ".$inst->desc()." */\n";
    } else {
      $this->{ctype}->{macro} .= " NONE PROVIDED */\n";
    };
  } else {
    $this->{ctype}->{macro} .= sprintf("\n/* encoding macros for %s */\n",
                                       $path->str("::"));
  };



#   $this->{ctype}->{macro} .= sprintf("#ifndef _ENCODING_%s_\n", uc($prefix));
#   $this->{ctype}->{macro} .= sprintf("#define _ENCODING_%s_\n", uc($prefix));

    my $encwidth;
    foreach my $enc ($encode->encodings()) {
      my $encval  = $enc->value();
      my $encname = $enc->name();

      my $encdesc = $enc->desc();
      if ( !$encdesc ) {
        $encdesc = "NONE PROVIDED";
      };

      $encwidth = $this->vnum_to_dec(\$encval) if( $encval =~ m/\'/ );
      $encval   = hex($encval)                 if( $encval =~ m/^0x/ );

      if ( $this->{comment} ) {
        $this->{ctype}->{macro} .= sprintf("/* encoding desc = $encdesc */\n");
        $this->write_macro($prefix."__".uc($encname), $encval);
        $this->{ctype}->{macro} .= sprintf("\n");
      } else {
        $this->write_macro($prefix."__".uc($encname), $encval);
      };
    }

    $this->write_macro($prefix."__ENCODING_WIDTH", $encwidth)
      if( defined $encwidth );

    if ( $this->{comment} ) {
      $this->{ctype}->{macro} .= sprintf("\n/* encoding macros for %s\n   desc =",
                                         $path->str("::"));
    if ( $inst->desc() ) {
      $this->{ctype}->{macro} .= " ".$inst->desc()." */\n";
    } else {
      $this->{ctype}->{macro} .= " NONE PROVIDED */\n";
    };
  } else {
    $this->{ctype}->{macro} .= sprintf("\n/* encoding macros for %s */\n",
                                       $path->str("::"));
  };

#   $this->{ctype}->{macro} .= sprintf("#endif /* _ENCODING_%s_ */\n\n",
#                              uc($prefix));
  }
}

##----------------------------------------------------------------------------
## gen_addrmap_def
##----------------------------------------------------------------------------
sub gen_addrmap_def {
  my( $this, $comp, $assign, $path ) = @_;

  $this->gen_component($comp, $assign, $path);
}

##----------------------------------------------------------------------------
## gen_regfile_def
##----------------------------------------------------------------------------
sub gen_regfile_def {
  my( $this, $comp, $assign, $path ) = @_;

  $this->gen_component($comp, $assign, $path);
}

##----------------------------------------------------------------------------
## vnum_to_dec  -- verilog style number to decimal converter
##----------------------------------------------------------------------------
sub vnum_to_dec {
  my( $this, $vnum ) = @_;

  if( $$vnum =~ m/\'h/ ) {
    $$vnum =~ s/([0-9])*\'h/0x/;
    $$vnum = hex($$vnum);
    return $1;
  } elsif( $$vnum =~ m/\'d/ ) {
    $$vnum =~ s/([0-9])*\'d//;
    return $1;
  } elsif( $$vnum =~ m/\'b/ ) {
    $$vnum =~ s/([0-9])*\'b//;
    my $width = $1;

    my @vnum = split(//, $$vnum);
    $$vnum   = 0;

    foreach my $n (@vnum) {
      $$vnum <<= 1;
      $$vnum++ if( $n == 1 );
    }

    return $width;
  }

  return undef;
}

##----------------------------------------------------------------------------
## reg_eff_width
##----------------------------------------------------------------------------
sub reg_eff_width {
  my( $this, $comp ) = @_;
  my $comp_width = $comp->width();

  return $comp_width if( $this->{reg_eff_width} == 0 );

  my @insts      = $comp->instances();
  my $max_inst   = $insts[scalar(@insts) - 1];
  my $max_byte   = int($max_inst->msb() / 8);
  my $width_byte = int($comp_width / 8);
  my $min_width  = $this->{reg_eff_width};
  $min_width     = $width_byte * 8 if( ($width_byte * 8) < $min_width );

  return $min_width if( $max_byte == 0 );

  my $ret_width  = $comp_width;

  while( $max_byte < ($width_byte / 2) ) {
      $ret_width  /= 2;
      $width_byte /= 2;
  }

  return $min_width if( $ret_width < $min_width );
  return $ret_width;
}

##----------------------------------------------------------------------------
## reg_data_type
##----------------------------------------------------------------------------
sub reg_data_type {
  my( $this, $inst ) = @_;

  my $width = $this->reg_eff_width($inst->type());
  $this->{ctype}->{reg_width} = $width if( $width > $this->{ctype}->{reg_width} );
  return "uint".$width."_t";
}

##----------------------------------------------------------------------------
## gen_field_read_macro
##----------------------------------------------------------------------------
sub gen_field_read_macro {
  my( $this, $field_macro, $inst, $mask, $type ) = @_;

  my $lsb = $inst->lsb();
  my $rhs = "(x) & $mask";
  $rhs    = "(($rhs) >> $lsb)";

  $this->write_macro($field_macro."_GET(x)", $rhs);
}

##----------------------------------------------------------------------------
## gen_field_write_macro
##----------------------------------------------------------------------------
sub gen_field_write_macro {
  my( $this, $field_macro, $inst, $mask, $type ) = @_;

  my $lsb = $inst->lsb();
  my $rhs = "(x)";
  $rhs    = "($rhs << $lsb)";
  $rhs    = "($rhs & $mask)";

  $this->write_macro($field_macro."_SET(x)", $rhs);
}

##----------------------------------------------------------------------------
## gen_reg_macro
##----------------------------------------------------------------------------
sub gen_reg_macro {
  my( $this, $inst ) = @_;

  my $comp           = $inst->type();
#  my $type_name      = $this->component_to_type_name($comp, 0);
#  my $macro          = uc($this->component_to_macro_name($comp, 0));
  my $byte_width     = int($this->reg_eff_width($comp) / 8);
  my $hex            = "0x%0".(2 * $byte_width)."x";
  my $addr           = sprintf("$hex", $this->{ctype}->{addr});

#  return if ( exists $this->{ctype}->{reg_macros}->{$type_name} );
#  $this->{ctype}->{reg_macros}->{$type_name} = "$macro";

  $this->write_macro(uc($inst->name())."_ADDRESS", $addr);
  $this->write_macro(uc($inst->name())."_OFFSET", $addr);

  foreach my $field_inst ($comp->instances()) {
    my $field_comp   = $field_inst->type();
    my $field_mask   = $this->gen_mask($field_inst->num(), $field_inst->lsb());
    my $hex_str      = sprintf("$hex", $field_mask);
    my $field_macro  = uc($inst->name())."_".uc($field_inst->name());

    $this->write_macro($field_macro."_MSB", $field_inst->msb());
    $this->write_macro($field_macro."_LSB", $field_inst->lsb());
    $this->write_macro($field_macro."_MASK", $hex_str);

    $this->gen_field_read_macro($field_macro, $field_inst, $hex_str, 0)
      if( $field_comp->sw_r() );

    $this->gen_field_write_macro($field_macro, $field_inst, $hex_str, 0)
      if( $field_comp->sw_w() );
  }
}


##----------------------------------------------------------------------------
## move_to_shared
##----------------------------------------------------------------------------
sub move_to_shared {
  my( $this, $type_name ) = @_;

  $this->{dtypes}->{$type_name}->{handle} = $this->{shared_handle};
  # "requires" - hash of structs used by "$type_name" struct
  foreach my $req (keys(%{$this->{dtypes}->{$type_name}->{requires}})) {
    $this->move_to_shared($req)
      if ( $this->{dtypes}->{$req}->{handle} ne $this->{shared_handle} );
  }
}


##----------------------------------------------------------------------------
## gen_inst_line
##----------------------------------------------------------------------------
sub gen_inst_line {
  my( $this, $type_name, $inst_name, $inst_num, $addr_adj ) = @_;

  my $inst_num_str = $inst_num;
  my $const        = 0;
  my $zero_addr    = 0;
  if( !defined $addr_adj ) {
    $const        = 1 if( defined $inst_name && $inst_name == 1 );
    $zero_addr    = 1 if( defined $inst_num  && $inst_num  == 1 );
    my $pad_idx   = $this->{ctype}->{pad_idx};
    $pad_idx      = 0 if( $zero_addr );

    $addr_adj     = $type_name; # only argument passed would be addr_adj
    $inst_num     = $type_name; # addr_adj == inst_num
    $type_name    = "volatile char";
    $inst_name    = sprintf("pad__%d", $pad_idx);
    $this->{ctype}->{pad_idx}++ if( !$const );
    $inst_num_str = sprintf("0x%x", $inst_num);
  }

  my $base_addr     = $this->{ctype}->{addr};
  $base_addr        = 0 if( $zero_addr );

  my $curr_addr_str = sprintf("0x%x", $base_addr);
  my $addr_adj_str  = sprintf("0x%x", $base_addr + $addr_adj);

  my $curr_addr_pad = 10 - length($curr_addr_str);
  my $addr_adj_pad  = 10 - length($addr_adj_str);


  #SWS to support desc
  #my $desc = $this->{target}->desc($this);
  #print "DESC=$desc\n";

  #  print $this;

  #  my $name = $this->{target}->desc_name($this);
  #  print "DESC_NAME=$name\n";


  my $comment = "/* ";
  $comment   .= (" ")x$curr_addr_pad if( $curr_addr_pad );
  $comment   .= "$curr_addr_str - $addr_adj_str";
  $comment   .= (" ")x$addr_adj_pad  if( $addr_adj_pad  );
  $comment   .= " */";

  my $stmt    = "  $type_name $inst_name";
  $stmt      .= "[".$inst_num_str."]" if( $inst_num > 1 );

  my $line;
  my $comment_pad_len  = 99 - length($stmt) - length($comment);
  if( $comment_pad_len > 0 ) {
    my $comment_pad = (" ")x$comment_pad_len;
    $line           = $stmt.";".$comment_pad.$comment."\n";
  } else {
    $comment_pad_len = 100 - length($comment);
    $line            = $stmt.";\n".(" ")x$comment_pad_len.$comment."\n";
  }

  # SWS
  # print "LINE = $line\n";

  return $line if( $const );

  $this->{ctype}->{addr} += $addr_adj;
  $this->{ctype}->{body} .=  $line;
}

##----------------------------------------------------------------------------
## write_macro
##----------------------------------------------------------------------------
sub write_macro {
  my( $this, $macro, $val ) = @_;

  my $def     = "#define $macro ";
  my $pad_len = 100 - length($def) - length($val);
  my $pad     = "";

  if( $pad_len > 0 ) {
    $pad = (" ")x$pad_len;
    $this->{ctype}->{macro} .= "$def$pad$val\n";
  } elsif( $pad_len == 0 ) {
    $this->{ctype}->{macro} .= "$def$val\n";
  } else {
    my $def_pad_len = 20;
    my $def_pad     = (" ")x$def_pad_len;
    my @val         = split(/\s+/, $val);
    $val            = "\\\n".$def_pad.shift @val;
    my $val_len     = length($val) + $def_pad_len;

    foreach my $v (@val) {
      my $v_len = length($v);
      if( ($val_len + $v_len + $def_pad_len) < 99 ) {
        $val_len += $v_len + 1;
        $val     .= " $v";
      } else {
        $val_len  = $def_pad_len + $v_len;
        $val     .= "\\\n$def_pad$v";
      }
    }

    $this->{ctype}->{macro} .= "$def$val\n";
  }
}

##----------------------------------------------------------------------------
## create_global_data_type
##----------------------------------------------------------------------------
sub create_global_data_type {
  my( $this, $type ) = @_;

  if( !defined $this->{shared_handle} ) {
    my $shared_handle      = $this->{target}->name()."__shared";
    $this->{shared_handle} = $shared_handle;
    my $file_name          = $this->{filename}.$shared_handle;
    $this->create_handle($shared_handle, $file_name.".h", "/*", "*/");
    $this->create_handle($shared_handle."_macro", $file_name."_macro.h",
                         "/*", "*/");
  }

  $this->move_to_shared($type);
}

##----------------------------------------------------------------------------
## component_to_type_name
##----------------------------------------------------------------------------
sub component_to_type_name {
  my( $this, $comp, $append_type ) = @_;

  $append_type = 1 if( !defined $append_type );

  my $type_name = $comp->name();
  $type_name   .= "__".$comp->type() if( $append_type );

  my $pcomp = $comp->parent();
  while( $pcomp ) {
    $type_name = $pcomp->name()."__".$type_name if ($pcomp->name() ne "BlueprintGlobalNameSpace");
    $pcomp = $pcomp->parent();
  }

  return $type_name;
}


##----------------------------------------------------------------------------
## component_to_macro_name - component_to_type_name but name trunc feature
##----------------------------------------------------------------------------
sub component_to_macro_name {
  my( $this, $comp, $append_type ) = @_;

  $append_type = 1 if( !defined $append_type );

  my $macro_name = $comp->name();
  $macro_name   .= "__".$comp->type() if( $append_type );

  my $scopelevels = 0;
  my @parents;
  my $pcomp = $comp->parent();
  while( $pcomp ) {
    $scopelevels++;
    push @parents, $pcomp->name();
    #$macro_name = $pcomp->name()."__".$macro_name if ($pcomp->name() ne "BlueprintGlobalNameSpace");
    $pcomp = $pcomp->parent();
  }

  # truncate the macros name
  for( my $i = 0; $i < ($scopelevels - $this->{trunc}); $i++ ) {
    $macro_name = $parents[$i]."__".$macro_name if ($parents[$i] ne "BlueprintGlobalNameSpace");
  }

  return $macro_name;
}



##----------------------------------------------------------------------------
## component_path_str
##----------------------------------------------------------------------------
sub component_path_str {
  my( $this, $comp ) = @_;

  my $comp_path = $comp->name();

  my $pcomp = $comp->parent();
  while( $pcomp ) {
    $comp_path = $pcomp->name()."::".$comp_path;
    $pcomp     = $pcomp->parent();
  }

  return $comp_path;
}

##----------------------------------------------------------------------------
## gen_mask
##----------------------------------------------------------------------------
sub gen_mask {
  my( $this, $width, $lsb ) = @_;

  my $fmask       = -1;
  my $upper_shift = 64 - $width;
  $fmask <<= $upper_shift;
  $fmask >>= $upper_shift;
  $fmask <<= $lsb;
}

1;

