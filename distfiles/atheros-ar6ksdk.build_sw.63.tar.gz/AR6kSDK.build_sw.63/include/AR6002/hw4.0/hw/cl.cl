Change 525945 by jhou@jhou-dev on 2009/05/19 12:35:50

	undo CL#525368 to keep mac_pcu_reg.cfg consistent with ToT

Affected files ...

... //depot/chips/venus/dev/doc/headers/mac_pcu_reg.cfg#5 edit

Differences ...

==== //depot/chips/venus/dev/doc/headers/mac_pcu_reg.cfg#5 (ktext) ====

1,10c1,10
< @FORMAT: 3
< #  1 - field name                  same
< #  2 - value (common mode)         same
< #  3 - register name               same
< #  4 - address offset              rf register number
< #  5 - bit range                   same
< #  6 - value is signed             shift data bit
< #  7 - writable                    same
< #  8 - readable                    same
< #  9 - hoffman encoded column      same
---
> #------------------------------------------------------------------------------------------------------------
> #  1 - field name
> #  2 - value (common mode)
> #  3 - register name
> #  4 - address offset
> #  5 - bit range
> #  6 - value is signed
> #  7 - writable
> #  8 - readable
> #  9 - hoffman encoded column
15,21c15,53
< #        4..9 analog banks 0..7 excluding banks 4 & 5
< # 10 - reserved for Atheros use    same
< # -----------------------------------------------------------------------------------------
< # 1                            2   3                              4          5      6 7 8 9 0
< # ---------------------------- -   ------------------------------ ---------- ------ - - - - -
<  mc_mac_pcu_slp32_mode_enable      1   mac_pcu_rtc_MAC_PCU_SLP32_MODE 0x000040f4 20     0 1 1 2 1
<  mc_mac_pcu_tsf_l32_value          268435455 mac_pcu_rtc_MAC_PCU_TSF_L32    0x0000411c 31:0   0 1 1 2 1
---
> # 10 - reserved for Atheros use
> # -----------------------------------------------------------------------------------------------------------
> #1                                                  2       3                    4        5      6 7 8 9 10
> # -----------------------------------------------------------------------------------------------------------
> 
>  mc_mac_pcu_slp32_mode_tsf2_write_status               1       MAC_PCU_SLP32_MODE   0x000040f4 24     0 0 1 2 1
>  mc_mac_pcu_slp32_mode_force_bias_block_on             0       MAC_PCU_SLP32_MODE   0x000040f4 23     0 1 1 2 1
>  mc_mac_pcu_slp32_mode_disable_32khz                   0       MAC_PCU_SLP32_MODE   0x000040f4 22     0 1 1 2 1
>  mc_mac_pcu_slp32_mode_tsf_write_status                1       MAC_PCU_SLP32_MODE   0x000040f4 21     0 0 1 2 1
>  mc_mac_pcu_slp32_mode_enable                          1       MAC_PCU_SLP32_MODE   0x000040f4 20     0 1 1 2 1
>  mc_mac_pcu_slp32_mode_half_clk_latency                62500   MAC_PCU_SLP32_MODE   0x000040f4 19:0   0 1 1 2 1
> 
>  mc_mac_pcu_slp32_wake_xtl_time                        2048    MAC_PCU_SLP32_WAKE   0x000040f8 15:0   0 1 1 2 1
> 
>  mc_mac_pcu_slp32_inc_tsf_inc                          125000  MAC_PCU_SLP32_INC    0x000040fc 19:0   0 1 1 2 1
> 
>  mc_mac_pcu_slp_mib1_sleep_cnt                         0       MAC_PCU_SLP_MIB1     0x00004100 31:0   0 1 1 2 1
> 
>  mc_mac_pcu_slp_mib2_cycle_cnt                         0       MAC_PCU_SLP_MIB2     0x00004104 31:0   0 1 1 2 1
> 
>  mc_mac_pcu_slp_mib3_pending                           0       MAC_PCU_SLP_MIB3     0x00004108 1      0 0 1 2 1
>  mc_mac_pcu_slp_mib3_clr_cnt                           0       MAC_PCU_SLP_MIB3     0x00004108 0      0 1 1 2 1
> 
>  mc_mac_pcu_tsf_l32_value                              268435455 MAC_PCU_TSF_L32      0x0000411c 31:0   0 1 1 2 1
> 
>  mc_mac_pcu_tsf_u32_value                              268435455 MAC_PCU_TSF_U32      0x00004120 31:0   0 1 1 2 1
> 
>  mc_mac_pcu_wbtimer_value                              0       MAC_PCU_WBTIMER      0x00004124 31:0   0 1 1 2 1
> 
>  mc_mac_pcu_generic_timers_data                        0       MAC_PCU_GENERIC_TIMERS 0x00004140 31:0   0 1 1 2 1
> 
>  mc_mac_pcu_generic_timers_mode_enable                 0       MAC_PCU_GENERIC_TIMERS_MODE 0x00004180 15:0   0 1 1 2 1
> 
>  mc_mac_pcu_generic_timers2_data                       0       MAC_PCU_GENERIC_TIMERS2 0x000041c0 31:0   0 1 1 2 1
> 
>  mc_mac_pcu_generic_timers_mode2_enable                0       MAC_PCU_GENERIC_TIMERS_MODE2 0x00004200 15:0   0 1 1 2 1
> 
>  mc_mac_pcu_slp1_assume_dtim                           0       MAC_PCU_SLP1         0x00004204 19     0 1 1 2 1
>  mc_mac_pcu_slp1_cab_timeout                           5       MAC_PCU_SLP1         0x00004204 15:0   0 1 1 2 1
23c55
<  mc_mac_pcu_tsf_u32_value          268435455 mac_pcu_rtc_MAC_PCU_TSF_U32    0x00004120 31:0   0 1 1 2 1
---
>  mc_mac_pcu_slp2_beacon_timeout                        2       MAC_PCU_SLP2         0x00004208 15:0   0 1 1 2 1
25c57,58
<  mc_mac_pcu_wbtimer_value          0   mac_pcu_rtc_MAC_PCU_WBTIMER    0x00004124 31:0   0 1 1 2 1
---
>  mc_mac_pcu_reset_tsf_one_shot2                        0       MAC_PCU_RESET_TSF    0x0000420c 25     0 1 1 2 1
>  mc_mac_pcu_reset_tsf_one_shot                         0       MAC_PCU_RESET_TSF    0x0000420c 24     0 1 1 2 1
27c60
<  mc_mac_pcu_generic_timers_mode_enable 0   mac_pcu_rtc_MAC_PCU_GENERIC_TIMERS_MODE 0x00004180 15:0   0 1 1 2 1
---
>  mc_mac_pcu_tsf_add_pll_value                          62      MAC_PCU_TSF_ADD_PLL  0x00004210 7:0    0 1 1 2 1
29c62,63
<  mc_mac_pcu_generic_timers2_data   0   mac_pcu_rtc_MAC_PCU_GENERIC_TIMERS2 0x000041c0 31:0   0 1 1 2 1
---
>  mc_mac_pcu_bmiss_timeout_enable                       0       MAC_PCU_BMISS_TIMEOUT 0x0000427c 24     0 1 1 2 1
>  mc_mac_pcu_bmiss_timeout_value                        16777215 MAC_PCU_BMISS_TIMEOUT 0x0000427c 23:0   0 1 1 2 1
31c65,66
<  mc_mac_pcu_generic_timers_mode2_enable 0   mac_pcu_rtc_MAC_PCU_GENERIC_TIMERS_MODE2 0x00004200 15:0   0 1 1 2 1
---
>  mc_mac_pcu_cab_awake_enable                           0       MAC_PCU_CAB_AWAKE    0x00004280 16     0 1 1 2 1
>  mc_mac_pcu_cab_awake_duration                         5       MAC_PCU_CAB_AWAKE    0x00004280 15:0   0 1 1 2 1
33c68
<  mc_mac_pcu_tsf_add_pll_value      62  mac_pcu_rtc_MAC_PCU_TSF_ADD_PLL 0x00004210 7:0    0 1 1 2 1
---
>  mc_mac_pcu_tsf2_l32_value                             268435455 MAC_PCU_TSF2_L32     0x000042cc 31:0   0 1 1 2 1
35,36c70
<  mc_mac_pcu_bmiss_timeout_enable   0   mac_pcu_rtc_MAC_PCU_BMISS_TIMEOUT 0x0000427c 24     0 1 1 2 1
<  mc_mac_pcu_bmiss_timeout_value    16777215 mac_pcu_rtc_MAC_PCU_BMISS_TIMEOUT 0x0000427c 23:0   0 1 1 2 1
---
>  mc_mac_pcu_tsf2_u32_value                             268435455 MAC_PCU_TSF2_U32     0x000042d0 31:0   0 1 1 2 1
38,39c72,73
<  mc_mac_pcu_cab_awake_enable       0   mac_pcu_rtc_MAC_PCU_CAB_AWAKE  0x00004280 16     0 1 1 2 1
<  mc_mac_pcu_tsf2_l32_value         268435455 mac_pcu_rtc_MAC_PCU_TSF2_L32   0x000042cc 31:0   0 1 1 2 1
---
>  mc_mac_pcu_generic_timers_mode3_overflow_index        0       MAC_PCU_GENERIC_TIMERS_MODE3 0x000042d4 27:24  0 0 1 2 1
>  mc_mac_pcu_generic_timers_mode3_thresh                256     MAC_PCU_GENERIC_TIMERS_MODE3 0x000042d4 19:0   0 1 1 2 1
41c75,77
<  mc_mac_pcu_tsf2_u32_value         268435455 mac_pcu_rtc_MAC_PCU_TSF2_U32   0x000042d0 31:0   0 1 1 2 1
---
>  mc_mac_pcu_direct_connect_sta_tsf_1_2_sel             0       MAC_PCU_DIRECT_CONNECT 0x000042d8 2      0 1 1 2 1
>  mc_mac_pcu_direct_connect_ap_tsf_1_2_sel              0       MAC_PCU_DIRECT_CONNECT 0x000042d8 1      0 1 1 2 1
>  mc_mac_pcu_direct_connect_ap_sta_enable               0       MAC_PCU_DIRECT_CONNECT 0x000042d8 0      0 1 1 2 1
43c79
<  mc_addr_31_0                      0   mac_pcu_MAC_PCU_STA_ADDR_L32   0x00028000 31:0   0 1 1 2 1
---
>  mc_mac_pcu_sta_addr_l32_addr_31_0                     0       MAC_PCU_STA_ADDR_L32 0x00028000 31:0   0 1 1 2 1
45,61c81,97
<  mc_adhoc_mcast_search             0   mac_pcu_MAC_PCU_STA_ADDR_U16   0x00028004 31     0 1 1 2 1
<  mc_cbciv_endian                   0   mac_pcu_MAC_PCU_STA_ADDR_U16   0x00028004 30     0 1 1 2 1
<  mc_preserve_seqnum                1   mac_pcu_MAC_PCU_STA_ADDR_U16   0x00028004 29     0 1 1 2 1
<  mc_ksrch_mode                     0   mac_pcu_MAC_PCU_STA_ADDR_U16   0x00028004 28     0 1 1 2 1
<  mc_crpt_mic_enable                0   mac_pcu_MAC_PCU_STA_ADDR_U16   0x00028004 27     0 1 1 2 1
<  mc_sector_self_gen                0   mac_pcu_MAC_PCU_STA_ADDR_U16   0x00028004 26     0 1 1 2 1
<  mc_base_rate_11b                  0   mac_pcu_MAC_PCU_STA_ADDR_U16   0x00028004 25     0 1 1 2 1
<  mc_ackcts_6mb                     0   mac_pcu_MAC_PCU_STA_ADDR_U16   0x00028004 24     0 1 1 2 1
<  mc_rts_use_def                    0   mac_pcu_MAC_PCU_STA_ADDR_U16   0x00028004 23     0 1 1 2 1
<  mc_defant_update                  0   mac_pcu_MAC_PCU_STA_ADDR_U16   0x00028004 22     0 1 1 2 1
<  mc_use_defant                     0   mac_pcu_MAC_PCU_STA_ADDR_U16   0x00028004 21     0 1 1 2 1
<  mc_pcf                            0   mac_pcu_MAC_PCU_STA_ADDR_U16   0x00028004 20     0 1 1 2 1
<  mc_keysrch_dis                    0   mac_pcu_MAC_PCU_STA_ADDR_U16   0x00028004 19     0 1 1 2 1
<  mc_pw_save                        0   mac_pcu_MAC_PCU_STA_ADDR_U16   0x00028004 18     0 1 1 2 1
<  mc_adhoc                          0   mac_pcu_MAC_PCU_STA_ADDR_U16   0x00028004 17     0 1 1 2 1
<  mc_sta_ap                         0   mac_pcu_MAC_PCU_STA_ADDR_U16   0x00028004 16     0 1 1 2 1
<  mc_addr_47_32                     0   mac_pcu_MAC_PCU_STA_ADDR_U16   0x00028004 15:0   0 1 1 2 1
---
>  mc_mac_pcu_sta_addr_u16_adhoc_mcast_search            0       MAC_PCU_STA_ADDR_U16 0x00028004 31     0 1 1 2 1
>  mc_mac_pcu_sta_addr_u16_cbciv_endian                  0       MAC_PCU_STA_ADDR_U16 0x00028004 30     0 1 1 2 1
>  mc_mac_pcu_sta_addr_u16_preserve_seqnum               1       MAC_PCU_STA_ADDR_U16 0x00028004 29     0 1 1 2 1
>  mc_mac_pcu_sta_addr_u16_ksrch_mode                    0       MAC_PCU_STA_ADDR_U16 0x00028004 28     0 1 1 2 1
>  mc_mac_pcu_sta_addr_u16_crpt_mic_enable               0       MAC_PCU_STA_ADDR_U16 0x00028004 27     0 1 1 2 1
>  mc_mac_pcu_sta_addr_u16_sector_self_gen               0       MAC_PCU_STA_ADDR_U16 0x00028004 26     0 1 1 2 1
>  mc_mac_pcu_sta_addr_u16_base_rate_11b                 0       MAC_PCU_STA_ADDR_U16 0x00028004 25     0 1 1 2 1
>  mc_mac_pcu_sta_addr_u16_ackcts_6mb                    0       MAC_PCU_STA_ADDR_U16 0x00028004 24     0 1 1 2 1
>  mc_mac_pcu_sta_addr_u16_rts_use_def                   0       MAC_PCU_STA_ADDR_U16 0x00028004 23     0 1 1 2 1
>  mc_mac_pcu_sta_addr_u16_defant_update                 0       MAC_PCU_STA_ADDR_U16 0x00028004 22     0 1 1 2 1
>  mc_mac_pcu_sta_addr_u16_use_defant                    0       MAC_PCU_STA_ADDR_U16 0x00028004 21     0 1 1 2 1
>  mc_mac_pcu_sta_addr_u16_pcf                           0       MAC_PCU_STA_ADDR_U16 0x00028004 20     0 1 1 2 1
>  mc_mac_pcu_sta_addr_u16_keysrch_dis                   0       MAC_PCU_STA_ADDR_U16 0x00028004 19     0 1 1 2 1
>  mc_mac_pcu_sta_addr_u16_pw_save                       0       MAC_PCU_STA_ADDR_U16 0x00028004 18     0 1 1 2 1
>  mc_mac_pcu_sta_addr_u16_adhoc                         0       MAC_PCU_STA_ADDR_U16 0x00028004 17     0 1 1 2 1
>  mc_mac_pcu_sta_addr_u16_sta_ap                        0       MAC_PCU_STA_ADDR_U16 0x00028004 16     0 1 1 2 1
>  mc_mac_pcu_sta_addr_u16_addr_47_32                    0       MAC_PCU_STA_ADDR_U16 0x00028004 15:0   0 1 1 2 1
63c99
<  mc_addr                           0   mac_pcu_MAC_PCU_BSSID_L32      0x00028008 31:0   0 1 1 2 1
---
>  mc_mac_pcu_bssid_l32_addr                             0       MAC_PCU_BSSID_L32    0x00028008 31:0   0 1 1 2 1
65,66c101,102
<  mc_aid                            0   mac_pcu_MAC_PCU_BSSID_U16      0x0002800c 26:16  0 1 1 2 1
<  mc_mac_pcu_bssid_u16_addr         0   mac_pcu_MAC_PCU_BSSID_U16      0x0002800c 15:0   0 1 1 2 1
---
>  mc_mac_pcu_bssid_u16_aid                              0       MAC_PCU_BSSID_U16    0x0002800c 26:16  0 1 1 2 1
>  mc_mac_pcu_bssid_u16_addr                             0       MAC_PCU_BSSID_U16    0x0002800c 15:0   0 1 1 2 1
68c104
<  mc_mac_pcu_bcn_rssi_ave_value     2048 mac_pcu_MAC_PCU_BCN_RSSI_AVE   0x00028010 11:0   0 0 1 2 1
---
>  mc_mac_pcu_bcn_rssi_ave_value                         2048    MAC_PCU_BCN_RSSI_AVE 0x00028010 11:0   0 0 1 2 1
70,71c106,107
<  mc_cts_timeout                    0   mac_pcu_MAC_PCU_ACK_CTS_TIMEOUT 0x00028014 29:16  0 1 1 2 1
<  mc_ack_timeout                    0   mac_pcu_MAC_PCU_ACK_CTS_TIMEOUT 0x00028014 13:0   0 1 1 2 1
---
>  mc_mac_pcu_ack_cts_timeout_cts_timeout                0       MAC_PCU_ACK_CTS_TIMEOUT 0x00028014 29:16  0 1 1 2 1
>  mc_mac_pcu_ack_cts_timeout_ack_timeout                0       MAC_PCU_ACK_CTS_TIMEOUT 0x00028014 13:0   0 1 1 2 1
73,77c109,113
<  mc_mac_pcu_bcn_rssi_ctl_reset     0   mac_pcu_MAC_PCU_BCN_RSSI_CTL   0x00028018 29     0 1 1 2 1
<  mc_weight                         0   mac_pcu_MAC_PCU_BCN_RSSI_CTL   0x00028018 28:24  0 1 1 2 1
<  mc_rssi_high_thresh               127 mac_pcu_MAC_PCU_BCN_RSSI_CTL   0x00028018 23:16  0 1 1 2 1
<  mc_miss_thresh                    0   mac_pcu_MAC_PCU_BCN_RSSI_CTL   0x00028018 15:8   0 1 1 2 1
<  mc_rssi_low_thresh                0   mac_pcu_MAC_PCU_BCN_RSSI_CTL   0x00028018 7:0    0 1 1 2 1
---
>  mc_mac_pcu_bcn_rssi_ctl_reset                         0       MAC_PCU_BCN_RSSI_CTL 0x00028018 29     0 1 1 2 1
>  mc_mac_pcu_bcn_rssi_ctl_weight                        0       MAC_PCU_BCN_RSSI_CTL 0x00028018 28:24  0 1 1 2 1
>  mc_mac_pcu_bcn_rssi_ctl_rssi_high_thresh              127     MAC_PCU_BCN_RSSI_CTL 0x00028018 23:16  0 1 1 2 1
>  mc_mac_pcu_bcn_rssi_ctl_miss_thresh                   0       MAC_PCU_BCN_RSSI_CTL 0x00028018 15:8   0 1 1 2 1
>  mc_mac_pcu_bcn_rssi_ctl_rssi_low_thresh               0       MAC_PCU_BCN_RSSI_CTL 0x00028018 7:0    0 1 1 2 1
79,81c115,117
<  mc_rx_latency                     0   mac_pcu_MAC_PCU_USEC_LATENCY   0x0002801c 28:23  0 1 1 2 1
<  mc_tx_latency                     0   mac_pcu_MAC_PCU_USEC_LATENCY   0x0002801c 22:14  0 1 1 2 1
<  mc_usec                           39  mac_pcu_MAC_PCU_USEC_LATENCY   0x0002801c 7:0    0 1 1 2 1
---
>  mc_mac_pcu_usec_latency_rx_latency                    0       MAC_PCU_USEC_LATENCY 0x0002801c 28:23  0 1 1 2 1
>  mc_mac_pcu_usec_latency_tx_latency                    0       MAC_PCU_USEC_LATENCY 0x0002801c 22:14  0 1 1 2 1
>  mc_mac_pcu_usec_latency_usec                          39      MAC_PCU_USEC_LATENCY 0x0002801c 7:0    0 1 1 2 1
83c119
<  mc_pcu_max_cfp_dur_value          0   mac_pcu_PCU_MAX_CFP_DUR        0x00028020 15:0   0 1 1 2 1
---
>  mc_pcu_max_cfp_dur_value                              0       PCU_MAX_CFP_DUR      0x00028020 15:0   0 1 1 2 1
85,104c121,140
<  mc_generic_filter                 0   mac_pcu_MAC_PCU_RX_FILTER      0x00028024 25:24  0 1 1 2 1
<  mc_generic_ftype                  0   mac_pcu_MAC_PCU_RX_FILTER      0x00028024 23:18  0 1 1 2 1
<  mc_from_to_ds                     0   mac_pcu_MAC_PCU_RX_FILTER      0x00028024 17     0 1 1 2 1
<  mc_rst_dlmtr_cnt_disable          0   mac_pcu_MAC_PCU_RX_FILTER      0x00028024 16     0 1 1 2 1
<  mc_mcast_bcast_all                0   mac_pcu_MAC_PCU_RX_FILTER      0x00028024 15     0 1 1 2 1
<  mc_ps_poll                        0   mac_pcu_MAC_PCU_RX_FILTER      0x00028024 14     0 1 1 2 1
<  mc_assume_radar                   1   mac_pcu_MAC_PCU_RX_FILTER      0x00028024 13     0 1 1 2 1
<  mc_uncompressed_ba_bar            0   mac_pcu_MAC_PCU_RX_FILTER      0x00028024 12     0 1 1 2 1
<  mc_compressed_ba                  0   mac_pcu_MAC_PCU_RX_FILTER      0x00028024 11     0 1 1 2 1
<  mc_compressed_bar                 0   mac_pcu_MAC_PCU_RX_FILTER      0x00028024 10     0 1 1 2 1
<  mc_my_beacon                      0   mac_pcu_MAC_PCU_RX_FILTER      0x00028024 9      0 1 1 2 1
<  mc_sync_frame                     0   mac_pcu_MAC_PCU_RX_FILTER      0x00028024 8      0 1 1 2 1
<  mc_probe_req                      0   mac_pcu_MAC_PCU_RX_FILTER      0x00028024 7      0 1 1 2 1
<  mc_xr_poll                        0   mac_pcu_MAC_PCU_RX_FILTER      0x00028024 6      0 1 1 2 1
<  mc_promiscuous                    0   mac_pcu_MAC_PCU_RX_FILTER      0x00028024 5      0 1 1 2 1
<  mc_beacon                         0   mac_pcu_MAC_PCU_RX_FILTER      0x00028024 4      0 1 1 2 1
<  mc_control                        0   mac_pcu_MAC_PCU_RX_FILTER      0x00028024 3      0 1 1 2 1
<  mc_broadcast                      0   mac_pcu_MAC_PCU_RX_FILTER      0x00028024 2      0 1 1 2 1
<  mc_multicast                      0   mac_pcu_MAC_PCU_RX_FILTER      0x00028024 1      0 1 1 2 1
<  mc_unicast                        0   mac_pcu_MAC_PCU_RX_FILTER      0x00028024 0      0 1 1 2 1
---
>  mc_mac_pcu_rx_filter_generic_filter                   0       MAC_PCU_RX_FILTER    0x00028024 25:24  0 1 1 2 1
>  mc_mac_pcu_rx_filter_generic_ftype                    0       MAC_PCU_RX_FILTER    0x00028024 23:18  0 1 1 2 1
>  mc_mac_pcu_rx_filter_from_to_ds                       0       MAC_PCU_RX_FILTER    0x00028024 17     0 1 1 2 1
>  mc_mac_pcu_rx_filter_rst_dlmtr_cnt_disable            0       MAC_PCU_RX_FILTER    0x00028024 16     0 1 1 2 1
>  mc_mac_pcu_rx_filter_mcast_bcast_all                  0       MAC_PCU_RX_FILTER    0x00028024 15     0 1 1 2 1
>  mc_mac_pcu_rx_filter_ps_poll                          0       MAC_PCU_RX_FILTER    0x00028024 14     0 1 1 2 1
>  mc_mac_pcu_rx_filter_assume_radar                     1       MAC_PCU_RX_FILTER    0x00028024 13     0 1 1 2 1
>  mc_mac_pcu_rx_filter_uncompressed_ba_bar              0       MAC_PCU_RX_FILTER    0x00028024 12     0 1 1 2 1
>  mc_mac_pcu_rx_filter_compressed_ba                    0       MAC_PCU_RX_FILTER    0x00028024 11     0 1 1 2 1
>  mc_mac_pcu_rx_filter_compressed_bar                   0       MAC_PCU_RX_FILTER    0x00028024 10     0 1 1 2 1
>  mc_mac_pcu_rx_filter_my_beacon                        0       MAC_PCU_RX_FILTER    0x00028024 9      0 1 1 2 1
>  mc_mac_pcu_rx_filter_sync_frame                       0       MAC_PCU_RX_FILTER    0x00028024 8      0 1 1 2 1
>  mc_mac_pcu_rx_filter_probe_req                        0       MAC_PCU_RX_FILTER    0x00028024 7      0 1 1 2 1
>  mc_mac_pcu_rx_filter_xr_poll                          0       MAC_PCU_RX_FILTER    0x00028024 6      0 1 1 2 1
>  mc_mac_pcu_rx_filter_promiscuous                      0       MAC_PCU_RX_FILTER    0x00028024 5      0 1 1 2 1
>  mc_mac_pcu_rx_filter_beacon                           0       MAC_PCU_RX_FILTER    0x00028024 4      0 1 1 2 1
>  mc_mac_pcu_rx_filter_control                          0       MAC_PCU_RX_FILTER    0x00028024 3      0 1 1 2 1
>  mc_mac_pcu_rx_filter_broadcast                        0       MAC_PCU_RX_FILTER    0x00028024 2      0 1 1 2 1
>  mc_mac_pcu_rx_filter_multicast                        0       MAC_PCU_RX_FILTER    0x00028024 1      0 1 1 2 1
>  mc_mac_pcu_rx_filter_unicast                          0       MAC_PCU_RX_FILTER    0x00028024 0      0 1 1 2 1
106c142
<  mc_mac_pcu_mcast_filter_l32_value 0   mac_pcu_MAC_PCU_MCAST_FILTER_L32 0x00028028 31:0   0 1 1 2 1
---
>  mc_mac_pcu_mcast_filter_l32_value                     0       MAC_PCU_MCAST_FILTER_L32 0x00028028 31:0   0 1 1 2 1
108c144
<  mc_mac_pcu_mcast_filter_u32_value 0   mac_pcu_MAC_PCU_MCAST_FILTER_U32 0x0002802c 31:0   0 1 1 2 1
---
>  mc_mac_pcu_mcast_filter_u32_value                     0       MAC_PCU_MCAST_FILTER_U32 0x0002802c 31:0   0 1 1 2 1
110,131c146,167
<  mc_debug_mode                     0   mac_pcu_MAC_PCU_DIAG_SW        0x00028030 31:30  0 1 1 2 1
<  mc_rx_clear_ext_low               0   mac_pcu_MAC_PCU_DIAG_SW        0x00028030 29     0 1 1 2 1
<  mc_rx_clear_ctl_low               0   mac_pcu_MAC_PCU_DIAG_SW        0x00028030 28     0 1 1 2 1
<  mc_obs_sel_2                      0   mac_pcu_MAC_PCU_DIAG_SW        0x00028030 27     0 1 1 2 1
<  mc_saturate_cycle_cnt             0   mac_pcu_MAC_PCU_DIAG_SW        0x00028030 26     0 1 1 2 1
<  mc_force_rx_abort                 0   mac_pcu_MAC_PCU_DIAG_SW        0x00028030 25     0 1 1 2 1
<  mc_dual_chain_chan_info           0   mac_pcu_MAC_PCU_DIAG_SW        0x00028030 24     0 1 1 2 1
<  mc_phyerr_enable_eifs_ctl         0   mac_pcu_MAC_PCU_DIAG_SW        0x00028030 23     0 1 1 2 1
<  mc_chan_idle_high                 0   mac_pcu_MAC_PCU_DIAG_SW        0x00028030 22     0 1 1 2 1
<  mc_ignore_nav                     0   mac_pcu_MAC_PCU_DIAG_SW        0x00028030 21     0 1 1 2 1
<  mc_rx_clear_high                  0   mac_pcu_MAC_PCU_DIAG_SW        0x00028030 20     0 1 1 2 1
<  mc_obs_sel_1_0                    0   mac_pcu_MAC_PCU_DIAG_SW        0x00028030 19:18  0 1 1 2 1
<  mc_accept_non_v0                  0   mac_pcu_MAC_PCU_DIAG_SW        0x00028030 17     0 1 1 2 1
<  mc_dump_chan_info                 0   mac_pcu_MAC_PCU_DIAG_SW        0x00028030 8      0 1 1 2 1
<  mc_corrupt_fcs                    0   mac_pcu_MAC_PCU_DIAG_SW        0x00028030 7      0 1 1 2 1
<  mc_loop_back                      0   mac_pcu_MAC_PCU_DIAG_SW        0x00028030 6      0 1 1 2 1
<  mc_halt_rx                        0   mac_pcu_MAC_PCU_DIAG_SW        0x00028030 5      0 1 1 2 1
<  mc_no_decrypt                     0   mac_pcu_MAC_PCU_DIAG_SW        0x00028030 4      0 1 1 2 1
<  mc_no_encrypt                     0   mac_pcu_MAC_PCU_DIAG_SW        0x00028030 3      0 1 1 2 1
<  mc_no_cts                         0   mac_pcu_MAC_PCU_DIAG_SW        0x00028030 2      0 1 1 2 1
<  mc_no_ack                         0   mac_pcu_MAC_PCU_DIAG_SW        0x00028030 1      0 1 1 2 1
<  mc_invalid_key_no_ack             0   mac_pcu_MAC_PCU_DIAG_SW        0x00028030 0      0 1 1 2 1
---
>  mc_mac_pcu_diag_sw_debug_mode                         0       MAC_PCU_DIAG_SW      0x00028030 31:30  0 1 1 2 1
>  mc_mac_pcu_diag_sw_rx_clear_ext_low                   0       MAC_PCU_DIAG_SW      0x00028030 29     0 1 1 2 1
>  mc_mac_pcu_diag_sw_rx_clear_ctl_low                   0       MAC_PCU_DIAG_SW      0x00028030 28     0 1 1 2 1
>  mc_mac_pcu_diag_sw_obs_sel_2                          0       MAC_PCU_DIAG_SW      0x00028030 27     0 1 1 2 1
>  mc_mac_pcu_diag_sw_saturate_cycle_cnt                 0       MAC_PCU_DIAG_SW      0x00028030 26     0 1 1 2 1
>  mc_mac_pcu_diag_sw_force_rx_abort                     0       MAC_PCU_DIAG_SW      0x00028030 25     0 1 1 2 1
>  mc_mac_pcu_diag_sw_dual_chain_chan_info               0       MAC_PCU_DIAG_SW      0x00028030 24     0 1 1 2 1
>  mc_mac_pcu_diag_sw_phyerr_enable_eifs_ctl             0       MAC_PCU_DIAG_SW      0x00028030 23     0 1 1 2 1
>  mc_mac_pcu_diag_sw_chan_idle_high                     0       MAC_PCU_DIAG_SW      0x00028030 22     0 1 1 2 1
>  mc_mac_pcu_diag_sw_ignore_nav                         0       MAC_PCU_DIAG_SW      0x00028030 21     0 1 1 2 1
>  mc_mac_pcu_diag_sw_rx_clear_high                      0       MAC_PCU_DIAG_SW      0x00028030 20     0 1 1 2 1
>  mc_mac_pcu_diag_sw_obs_sel_1_0                        0       MAC_PCU_DIAG_SW      0x00028030 19:18  0 1 1 2 1
>  mc_mac_pcu_diag_sw_accept_non_v0                      0       MAC_PCU_DIAG_SW      0x00028030 17     0 1 1 2 1
>  mc_mac_pcu_diag_sw_dump_chan_info                     0       MAC_PCU_DIAG_SW      0x00028030 8      0 1 1 2 1
>  mc_mac_pcu_diag_sw_corrupt_fcs                        0       MAC_PCU_DIAG_SW      0x00028030 7      0 1 1 2 1
>  mc_mac_pcu_diag_sw_loop_back                          0       MAC_PCU_DIAG_SW      0x00028030 6      0 1 1 2 1
>  mc_mac_pcu_diag_sw_halt_rx                            0       MAC_PCU_DIAG_SW      0x00028030 5      0 1 1 2 1
>  mc_mac_pcu_diag_sw_no_decrypt                         0       MAC_PCU_DIAG_SW      0x00028030 4      0 1 1 2 1
>  mc_mac_pcu_diag_sw_no_encrypt                         0       MAC_PCU_DIAG_SW      0x00028030 3      0 1 1 2 1
>  mc_mac_pcu_diag_sw_no_cts                             0       MAC_PCU_DIAG_SW      0x00028030 2      0 1 1 2 1
>  mc_mac_pcu_diag_sw_no_ack                             0       MAC_PCU_DIAG_SW      0x00028030 1      0 1 1 2 1
>  mc_mac_pcu_diag_sw_invalid_key_no_ack                 0       MAC_PCU_DIAG_SW      0x00028030 0      0 1 1 2 1
133,142c169,178
<  mc_test_arm                       0   mac_pcu_MAC_PCU_TST_ADDAC      0x00028034 20     0 1 1 2 1
<  mc_test_capture                   0   mac_pcu_MAC_PCU_TST_ADDAC      0x00028034 19     0 1 1 2 1
<  mc_cont_test                      0   mac_pcu_MAC_PCU_TST_ADDAC      0x00028034 18     0 0 1 2 1
<  mc_trig_polarity                  0   mac_pcu_MAC_PCU_TST_ADDAC      0x00028034 17     0 1 1 2 1
<  mc_trig_sel                       0   mac_pcu_MAC_PCU_TST_ADDAC      0x00028034 16     0 1 1 2 1
<  mc_upper_8b                       0   mac_pcu_MAC_PCU_TST_ADDAC      0x00028034 14     0 1 1 2 1
<  mc_loop_len                       0   mac_pcu_MAC_PCU_TST_ADDAC      0x00028034 13:3   0 1 1 2 1
<  mc_loop                           0   mac_pcu_MAC_PCU_TST_ADDAC      0x00028034 2      0 1 1 2 1
<  mc_testmode                       0   mac_pcu_MAC_PCU_TST_ADDAC      0x00028034 1      0 1 1 2 1
<  mc_cont_tx                        0   mac_pcu_MAC_PCU_TST_ADDAC      0x00028034 0      0 1 1 2 1
---
>  mc_mac_pcu_tst_addac_test_arm                         0       MAC_PCU_TST_ADDAC    0x00028034 20     0 1 1 2 1
>  mc_mac_pcu_tst_addac_test_capture                     0       MAC_PCU_TST_ADDAC    0x00028034 19     0 1 1 2 1
>  mc_mac_pcu_tst_addac_cont_test                        0       MAC_PCU_TST_ADDAC    0x00028034 18     0 0 1 2 1
>  mc_mac_pcu_tst_addac_trig_polarity                    0       MAC_PCU_TST_ADDAC    0x00028034 17     0 1 1 2 1
>  mc_mac_pcu_tst_addac_trig_sel                         0       MAC_PCU_TST_ADDAC    0x00028034 16     0 1 1 2 1
>  mc_mac_pcu_tst_addac_upper_8b                         0       MAC_PCU_TST_ADDAC    0x00028034 14     0 1 1 2 1
>  mc_mac_pcu_tst_addac_loop_len                         0       MAC_PCU_TST_ADDAC    0x00028034 13:3   0 1 1 2 1
>  mc_mac_pcu_tst_addac_loop                             0       MAC_PCU_TST_ADDAC    0x00028034 2      0 1 1 2 1
>  mc_mac_pcu_tst_addac_testmode                         0       MAC_PCU_TST_ADDAC    0x00028034 1      0 1 1 2 1
>  mc_mac_pcu_tst_addac_cont_tx                          0       MAC_PCU_TST_ADDAC    0x00028034 0      0 1 1 2 1
144,146c180,182
<  mc_rx_lna_config_sel              0   mac_pcu_MAC_PCU_DEF_ANTENNA    0x00028038 28     0 1 1 2 1
<  mc_tx_def_ant_sel                 0   mac_pcu_MAC_PCU_DEF_ANTENNA    0x00028038 24     0 1 1 2 1
<  mc_mac_pcu_def_antenna_value      0   mac_pcu_MAC_PCU_DEF_ANTENNA    0x00028038 23:0   0 1 1 2 1
---
>  mc_mac_pcu_def_antenna_rx_lna_config_sel              0       MAC_PCU_DEF_ANTENNA  0x00028038 28     0 1 1 2 1
>  mc_mac_pcu_def_antenna_tx_def_ant_sel                 0       MAC_PCU_DEF_ANTENNA  0x00028038 24     0 1 1 2 1
>  mc_mac_pcu_def_antenna_value                          0       MAC_PCU_DEF_ANTENNA  0x00028038 23:0   0 1 1 2 1
148,149c184,185
<  mc_qos                            65535 mac_pcu_MAC_PCU_AES_MUTE_MASK_0 0x0002803c 31:16  0 1 1 2 1
<  mc_fc                             51087 mac_pcu_MAC_PCU_AES_MUTE_MASK_0 0x0002803c 15:0   0 1 1 2 1
---
>  mc_mac_pcu_aes_mute_mask_0_qos                        65535   MAC_PCU_AES_MUTE_MASK_0 0x0002803c 31:16  0 1 1 2 1
>  mc_mac_pcu_aes_mute_mask_0_fc                         51087   MAC_PCU_AES_MUTE_MASK_0 0x0002803c 15:0   0 1 1 2 1
151,152c187,188
<  mc_fc_mgmt                        59391 mac_pcu_MAC_PCU_AES_MUTE_MASK_1 0x00028040 31:16  0 1 1 2 1
<  mc_seq                            15  mac_pcu_MAC_PCU_AES_MUTE_MASK_1 0x00028040 15:0   0 1 1 2 1
---
>  mc_mac_pcu_aes_mute_mask_1_fc_mgmt                    59391   MAC_PCU_AES_MUTE_MASK_1 0x00028040 31:16  0 1 1 2 1
>  mc_mac_pcu_aes_mute_mask_1_seq                        15      MAC_PCU_AES_MUTE_MASK_1 0x00028040 15:0   0 1 1 2 1
154,156c190,192
<  mc_gated_reg                      0   mac_pcu_MAC_PCU_GATED_CLKS     0x00028044 3      0 1 1 2 1
<  mc_gated_rx                       0   mac_pcu_MAC_PCU_GATED_CLKS     0x00028044 2      0 1 1 2 1
<  mc_gated_tx                       0   mac_pcu_MAC_PCU_GATED_CLKS     0x00028044 1      0 1 1 2 1
---
>  mc_mac_pcu_gated_clks_gated_reg                       0       MAC_PCU_GATED_CLKS   0x00028044 3      0 1 1 2 1
>  mc_mac_pcu_gated_clks_gated_rx                        0       MAC_PCU_GATED_CLKS   0x00028044 2      0 1 1 2 1
>  mc_mac_pcu_gated_clks_gated_tx                        0       MAC_PCU_GATED_CLKS   0x00028044 1      0 1 1 2 1
158c194
<  mc_mac_pcu_obs_bus_2_value        0   mac_pcu_MAC_PCU_OBS_BUS_2      0x00028048 17:0   0 0 1 2 1
---
>  mc_mac_pcu_obs_bus_2_value                            0       MAC_PCU_OBS_BUS_2    0x00028048 17:0   0 0 1 2 1
160,174c196,210
<  mc_tx_state                       0   mac_pcu_MAC_PCU_OBS_BUS_1      0x0002804c 30:25  0 0 1 2 1
<  mc_rx_state                       0   mac_pcu_MAC_PCU_OBS_BUS_1      0x0002804c 24:20  0 0 1 2 1
<  mc_wep_state                      0   mac_pcu_MAC_PCU_OBS_BUS_1      0x0002804c 17:12  0 0 1 2 1
<  mc_rx_clear                       0   mac_pcu_MAC_PCU_OBS_BUS_1      0x0002804c 11     0 0 1 2 1
<  mc_rx_frame                       0   mac_pcu_MAC_PCU_OBS_BUS_1      0x0002804c 10     0 0 1 2 1
<  mc_tx_frame                       0   mac_pcu_MAC_PCU_OBS_BUS_1      0x0002804c 9      0 0 1 2 1
<  mc_tx_hold                        0   mac_pcu_MAC_PCU_OBS_BUS_1      0x0002804c 8      0 0 1 2 1
<  mc_pcu_channel_idle               0   mac_pcu_MAC_PCU_OBS_BUS_1      0x0002804c 7      0 0 1 2 1
<  mc_tm_quiet_time                  0   mac_pcu_MAC_PCU_OBS_BUS_1      0x0002804c 6      0 0 1 2 1
<  mc_tx_hcf                         0   mac_pcu_MAC_PCU_OBS_BUS_1      0x0002804c 5      0 0 1 2 1
<  mc_filter_pass                    0   mac_pcu_MAC_PCU_OBS_BUS_1      0x0002804c 4      0 0 1 2 1
<  mc_rx_my_beacon                   0   mac_pcu_MAC_PCU_OBS_BUS_1      0x0002804c 3      0 0 1 2 1
<  mc_rx_wep                         0   mac_pcu_MAC_PCU_OBS_BUS_1      0x0002804c 2      0 0 1 2 1
<  mc_pcu_rx_end                     0   mac_pcu_MAC_PCU_OBS_BUS_1      0x0002804c 1      0 0 1 2 1
<  mc_pcu_directed                   0   mac_pcu_MAC_PCU_OBS_BUS_1      0x0002804c 0      0 0 1 2 1
---
>  mc_mac_pcu_obs_bus_1_tx_state                         0       MAC_PCU_OBS_BUS_1    0x0002804c 30:25  0 0 1 2 1
>  mc_mac_pcu_obs_bus_1_rx_state                         0       MAC_PCU_OBS_BUS_1    0x0002804c 24:20  0 0 1 2 1
>  mc_mac_pcu_obs_bus_1_wep_state                        0       MAC_PCU_OBS_BUS_1    0x0002804c 17:12  0 0 1 2 1
>  mc_mac_pcu_obs_bus_1_rx_clear                         0       MAC_PCU_OBS_BUS_1    0x0002804c 11     0 0 1 2 1
>  mc_mac_pcu_obs_bus_1_rx_frame                         0       MAC_PCU_OBS_BUS_1    0x0002804c 10     0 0 1 2 1
>  mc_mac_pcu_obs_bus_1_tx_frame                         0       MAC_PCU_OBS_BUS_1    0x0002804c 9      0 0 1 2 1
>  mc_mac_pcu_obs_bus_1_tx_hold                          0       MAC_PCU_OBS_BUS_1    0x0002804c 8      0 0 1 2 1
>  mc_mac_pcu_obs_bus_1_pcu_channel_idle                 0       MAC_PCU_OBS_BUS_1    0x0002804c 7      0 0 1 2 1
>  mc_mac_pcu_obs_bus_1_tm_quiet_time                    0       MAC_PCU_OBS_BUS_1    0x0002804c 6      0 0 1 2 1
>  mc_mac_pcu_obs_bus_1_tx_hcf                           0       MAC_PCU_OBS_BUS_1    0x0002804c 5      0 0 1 2 1
>  mc_mac_pcu_obs_bus_1_filter_pass                      0       MAC_PCU_OBS_BUS_1    0x0002804c 4      0 0 1 2 1
>  mc_mac_pcu_obs_bus_1_rx_my_beacon                     0       MAC_PCU_OBS_BUS_1    0x0002804c 3      0 0 1 2 1
>  mc_mac_pcu_obs_bus_1_rx_wep                           0       MAC_PCU_OBS_BUS_1    0x0002804c 2      0 0 1 2 1
>  mc_mac_pcu_obs_bus_1_pcu_rx_end                       0       MAC_PCU_OBS_BUS_1    0x0002804c 1      0 0 1 2 1
>  mc_mac_pcu_obs_bus_1_pcu_directed                     0       MAC_PCU_OBS_BUS_1    0x0002804c 0      0 0 1 2 1
176,180c212,216
<  mc_hi_pwr_chain_mask              3   mac_pcu_MAC_PCU_DYM_MIMO_PWR_SAVE 0x00028050 10:8   0 1 1 2 1
<  mc_low_pwr_chain_mask             1   mac_pcu_MAC_PCU_DYM_MIMO_PWR_SAVE 0x00028050 6:4    0 1 1 2 1
<  mc_sw_chain_mask_sel              0   mac_pcu_MAC_PCU_DYM_MIMO_PWR_SAVE 0x00028050 2      0 1 1 2 1
<  mc_hw_ctrl_en                     0   mac_pcu_MAC_PCU_DYM_MIMO_PWR_SAVE 0x00028050 1      0 1 1 2 1
<  mc_use_mac_ctrl                   0   mac_pcu_MAC_PCU_DYM_MIMO_PWR_SAVE 0x00028050 0      0 1 1 2 1
---
>  mc_mac_pcu_dym_mimo_pwr_save_hi_pwr_chain_mask        3       MAC_PCU_DYM_MIMO_PWR_SAVE 0x00028050 10:8   0 1 1 2 1
>  mc_mac_pcu_dym_mimo_pwr_save_low_pwr_chain_mask       1       MAC_PCU_DYM_MIMO_PWR_SAVE 0x00028050 6:4    0 1 1 2 1
>  mc_mac_pcu_dym_mimo_pwr_save_sw_chain_mask_sel        0       MAC_PCU_DYM_MIMO_PWR_SAVE 0x00028050 2      0 1 1 2 1
>  mc_mac_pcu_dym_mimo_pwr_save_hw_ctrl_en               0       MAC_PCU_DYM_MIMO_PWR_SAVE 0x00028050 1      0 1 1 2 1
>  mc_mac_pcu_dym_mimo_pwr_save_use_mac_ctrl             0       MAC_PCU_DYM_MIMO_PWR_SAVE 0x00028050 0      0 1 1 2 1
182c218
<  mc_mac_pcu_last_beacon_tsf_value  0   mac_pcu_MAC_PCU_LAST_BEACON_TSF 0x00028054 31:0   0 0 1 2 1
---
>  mc_mac_pcu_last_beacon_tsf_value                      0       MAC_PCU_LAST_BEACON_TSF 0x00028054 31:0   0 0 1 2 1
184c220
<  mc_mac_pcu_nav_value              0   mac_pcu_MAC_PCU_NAV            0x00028058 25:0   0 1 1 2 1
---
>  mc_mac_pcu_nav_value                                  0       MAC_PCU_NAV          0x00028058 25:0   0 1 1 2 1
186c222
<  mc_mac_pcu_rts_success_cnt_value  0   mac_pcu_MAC_PCU_RTS_SUCCESS_CNT 0x0002805c 15:0   0 0 1 2 1
---
>  mc_mac_pcu_rts_success_cnt_value                      0       MAC_PCU_RTS_SUCCESS_CNT 0x0002805c 15:0   0 0 1 2 1
188c224
<  mc_mac_pcu_rts_fail_cnt_value     0   mac_pcu_MAC_PCU_RTS_FAIL_CNT   0x00028060 15:0   0 0 1 2 1
---
>  mc_mac_pcu_rts_fail_cnt_value                         0       MAC_PCU_RTS_FAIL_CNT 0x00028060 15:0   0 0 1 2 1
190c226
<  mc_mac_pcu_ack_fail_cnt_value     0   mac_pcu_MAC_PCU_ACK_FAIL_CNT   0x00028064 15:0   0 0 1 2 1
---
>  mc_mac_pcu_ack_fail_cnt_value                         0       MAC_PCU_ACK_FAIL_CNT 0x00028064 15:0   0 0 1 2 1
192c228
<  mc_mac_pcu_fcs_fail_cnt_value     0   mac_pcu_MAC_PCU_FCS_FAIL_CNT   0x00028068 15:0   0 0 1 2 1
---
>  mc_mac_pcu_fcs_fail_cnt_value                         0       MAC_PCU_FCS_FAIL_CNT 0x00028068 15:0   0 0 1 2 1
194c230
<  mc_mac_pcu_beacon_cnt_value       0   mac_pcu_MAC_PCU_BEACON_CNT     0x0002806c 15:0   0 0 1 2 1
---
>  mc_mac_pcu_beacon_cnt_value                           0       MAC_PCU_BEACON_CNT   0x0002806c 15:0   0 0 1 2 1
196,198c232,234
<  mc_frame_hold                     680 mac_pcu_MAC_PCU_XRMODE         0x00028070 31:20  0 1 1 2 1
<  mc_wait_for_poll                  0   mac_pcu_MAC_PCU_XRMODE         0x00028070 7      0 1 1 2 1
<  mc_poll_type                      0   mac_pcu_MAC_PCU_XRMODE         0x00028070 5:0    0 1 1 2 1
---
>  mc_mac_pcu_xrmode_frame_hold                          680     MAC_PCU_XRMODE       0x00028070 31:20  0 1 1 2 1
>  mc_mac_pcu_xrmode_wait_for_poll                       0       MAC_PCU_XRMODE       0x00028070 7      0 1 1 2 1
>  mc_mac_pcu_xrmode_poll_type                           0       MAC_PCU_XRMODE       0x00028070 5:0    0 1 1 2 1
200,201c236,237
<  mc_chirp_data_delay               1680 mac_pcu_MAC_PCU_XRDEL          0x00028074 31:16  0 1 1 2 1
<  mc_slot_delay                     360 mac_pcu_MAC_PCU_XRDEL          0x00028074 15:0   0 1 1 2 1
---
>  mc_mac_pcu_xrdel_chirp_data_delay                     1680    MAC_PCU_XRDEL        0x00028074 31:16  0 1 1 2 1
>  mc_mac_pcu_xrdel_slot_delay                           360     MAC_PCU_XRDEL        0x00028074 15:0   0 1 1 2 1
203,204c239,240
<  mc_poll_timeout                   5000 mac_pcu_MAC_PCU_XRTO           0x00028078 31:16  0 1 1 2 1
<  mc_chirp_timeout                  7200 mac_pcu_MAC_PCU_XRTO           0x00028078 15:0   0 1 1 2 1
---
>  mc_mac_pcu_xrto_poll_timeout                          5000    MAC_PCU_XRTO         0x00028078 31:16  0 1 1 2 1
>  mc_mac_pcu_xrto_chirp_timeout                         7200    MAC_PCU_XRTO         0x00028078 15:0   0 1 1 2 1
206,207c242,243
<  mc_chirp_gap                      500 mac_pcu_MAC_PCU_XRCRP          0x0002807c 31:16  0 1 1 2 1
<  mc_send_chirp                     0   mac_pcu_MAC_PCU_XRCRP          0x0002807c 0      0 1 1 2 1
---
>  mc_mac_pcu_xrcrp_chirp_gap                            500     MAC_PCU_XRCRP        0x0002807c 31:16  0 1 1 2 1
>  mc_mac_pcu_xrcrp_send_chirp                           0       MAC_PCU_XRCRP        0x0002807c 0      0 1 1 2 1
209,216c245,252
<  mc_rx_abort_rssi_thresh           37  mac_pcu_MAC_PCU_XRSTMP         0x00028080 23:16  0 1 1 2 1
<  mc_tx_stomp_rssi_thresh           37  mac_pcu_MAC_PCU_XRSTMP         0x00028080 15:8   0 1 1 2 1
<  mc_rx_abort_data                  0   mac_pcu_MAC_PCU_XRSTMP         0x00028080 5      0 1 1 2 1
<  mc_tx_stomp_data                  0   mac_pcu_MAC_PCU_XRSTMP         0x00028080 4      0 1 1 2 1
<  mc_tx_stomp_bssid                 0   mac_pcu_MAC_PCU_XRSTMP         0x00028080 3      0 1 1 2 1
<  mc_tx_stomp_rssi                  0   mac_pcu_MAC_PCU_XRSTMP         0x00028080 2      0 1 1 2 1
<  mc_rx_abort_bssid                 0   mac_pcu_MAC_PCU_XRSTMP         0x00028080 1      0 1 1 2 1
<  mc_rx_abort_rssi                  0   mac_pcu_MAC_PCU_XRSTMP         0x00028080 0      0 1 1 2 1
---
>  mc_mac_pcu_xrstmp_rx_abort_rssi_thresh                37      MAC_PCU_XRSTMP       0x00028080 23:16  0 1 1 2 1
>  mc_mac_pcu_xrstmp_tx_stomp_rssi_thresh                37      MAC_PCU_XRSTMP       0x00028080 15:8   0 1 1 2 1
>  mc_mac_pcu_xrstmp_rx_abort_data                       0       MAC_PCU_XRSTMP       0x00028080 5      0 1 1 2 1
>  mc_mac_pcu_xrstmp_tx_stomp_data                       0       MAC_PCU_XRSTMP       0x00028080 4      0 1 1 2 1
>  mc_mac_pcu_xrstmp_tx_stomp_bssid                      0       MAC_PCU_XRSTMP       0x00028080 3      0 1 1 2 1
>  mc_mac_pcu_xrstmp_tx_stomp_rssi                       0       MAC_PCU_XRSTMP       0x00028080 2      0 1 1 2 1
>  mc_mac_pcu_xrstmp_rx_abort_bssid                      0       MAC_PCU_XRSTMP       0x00028080 1      0 1 1 2 1
>  mc_mac_pcu_xrstmp_rx_abort_rssi                       0       MAC_PCU_XRSTMP       0x00028080 0      0 1 1 2 1
218c254
<  mc_mac_pcu_addr1_mask_l32_value   -1  mac_pcu_MAC_PCU_ADDR1_MASK_L32 0x00028084 31:0   0 1 1 2 1
---
>  mc_mac_pcu_addr1_mask_l32_value                       -1      MAC_PCU_ADDR1_MASK_L32 0x00028084 31:0   0 1 1 2 1
220c256
<  mc_mac_pcu_addr1_mask_u16_value   65535 mac_pcu_MAC_PCU_ADDR1_MASK_U16 0x00028088 15:0   0 1 1 2 1
---
>  mc_mac_pcu_addr1_mask_u16_value                       65535   MAC_PCU_ADDR1_MASK_U16 0x00028088 15:0   0 1 1 2 1
222,224c258,260
<  mc_chirp_pwr                      63  mac_pcu_MAC_PCU_TPC            0x0002808c 21:16  0 1 1 2 1
<  mc_cts_pwr                        63  mac_pcu_MAC_PCU_TPC            0x0002808c 13:8   0 1 1 2 1
<  mc_ack_pwr                        63  mac_pcu_MAC_PCU_TPC            0x0002808c 5:0    0 1 1 2 1
---
>  mc_mac_pcu_tpc_chirp_pwr                              63      MAC_PCU_TPC          0x0002808c 21:16  0 1 1 2 1
>  mc_mac_pcu_tpc_cts_pwr                                63      MAC_PCU_TPC          0x0002808c 13:8   0 1 1 2 1
>  mc_mac_pcu_tpc_ack_pwr                                63      MAC_PCU_TPC          0x0002808c 5:0    0 1 1 2 1
226c262
<  mc_mac_pcu_tx_frame_cnt_value     0   mac_pcu_MAC_PCU_TX_FRAME_CNT   0x00028090 31:0   0 1 1 2 1
---
>  mc_mac_pcu_tx_frame_cnt_value                         0       MAC_PCU_TX_FRAME_CNT 0x00028090 31:0   0 1 1 2 1
228c264
<  mc_mac_pcu_rx_frame_cnt_value     0   mac_pcu_MAC_PCU_RX_FRAME_CNT   0x00028094 31:0   0 1 1 2 1
---
>  mc_mac_pcu_rx_frame_cnt_value                         0       MAC_PCU_RX_FRAME_CNT 0x00028094 31:0   0 1 1 2 1
230c266
<  mc_mac_pcu_rx_clear_cnt_value     0   mac_pcu_MAC_PCU_RX_CLEAR_CNT   0x00028098 31:0   0 1 1 2 1
---
>  mc_mac_pcu_rx_clear_cnt_value                         0       MAC_PCU_RX_CLEAR_CNT 0x00028098 31:0   0 1 1 2 1
232c268
<  mc_mac_pcu_cycle_cnt_value        0   mac_pcu_MAC_PCU_CYCLE_CNT      0x0002809c 31:0   0 1 1 2 1
---
>  mc_mac_pcu_cycle_cnt_value                            0       MAC_PCU_CYCLE_CNT    0x0002809c 31:0   0 1 1 2 1
234c270
<  mc_ack_cts_enable                 1   mac_pcu_MAC_PCU_QUIET_TIME_1   0x000280a0 17     0 1 1 2 1
---
>  mc_mac_pcu_quiet_time_1_ack_cts_enable                1       MAC_PCU_QUIET_TIME_1 0x000280a0 17     0 1 1 2 1
236c272
<  mc_mac_pcu_quiet_time_2_duration  0   mac_pcu_MAC_PCU_QUIET_TIME_2   0x000280a4 31:16  0 1 1 2 1
---
>  mc_mac_pcu_quiet_time_2_duration                      0       MAC_PCU_QUIET_TIME_2 0x000280a4 31:16  0 1 1 2 1
238,240c274,276
<  mc_byte_offset                    0   mac_pcu_MAC_PCU_QOS_NO_ACK     0x000280a8 8:7    0 1 1 2 1
<  mc_bit_offset                     5   mac_pcu_MAC_PCU_QOS_NO_ACK     0x000280a8 6:4    0 1 1 2 1
<  mc_two_bit_values                 2   mac_pcu_MAC_PCU_QOS_NO_ACK     0x000280a8 3:0    0 1 1 2 1
---
>  mc_mac_pcu_qos_no_ack_byte_offset                     0       MAC_PCU_QOS_NO_ACK   0x000280a8 8:7    0 1 1 2 1
>  mc_mac_pcu_qos_no_ack_bit_offset                      5       MAC_PCU_QOS_NO_ACK   0x000280a8 6:4    0 1 1 2 1
>  mc_mac_pcu_qos_no_ack_two_bit_values                  2       MAC_PCU_QOS_NO_ACK   0x000280a8 3:0    0 1 1 2 1
242c278
<  mc_mac_pcu_phy_error_mask_value   0   mac_pcu_MAC_PCU_PHY_ERROR_MASK 0x000280ac 31:0   0 1 1 2 1
---
>  mc_mac_pcu_phy_error_mask_value                       0       MAC_PCU_PHY_ERROR_MASK 0x000280ac 31:0   0 1 1 2 1
244c280
<  mc_mac_pcu_xrlat_value            0   mac_pcu_MAC_PCU_XRLAT          0x000280b0 11:0   0 1 1 2 1
---
>  mc_mac_pcu_xrlat_value                                0       MAC_PCU_XRLAT        0x000280b0 11:0   0 1 1 2 1
246,247c282,283
<  mc_reg_rd_enable                  0   mac_pcu_MAC_PCU_RXBUF          0x000280b4 11     0 1 1 2 1
<  mc_high_priority_thrshd           256 mac_pcu_MAC_PCU_RXBUF          0x000280b4 10:0   0 1 1 2 1
---
>  mc_mac_pcu_rxbuf_reg_rd_enable                        0       MAC_PCU_RXBUF        0x000280b4 11     0 1 1 2 1
>  mc_mac_pcu_rxbuf_high_priority_thrshd                 256     MAC_PCU_RXBUF        0x000280b4 10:0   0 1 1 2 1
249,257c285,293
<  mc_mac_pcu_mic_qos_control_enable 0   mac_pcu_MAC_PCU_MIC_QOS_CONTROL 0x000280b8 16     0 1 1 2 1
<  mc_value_7                        0   mac_pcu_MAC_PCU_MIC_QOS_CONTROL 0x000280b8 15:14  0 1 1 2 1
<  mc_value_6                        0   mac_pcu_MAC_PCU_MIC_QOS_CONTROL 0x000280b8 13:12  0 1 1 2 1
<  mc_value_5                        0   mac_pcu_MAC_PCU_MIC_QOS_CONTROL 0x000280b8 11:10  0 1 1 2 1
<  mc_value_4                        0   mac_pcu_MAC_PCU_MIC_QOS_CONTROL 0x000280b8 9:8    0 1 1 2 1
<  mc_value_3                        2   mac_pcu_MAC_PCU_MIC_QOS_CONTROL 0x000280b8 7:6    0 1 1 2 1
<  mc_value_2                        2   mac_pcu_MAC_PCU_MIC_QOS_CONTROL 0x000280b8 5:4    0 1 1 2 1
<  mc_value_1                        2   mac_pcu_MAC_PCU_MIC_QOS_CONTROL 0x000280b8 3:2    0 1 1 2 1
<  mc_value_0                        2   mac_pcu_MAC_PCU_MIC_QOS_CONTROL 0x000280b8 1:0    0 1 1 2 1
---
>  mc_mac_pcu_mic_qos_control_enable                     0       MAC_PCU_MIC_QOS_CONTROL 0x000280b8 16     0 1 1 2 1
>  mc_mac_pcu_mic_qos_control_value_7                    0       MAC_PCU_MIC_QOS_CONTROL 0x000280b8 15:14  0 1 1 2 1
>  mc_mac_pcu_mic_qos_control_value_6                    0       MAC_PCU_MIC_QOS_CONTROL 0x000280b8 13:12  0 1 1 2 1
>  mc_mac_pcu_mic_qos_control_value_5                    0       MAC_PCU_MIC_QOS_CONTROL 0x000280b8 11:10  0 1 1 2 1
>  mc_mac_pcu_mic_qos_control_value_4                    0       MAC_PCU_MIC_QOS_CONTROL 0x000280b8 9:8    0 1 1 2 1
>  mc_mac_pcu_mic_qos_control_value_3                    2       MAC_PCU_MIC_QOS_CONTROL 0x000280b8 7:6    0 1 1 2 1
>  mc_mac_pcu_mic_qos_control_value_2                    2       MAC_PCU_MIC_QOS_CONTROL 0x000280b8 5:4    0 1 1 2 1
>  mc_mac_pcu_mic_qos_control_value_1                    2       MAC_PCU_MIC_QOS_CONTROL 0x000280b8 3:2    0 1 1 2 1
>  mc_mac_pcu_mic_qos_control_value_0                    2       MAC_PCU_MIC_QOS_CONTROL 0x000280b8 1:0    0 1 1 2 1
259,266c295,302
<  mc_mac_pcu_mic_qos_select_value_7 0   mac_pcu_MAC_PCU_MIC_QOS_SELECT 0x000280bc 31:28  0 1 1 2 1
<  mc_mac_pcu_mic_qos_select_value_6 0   mac_pcu_MAC_PCU_MIC_QOS_SELECT 0x000280bc 27:24  0 1 1 2 1
<  mc_mac_pcu_mic_qos_select_value_5 0   mac_pcu_MAC_PCU_MIC_QOS_SELECT 0x000280bc 23:20  0 1 1 2 1
<  mc_mac_pcu_mic_qos_select_value_4 0   mac_pcu_MAC_PCU_MIC_QOS_SELECT 0x000280bc 19:16  0 1 1 2 1
<  mc_mac_pcu_mic_qos_select_value_3 3   mac_pcu_MAC_PCU_MIC_QOS_SELECT 0x000280bc 15:12  0 1 1 2 1
<  mc_mac_pcu_mic_qos_select_value_2 2   mac_pcu_MAC_PCU_MIC_QOS_SELECT 0x000280bc 11:8   0 1 1 2 1
<  mc_mac_pcu_mic_qos_select_value_1 1   mac_pcu_MAC_PCU_MIC_QOS_SELECT 0x000280bc 7:4    0 1 1 2 1
<  mc_mac_pcu_mic_qos_select_value_0 0   mac_pcu_MAC_PCU_MIC_QOS_SELECT 0x000280bc 3:0    0 1 1 2 1
---
>  mc_mac_pcu_mic_qos_select_value_7                     0       MAC_PCU_MIC_QOS_SELECT 0x000280bc 31:28  0 1 1 2 1
>  mc_mac_pcu_mic_qos_select_value_6                     0       MAC_PCU_MIC_QOS_SELECT 0x000280bc 27:24  0 1 1 2 1
>  mc_mac_pcu_mic_qos_select_value_5                     0       MAC_PCU_MIC_QOS_SELECT 0x000280bc 23:20  0 1 1 2 1
>  mc_mac_pcu_mic_qos_select_value_4                     0       MAC_PCU_MIC_QOS_SELECT 0x000280bc 19:16  0 1 1 2 1
>  mc_mac_pcu_mic_qos_select_value_3                     3       MAC_PCU_MIC_QOS_SELECT 0x000280bc 15:12  0 1 1 2 1
>  mc_mac_pcu_mic_qos_select_value_2                     2       MAC_PCU_MIC_QOS_SELECT 0x000280bc 11:8   0 1 1 2 1
>  mc_mac_pcu_mic_qos_select_value_1                     1       MAC_PCU_MIC_QOS_SELECT 0x000280bc 7:4    0 1 1 2 1
>  mc_mac_pcu_mic_qos_select_value_0                     0       MAC_PCU_MIC_QOS_SELECT 0x000280bc 3:0    0 1 1 2 1
268,289c304,325
<  mc_mac_pcu_misc_mode_debug_mode   0   mac_pcu_MAC_PCU_MISC_MODE      0x000280c0 31:30  0 1 1 2 1
<  mc_use_eop_ptr_for_dma_wr         0   mac_pcu_MAC_PCU_MISC_MODE      0x000280c0 29     0 1 1 2 1
<  mc_always_perform_key_search      0   mac_pcu_MAC_PCU_MISC_MODE      0x000280c0 28     0 1 1 2 1
<  mc_sel_evm                        1   mac_pcu_MAC_PCU_MISC_MODE      0x000280c0 27     0 1 1 2 1
<  mc_clear_ba_valid                 0   mac_pcu_MAC_PCU_MISC_MODE      0x000280c0 26     0 1 1 2 1
<  mc_clear_first_hcf                0   mac_pcu_MAC_PCU_MISC_MODE      0x000280c0 25     0 1 1 2 1
<  mc_clear_vmf                      0   mac_pcu_MAC_PCU_MISC_MODE      0x000280c0 24     0 1 1 2 1
<  mc_rx_hcf_poll_enable             1   mac_pcu_MAC_PCU_MISC_MODE      0x000280c0 23     0 1 1 2 1
<  mc_hcf_poll_cancels_nav           1   mac_pcu_MAC_PCU_MISC_MODE      0x000280c0 22     0 1 1 2 1
<  mc_tbtt_protect                   1   mac_pcu_MAC_PCU_MISC_MODE      0x000280c0 21     0 1 1 2 1
<  mc_bt_ant_prevents_rx             1   mac_pcu_MAC_PCU_MISC_MODE      0x000280c0 20     0 1 1 2 1
<  mc_force_quiet_collision          0   mac_pcu_MAC_PCU_MISC_MODE      0x000280c0 18     0 1 1 2 1
<  mc_miss_beacon_in_sleep           1   mac_pcu_MAC_PCU_MISC_MODE      0x000280c0 14     0 1 1 2 1
<  mc_txop_tbtt_limit_enable         0   mac_pcu_MAC_PCU_MISC_MODE      0x000280c0 12     0 1 1 2 1
<  mc_kc_rx_ant_update               1   mac_pcu_MAC_PCU_MISC_MODE      0x000280c0 11     0 1 1 2 1
<  mc_debug_mode_sifs                0   mac_pcu_MAC_PCU_MISC_MODE      0x000280c0 10     0 1 1 2 1
<  mc_debug_mode_ba_bitmap           0   mac_pcu_MAC_PCU_MISC_MODE      0x000280c0 9      0 1 1 2 1
<  mc_cck_sifs_mode                  0   mac_pcu_MAC_PCU_MISC_MODE      0x000280c0 4      0 1 1 2 1
<  mc_tx_add_tsf                     0   mac_pcu_MAC_PCU_MISC_MODE      0x000280c0 3      0 1 1 2 1
<  mc_mic_new_location_enable        0   mac_pcu_MAC_PCU_MISC_MODE      0x000280c0 2      0 1 1 2 1
<  mc_debug_mode_ad                  0   mac_pcu_MAC_PCU_MISC_MODE      0x000280c0 1      0 1 1 2 1
<  mc_bssid_match_force              0   mac_pcu_MAC_PCU_MISC_MODE      0x000280c0 0      0 1 1 2 1
---
>  mc_mac_pcu_misc_mode_debug_mode                       0       MAC_PCU_MISC_MODE    0x000280c0 31:30  0 1 1 2 1
>  mc_mac_pcu_misc_mode_use_eop_ptr_for_dma_wr           0       MAC_PCU_MISC_MODE    0x000280c0 29     0 1 1 2 1
>  mc_mac_pcu_misc_mode_always_perform_key_search        0       MAC_PCU_MISC_MODE    0x000280c0 28     0 1 1 2 1
>  mc_mac_pcu_misc_mode_sel_evm                          1       MAC_PCU_MISC_MODE    0x000280c0 27     0 1 1 2 1
>  mc_mac_pcu_misc_mode_clear_ba_valid                   0       MAC_PCU_MISC_MODE    0x000280c0 26     0 1 1 2 1
>  mc_mac_pcu_misc_mode_clear_first_hcf                  0       MAC_PCU_MISC_MODE    0x000280c0 25     0 1 1 2 1
>  mc_mac_pcu_misc_mode_clear_vmf                        0       MAC_PCU_MISC_MODE    0x000280c0 24     0 1 1 2 1
>  mc_mac_pcu_misc_mode_rx_hcf_poll_enable               1       MAC_PCU_MISC_MODE    0x000280c0 23     0 1 1 2 1
>  mc_mac_pcu_misc_mode_hcf_poll_cancels_nav             1       MAC_PCU_MISC_MODE    0x000280c0 22     0 1 1 2 1
>  mc_mac_pcu_misc_mode_tbtt_protect                     1       MAC_PCU_MISC_MODE    0x000280c0 21     0 1 1 2 1
>  mc_mac_pcu_misc_mode_bt_ant_prevents_rx               1       MAC_PCU_MISC_MODE    0x000280c0 20     0 1 1 2 1
>  mc_mac_pcu_misc_mode_force_quiet_collision            0       MAC_PCU_MISC_MODE    0x000280c0 18     0 1 1 2 1
>  mc_mac_pcu_misc_mode_miss_beacon_in_sleep             1       MAC_PCU_MISC_MODE    0x000280c0 14     0 1 1 2 1
>  mc_mac_pcu_misc_mode_txop_tbtt_limit_enable           0       MAC_PCU_MISC_MODE    0x000280c0 12     0 1 1 2 1
>  mc_mac_pcu_misc_mode_kc_rx_ant_update                 1       MAC_PCU_MISC_MODE    0x000280c0 11     0 1 1 2 1
>  mc_mac_pcu_misc_mode_debug_mode_sifs                  0       MAC_PCU_MISC_MODE    0x000280c0 10     0 1 1 2 1
>  mc_mac_pcu_misc_mode_debug_mode_ba_bitmap             0       MAC_PCU_MISC_MODE    0x000280c0 9      0 1 1 2 1
>  mc_mac_pcu_misc_mode_cck_sifs_mode                    0       MAC_PCU_MISC_MODE    0x000280c0 4      0 1 1 2 1
>  mc_mac_pcu_misc_mode_tx_add_tsf                       0       MAC_PCU_MISC_MODE    0x000280c0 3      0 1 1 2 1
>  mc_mac_pcu_misc_mode_mic_new_location_enable          0       MAC_PCU_MISC_MODE    0x000280c0 2      0 1 1 2 1
>  mc_mac_pcu_misc_mode_debug_mode_ad                    0       MAC_PCU_MISC_MODE    0x000280c0 1      0 1 1 2 1
>  mc_mac_pcu_misc_mode_bssid_match_force                0       MAC_PCU_MISC_MODE    0x000280c0 0      0 1 1 2 1
291c327
<  mc_mac_pcu_filter_ofdm_cnt_value  0   mac_pcu_MAC_PCU_FILTER_OFDM_CNT 0x000280c4 23:0   0 1 1 2 1
---
>  mc_mac_pcu_filter_ofdm_cnt_value                      0       MAC_PCU_FILTER_OFDM_CNT 0x000280c4 23:0   0 1 1 2 1
293c329
<  mc_mac_pcu_filter_cck_cnt_value   0   mac_pcu_MAC_PCU_FILTER_CCK_CNT 0x000280c8 23:0   0 1 1 2 1
---
>  mc_mac_pcu_filter_cck_cnt_value                       0       MAC_PCU_FILTER_CCK_CNT 0x000280c8 23:0   0 1 1 2 1
295c331
<  mc_mac_pcu_phy_err_cnt_1_value    0   mac_pcu_MAC_PCU_PHY_ERR_CNT_1  0x000280cc 23:0   0 1 1 2 1
---
>  mc_mac_pcu_phy_err_cnt_1_value                        0       MAC_PCU_PHY_ERR_CNT_1 0x000280cc 23:0   0 1 1 2 1
297c333
<  mc_mac_pcu_phy_err_cnt_1_mask_value 0   mac_pcu_MAC_PCU_PHY_ERR_CNT_1_MASK 0x000280d0 31:0   0 1 1 2 1
---
>  mc_mac_pcu_phy_err_cnt_1_mask_value                   0       MAC_PCU_PHY_ERR_CNT_1_MASK 0x000280d0 31:0   0 1 1 2 1
299c335
<  mc_mac_pcu_phy_err_cnt_2_value    0   mac_pcu_MAC_PCU_PHY_ERR_CNT_2  0x000280d4 23:0   0 1 1 2 1
---
>  mc_mac_pcu_phy_err_cnt_2_value                        0       MAC_PCU_PHY_ERR_CNT_2 0x000280d4 23:0   0 1 1 2 1
301c337
<  mc_mac_pcu_phy_err_cnt_2_mask_value 0   mac_pcu_MAC_PCU_PHY_ERR_CNT_2_MASK 0x000280d8 31:0   0 1 1 2 1
---
>  mc_mac_pcu_phy_err_cnt_2_mask_value                   0       MAC_PCU_PHY_ERR_CNT_2_MASK 0x000280d8 31:0   0 1 1 2 1
303c339
<  mc_mac_pcu_tsf_threshold_value    65535 mac_pcu_MAC_PCU_TSF_THRESHOLD  0x000280dc 15:0   0 1 1 2 1
---
>  mc_mac_pcu_tsf_threshold_value                        65535   MAC_PCU_TSF_THRESHOLD 0x000280dc 15:0   0 1 1 2 1
305c341
<  mc_mac_pcu_phy_error_eifs_mask_value 0   mac_pcu_MAC_PCU_PHY_ERROR_EIFS_MASK 0x000280e0 31:0   0 1 1 2 1
---
>  mc_mac_pcu_phy_error_eifs_mask_value                  0       MAC_PCU_PHY_ERROR_EIFS_MASK 0x000280e0 31:0   0 1 1 2 1
307c343
<  mc_mac_pcu_phy_err_cnt_3_value    0   mac_pcu_MAC_PCU_PHY_ERR_CNT_3  0x000280e4 23:0   0 1 1 2 1
---
>  mc_mac_pcu_phy_err_cnt_3_value                        0       MAC_PCU_PHY_ERR_CNT_3 0x000280e4 23:0   0 1 1 2 1
309c345
<  mc_mac_pcu_phy_err_cnt_3_mask_value 0   mac_pcu_MAC_PCU_PHY_ERR_CNT_3_MASK 0x000280e8 31:0   0 1 1 2 1
---
>  mc_mac_pcu_phy_err_cnt_3_mask_value                   0       MAC_PCU_PHY_ERR_CNT_3_MASK 0x000280e8 31:0   0 1 1 2 1
311,319c347,355
<  mc_first_slot_time                24  mac_pcu_MAC_PCU_BLUETOOTH_MODE 0x000280ec 31:24  0 1 1 2 1
<  mc_mac_pcu_bluetooth_mode_priority_time 18  mac_pcu_MAC_PCU_BLUETOOTH_MODE 0x000280ec 23:18  0 1 1 2 1
<  mc_rx_clear_polarity              0   mac_pcu_MAC_PCU_BLUETOOTH_MODE 0x000280ec 17     0 1 1 2 1
<  mc_qcu_thresh                     3   mac_pcu_MAC_PCU_BLUETOOTH_MODE 0x000280ec 16:13  0 1 1 2 1
<  mc_quiet                          0   mac_pcu_MAC_PCU_BLUETOOTH_MODE 0x000280ec 12     0 1 1 2 1
<  mc_mac_pcu_bluetooth_mode_mode    3   mac_pcu_MAC_PCU_BLUETOOTH_MODE 0x000280ec 11:10  0 1 1 2 1
<  mc_tx_frame_extend                0   mac_pcu_MAC_PCU_BLUETOOTH_MODE 0x000280ec 9      0 1 1 2 1
<  mc_tx_state_extend                0   mac_pcu_MAC_PCU_BLUETOOTH_MODE 0x000280ec 8      0 1 1 2 1
<  mc_time_extend                    0   mac_pcu_MAC_PCU_BLUETOOTH_MODE 0x000280ec 7:0    0 1 1 2 1
---
>  mc_mac_pcu_bluetooth_mode_first_slot_time             24      MAC_PCU_BLUETOOTH_MODE 0x000280ec 31:24  0 1 1 2 1
>  mc_mac_pcu_bluetooth_mode_priority_time               18      MAC_PCU_BLUETOOTH_MODE 0x000280ec 23:18  0 1 1 2 1
>  mc_mac_pcu_bluetooth_mode_rx_clear_polarity           0       MAC_PCU_BLUETOOTH_MODE 0x000280ec 17     0 1 1 2 1
>  mc_mac_pcu_bluetooth_mode_qcu_thresh                  3       MAC_PCU_BLUETOOTH_MODE 0x000280ec 16:13  0 1 1 2 1
>  mc_mac_pcu_bluetooth_mode_quiet                       0       MAC_PCU_BLUETOOTH_MODE 0x000280ec 12     0 1 1 2 1
>  mc_mac_pcu_bluetooth_mode_mode                        3       MAC_PCU_BLUETOOTH_MODE 0x000280ec 11:10  0 1 1 2 1
>  mc_mac_pcu_bluetooth_mode_tx_frame_extend             0       MAC_PCU_BLUETOOTH_MODE 0x000280ec 9      0 1 1 2 1
>  mc_mac_pcu_bluetooth_mode_tx_state_extend             0       MAC_PCU_BLUETOOTH_MODE 0x000280ec 8      0 1 1 2 1
>  mc_mac_pcu_bluetooth_mode_time_extend                 0       MAC_PCU_BLUETOOTH_MODE 0x000280ec 7:0    0 1 1 2 1
321,322c357,358
<  mc_wl_weight                      64164 mac_pcu_MAC_PCU_BLUETOOTH_WEIGHTS 0x000280f0 31:16  0 1 1 2 1
<  mc_bt_weight                      64080 mac_pcu_MAC_PCU_BLUETOOTH_WEIGHTS 0x000280f0 15:0   0 1 1 2 1
---
>  mc_mac_pcu_bluetooth_weights_wl_weight                64164   MAC_PCU_BLUETOOTH_WEIGHTS 0x000280f0 31:16  0 1 1 2 1
>  mc_mac_pcu_bluetooth_weights_bt_weight                64080   MAC_PCU_BLUETOOTH_WEIGHTS 0x000280f0 15:0   0 1 1 2 1
324,337c360,373
<  mc_phy_err_bt_coll_enable         0   mac_pcu_MAC_PCU_BLUETOOTH_MODE2 0x000280f4 31     0 1 1 2 1
<  mc_interrupt_enable               0   mac_pcu_MAC_PCU_BLUETOOTH_MODE2 0x000280f4 30     0 1 1 2 1
<  mc_tsf_bt_priority_ctrl           0   mac_pcu_MAC_PCU_BLUETOOTH_MODE2 0x000280f4 29:28  0 1 1 2 1
<  mc_tsf_bt_active_ctrl             0   mac_pcu_MAC_PCU_BLUETOOTH_MODE2 0x000280f4 27:26  0 1 1 2 1
<  mc_rs_discard_extend              0   mac_pcu_MAC_PCU_BLUETOOTH_MODE2 0x000280f4 25     0 1 1 2 1
<  mc_wl_txrx_separate               0   mac_pcu_MAC_PCU_BLUETOOTH_MODE2 0x000280f4 24     0 1 1 2 1
<  mc_wl_active_mode                 0   mac_pcu_MAC_PCU_BLUETOOTH_MODE2 0x000280f4 23:22  0 1 1 2 1
<  mc_quiet_2_wire                   0   mac_pcu_MAC_PCU_BLUETOOTH_MODE2 0x000280f4 21     0 1 1 2 1
<  mc_disable_bt_ant                 0   mac_pcu_MAC_PCU_BLUETOOTH_MODE2 0x000280f4 20     0 1 1 2 1
<  mc_protect_bt_after_wakeup        0   mac_pcu_MAC_PCU_BLUETOOTH_MODE2 0x000280f4 19     0 1 1 2 1
<  mc_sleep_allow_bt_access          1   mac_pcu_MAC_PCU_BLUETOOTH_MODE2 0x000280f4 17     0 1 1 2 1
<  mc_hold_rx_clear                  0   mac_pcu_MAC_PCU_BLUETOOTH_MODE2 0x000280f4 16     0 1 1 2 1
<  mc_bcn_miss_cnt                   0   mac_pcu_MAC_PCU_BLUETOOTH_MODE2 0x000280f4 15:8   0 0 1 2 1
<  mc_bcn_miss_thresh                0   mac_pcu_MAC_PCU_BLUETOOTH_MODE2 0x000280f4 7:0    0 1 1 2 1
---
>  mc_mac_pcu_bluetooth_mode2_phy_err_bt_coll_enable     0       MAC_PCU_BLUETOOTH_MODE2 0x000280f4 31     0 1 1 2 1
>  mc_mac_pcu_bluetooth_mode2_interrupt_enable           0       MAC_PCU_BLUETOOTH_MODE2 0x000280f4 30     0 1 1 2 1
>  mc_mac_pcu_bluetooth_mode2_tsf_bt_priority_ctrl       0       MAC_PCU_BLUETOOTH_MODE2 0x000280f4 29:28  0 1 1 2 1
>  mc_mac_pcu_bluetooth_mode2_tsf_bt_active_ctrl         0       MAC_PCU_BLUETOOTH_MODE2 0x000280f4 27:26  0 1 1 2 1
>  mc_mac_pcu_bluetooth_mode2_rs_discard_extend          0       MAC_PCU_BLUETOOTH_MODE2 0x000280f4 25     0 1 1 2 1
>  mc_mac_pcu_bluetooth_mode2_wl_txrx_separate           0       MAC_PCU_BLUETOOTH_MODE2 0x000280f4 24     0 1 1 2 1
>  mc_mac_pcu_bluetooth_mode2_wl_active_mode             0       MAC_PCU_BLUETOOTH_MODE2 0x000280f4 23:22  0 1 1 2 1
>  mc_mac_pcu_bluetooth_mode2_quiet_2_wire               0       MAC_PCU_BLUETOOTH_MODE2 0x000280f4 21     0 1 1 2 1
>  mc_mac_pcu_bluetooth_mode2_disable_bt_ant             0       MAC_PCU_BLUETOOTH_MODE2 0x000280f4 20     0 1 1 2 1
>  mc_mac_pcu_bluetooth_mode2_protect_bt_after_wakeup    0       MAC_PCU_BLUETOOTH_MODE2 0x000280f4 19     0 1 1 2 1
>  mc_mac_pcu_bluetooth_mode2_sleep_allow_bt_access      1       MAC_PCU_BLUETOOTH_MODE2 0x000280f4 17     0 1 1 2 1
>  mc_mac_pcu_bluetooth_mode2_hold_rx_clear              0       MAC_PCU_BLUETOOTH_MODE2 0x000280f4 16     0 1 1 2 1
>  mc_mac_pcu_bluetooth_mode2_bcn_miss_cnt               0       MAC_PCU_BLUETOOTH_MODE2 0x000280f4 15:8   0 0 1 2 1
>  mc_mac_pcu_bluetooth_mode2_bcn_miss_thresh            0       MAC_PCU_BLUETOOTH_MODE2 0x000280f4 7:0    0 1 1 2 1
339,341c375,377
<  mc_ack_shift                      3   mac_pcu_MAC_PCU_TXSIFS         0x000280f8 14:12  0 1 1 2 1
<  mc_mac_pcu_txsifs_tx_latency      2   mac_pcu_MAC_PCU_TXSIFS         0x000280f8 11:8   0 1 1 2 1
<  mc_sifs_time                      16  mac_pcu_MAC_PCU_TXSIFS         0x000280f8 7:0    0 1 1 2 1
---
>  mc_mac_pcu_txsifs_ack_shift                           3       MAC_PCU_TXSIFS       0x000280f8 14:12  0 1 1 2 1
>  mc_mac_pcu_txsifs_tx_latency                          2       MAC_PCU_TXSIFS       0x000280f8 11:8   0 1 1 2 1
>  mc_mac_pcu_txsifs_sifs_time                           16      MAC_PCU_TXSIFS       0x000280f8 7:0    0 1 1 2 1
343c379
<  mc_mac_pcu_txop_x_value           0   mac_pcu_MAC_PCU_TXOP_X         0x000280fc 7:0    0 1 1 2 1
---
>  mc_mac_pcu_txop_x_value                               0       MAC_PCU_TXOP_X       0x000280fc 7:0    0 1 1 2 1
345,348c381,384
<  mc_mac_pcu_txop_0_3_value_3       0   mac_pcu_MAC_PCU_TXOP_0_3       0x00028100 31:24  0 1 1 2 1
<  mc_mac_pcu_txop_0_3_value_2       0   mac_pcu_MAC_PCU_TXOP_0_3       0x00028100 23:16  0 1 1 2 1
<  mc_mac_pcu_txop_0_3_value_1       0   mac_pcu_MAC_PCU_TXOP_0_3       0x00028100 15:8   0 1 1 2 1
<  mc_mac_pcu_txop_0_3_value_0       0   mac_pcu_MAC_PCU_TXOP_0_3       0x00028100 7:0    0 1 1 2 1
---
>  mc_mac_pcu_txop_0_3_value_3                           0       MAC_PCU_TXOP_0_3     0x00028100 31:24  0 1 1 2 1
>  mc_mac_pcu_txop_0_3_value_2                           0       MAC_PCU_TXOP_0_3     0x00028100 23:16  0 1 1 2 1
>  mc_mac_pcu_txop_0_3_value_1                           0       MAC_PCU_TXOP_0_3     0x00028100 15:8   0 1 1 2 1
>  mc_mac_pcu_txop_0_3_value_0                           0       MAC_PCU_TXOP_0_3     0x00028100 7:0    0 1 1 2 1
350,353c386,389
<  mc_mac_pcu_txop_4_7_value_7       0   mac_pcu_MAC_PCU_TXOP_4_7       0x00028104 31:24  0 1 1 2 1
<  mc_mac_pcu_txop_4_7_value_6       0   mac_pcu_MAC_PCU_TXOP_4_7       0x00028104 23:16  0 1 1 2 1
<  mc_mac_pcu_txop_4_7_value_5       0   mac_pcu_MAC_PCU_TXOP_4_7       0x00028104 15:8   0 1 1 2 1
<  mc_mac_pcu_txop_4_7_value_4       0   mac_pcu_MAC_PCU_TXOP_4_7       0x00028104 7:0    0 1 1 2 1
---
>  mc_mac_pcu_txop_4_7_value_7                           0       MAC_PCU_TXOP_4_7     0x00028104 31:24  0 1 1 2 1
>  mc_mac_pcu_txop_4_7_value_6                           0       MAC_PCU_TXOP_4_7     0x00028104 23:16  0 1 1 2 1
>  mc_mac_pcu_txop_4_7_value_5                           0       MAC_PCU_TXOP_4_7     0x00028104 15:8   0 1 1 2 1
>  mc_mac_pcu_txop_4_7_value_4                           0       MAC_PCU_TXOP_4_7     0x00028104 7:0    0 1 1 2 1
355,358c391,394
<  mc_value_11                       0   mac_pcu_MAC_PCU_TXOP_8_11      0x00028108 31:24  0 1 1 2 1
<  mc_value_10                       0   mac_pcu_MAC_PCU_TXOP_8_11      0x00028108 23:16  0 1 1 2 1
<  mc_value_9                        0   mac_pcu_MAC_PCU_TXOP_8_11      0x00028108 15:8   0 1 1 2 1
<  mc_value_8                        0   mac_pcu_MAC_PCU_TXOP_8_11      0x00028108 7:0    0 1 1 2 1
---
>  mc_mac_pcu_txop_8_11_value_11                         0       MAC_PCU_TXOP_8_11    0x00028108 31:24  0 1 1 2 1
>  mc_mac_pcu_txop_8_11_value_10                         0       MAC_PCU_TXOP_8_11    0x00028108 23:16  0 1 1 2 1
>  mc_mac_pcu_txop_8_11_value_9                          0       MAC_PCU_TXOP_8_11    0x00028108 15:8   0 1 1 2 1
>  mc_mac_pcu_txop_8_11_value_8                          0       MAC_PCU_TXOP_8_11    0x00028108 7:0    0 1 1 2 1
360,363c396,399
<  mc_value_15                       0   mac_pcu_MAC_PCU_TXOP_12_15     0x0002810c 31:24  0 1 1 2 1
<  mc_value_14                       0   mac_pcu_MAC_PCU_TXOP_12_15     0x0002810c 23:16  0 1 1 2 1
<  mc_value_13                       0   mac_pcu_MAC_PCU_TXOP_12_15     0x0002810c 15:8   0 1 1 2 1
<  mc_value_12                       0   mac_pcu_MAC_PCU_TXOP_12_15     0x0002810c 7:0    0 1 1 2 1
---
>  mc_mac_pcu_txop_12_15_value_15                        0       MAC_PCU_TXOP_12_15   0x0002810c 31:24  0 1 1 2 1
>  mc_mac_pcu_txop_12_15_value_14                        0       MAC_PCU_TXOP_12_15   0x0002810c 23:16  0 1 1 2 1
>  mc_mac_pcu_txop_12_15_value_13                        0       MAC_PCU_TXOP_12_15   0x0002810c 15:8   0 1 1 2 1
>  mc_mac_pcu_txop_12_15_value_12                        0       MAC_PCU_TXOP_12_15   0x0002810c 7:0    0 1 1 2 1
365,371c401,407
<  mc_diag_mode                      8744 mac_pcu_MAC_PCU_LOGIC_ANALYZER 0x00028110 31:18  0 1 1 2 1
<  mc_int_addr                       0   mac_pcu_MAC_PCU_LOGIC_ANALYZER 0x00028110 17:8   0 0 1 2 1
<  mc_qcu_sel                        1   mac_pcu_MAC_PCU_LOGIC_ANALYZER 0x00028110 7:4    0 1 1 2 1
<  mc_mac_pcu_logic_analyzer_enable  0   mac_pcu_MAC_PCU_LOGIC_ANALYZER 0x00028110 3      0 1 1 2 1
<  mc_state                          0   mac_pcu_MAC_PCU_LOGIC_ANALYZER 0x00028110 2      0 0 1 2 1
<  mc_clear                          0   mac_pcu_MAC_PCU_LOGIC_ANALYZER 0x00028110 1      0 1 1 2 1
<  mc_hold                           0   mac_pcu_MAC_PCU_LOGIC_ANALYZER 0x00028110 0      0 1 1 2 1
---
>  mc_mac_pcu_logic_analyzer_diag_mode                   8744    MAC_PCU_LOGIC_ANALYZER 0x00028110 31:18  0 1 1 2 1
>  mc_mac_pcu_logic_analyzer_int_addr                    0       MAC_PCU_LOGIC_ANALYZER 0x00028110 17:8   0 0 1 2 1
>  mc_mac_pcu_logic_analyzer_qcu_sel                     1       MAC_PCU_LOGIC_ANALYZER 0x00028110 7:4    0 1 1 2 1
>  mc_mac_pcu_logic_analyzer_enable                      0       MAC_PCU_LOGIC_ANALYZER 0x00028110 3      0 1 1 2 1
>  mc_mac_pcu_logic_analyzer_state                       0       MAC_PCU_LOGIC_ANALYZER 0x00028110 2      0 0 1 2 1
>  mc_mac_pcu_logic_analyzer_clear                       0       MAC_PCU_LOGIC_ANALYZER 0x00028110 1      0 1 1 2 1
>  mc_mac_pcu_logic_analyzer_hold                        0       MAC_PCU_LOGIC_ANALYZER 0x00028110 0      0 1 1 2 1
373c409
<  mc_mask                           -1  mac_pcu_MAC_PCU_LOGIC_ANALYZER_32L 0x00028114 31:0   0 1 1 2 1
---
>  mc_mac_pcu_logic_analyzer_32l_mask                    -1      MAC_PCU_LOGIC_ANALYZER_32L 0x00028114 31:0   0 1 1 2 1
375c411
<  mc_mac_pcu_logic_analyzer_16u_mask 65535 mac_pcu_MAC_PCU_LOGIC_ANALYZER_16U 0x00028118 15:0   0 1 1 2 1
---
>  mc_mac_pcu_logic_analyzer_16u_mask                    65535   MAC_PCU_LOGIC_ANALYZER_16U 0x00028118 15:0   0 1 1 2 1
377,379c413,415
<  mc_mask3                          0   mac_pcu_MAC_PCU_PHY_ERR_CNT_MASK_CONT 0x0002811c 23:16  0 1 1 2 1
<  mc_mask2                          0   mac_pcu_MAC_PCU_PHY_ERR_CNT_MASK_CONT 0x0002811c 15:8   0 1 1 2 1
<  mc_mask1                          0   mac_pcu_MAC_PCU_PHY_ERR_CNT_MASK_CONT 0x0002811c 7:0    0 1 1 2 1
---
>  mc_mac_pcu_phy_err_cnt_mask_cont_mask3                0       MAC_PCU_PHY_ERR_CNT_MASK_CONT 0x0002811c 23:16  0 1 1 2 1
>  mc_mac_pcu_phy_err_cnt_mask_cont_mask2                0       MAC_PCU_PHY_ERR_CNT_MASK_CONT 0x0002811c 15:8   0 1 1 2 1
>  mc_mac_pcu_phy_err_cnt_mask_cont_mask1                0       MAC_PCU_PHY_ERR_CNT_MASK_CONT 0x0002811c 7:0    0 1 1 2 1
381,388c417,424
<  mc_ba_uses_ad1                    0   mac_pcu_MAC_PCU_AZIMUTH_MODE   0x00028120 7      0 1 1 2 1
<  mc_ack_cts_match_tx_ad2           1   mac_pcu_MAC_PCU_AZIMUTH_MODE   0x00028120 6      0 1 1 2 1
<  mc_tx_desc_en                     0   mac_pcu_MAC_PCU_AZIMUTH_MODE   0x00028120 5      0 1 1 2 1
<  mc_clk_en                         0   mac_pcu_MAC_PCU_AZIMUTH_MODE   0x00028120 4      0 1 1 2 1
<  mc_rx_tsf_status_sel              0   mac_pcu_MAC_PCU_AZIMUTH_MODE   0x00028120 3      0 1 1 2 1
<  mc_tx_tsf_status_sel              0   mac_pcu_MAC_PCU_AZIMUTH_MODE   0x00028120 2      0 1 1 2 1
<  mc_key_search_ad1                 0   mac_pcu_MAC_PCU_AZIMUTH_MODE   0x00028120 1      0 1 1 2 1
<  mc_disable_tsf_update             0   mac_pcu_MAC_PCU_AZIMUTH_MODE   0x00028120 0      0 1 1 2 1
---
>  mc_mac_pcu_azimuth_mode_ba_uses_ad1                   0       MAC_PCU_AZIMUTH_MODE 0x00028120 7      0 1 1 2 1
>  mc_mac_pcu_azimuth_mode_ack_cts_match_tx_ad2          1       MAC_PCU_AZIMUTH_MODE 0x00028120 6      0 1 1 2 1
>  mc_mac_pcu_azimuth_mode_tx_desc_en                    0       MAC_PCU_AZIMUTH_MODE 0x00028120 5      0 1 1 2 1
>  mc_mac_pcu_azimuth_mode_clk_en                        0       MAC_PCU_AZIMUTH_MODE 0x00028120 4      0 1 1 2 1
>  mc_mac_pcu_azimuth_mode_rx_tsf_status_sel             0       MAC_PCU_AZIMUTH_MODE 0x00028120 3      0 1 1 2 1
>  mc_mac_pcu_azimuth_mode_tx_tsf_status_sel             0       MAC_PCU_AZIMUTH_MODE 0x00028120 2      0 1 1 2 1
>  mc_mac_pcu_azimuth_mode_key_search_ad1                0       MAC_PCU_AZIMUTH_MODE 0x00028120 1      0 1 1 2 1
>  mc_mac_pcu_azimuth_mode_disable_tsf_update            0       MAC_PCU_AZIMUTH_MODE 0x00028120 0      0 1 1 2 1
390,394c426,430
<  mc_pifs_cycles                    1672 mac_pcu_MAC_PCU_20_40_MODE     0x00028124 15:4   0 1 1 2 1
<  mc_swamped_forces_rx_clear_ctl_idle 0   mac_pcu_MAC_PCU_20_40_MODE     0x00028124 3      0 1 1 2 1
<  mc_tx_ht20_on_ext_busy            0   mac_pcu_MAC_PCU_20_40_MODE     0x00028124 2      0 1 1 2 1
<  mc_ext_pifs_enable                0   mac_pcu_MAC_PCU_20_40_MODE     0x00028124 1      0 1 1 2 1
<  mc_joined_rx_clear                0   mac_pcu_MAC_PCU_20_40_MODE     0x00028124 0      0 1 1 2 1
---
>  mc_mac_pcu_20_40_mode_pifs_cycles                     1672    MAC_PCU_20_40_MODE   0x00028124 15:4   0 1 1 2 1
>  mc_mac_pcu_20_40_mode_swamped_forces_rx_clear_ctl_idle 0       MAC_PCU_20_40_MODE   0x00028124 3      0 1 1 2 1
>  mc_mac_pcu_20_40_mode_tx_ht20_on_ext_busy             0       MAC_PCU_20_40_MODE   0x00028124 2      0 1 1 2 1
>  mc_mac_pcu_20_40_mode_ext_pifs_enable                 0       MAC_PCU_20_40_MODE   0x00028124 1      0 1 1 2 1
>  mc_mac_pcu_20_40_mode_joined_rx_clear                 0       MAC_PCU_20_40_MODE   0x00028124 0      0 1 1 2 1
396c432
<  mc_mac_pcu_rx_clear_diff_cnt_value 0   mac_pcu_MAC_PCU_RX_CLEAR_DIFF_CNT 0x00028128 31:0   0 1 1 2 1
---
>  mc_mac_pcu_rx_clear_diff_cnt_value                    0       MAC_PCU_RX_CLEAR_DIFF_CNT 0x00028128 31:0   0 1 1 2 1
398c434
<  mc_mac_pcu_self_gen_antenna_mask_value 7   mac_pcu_MAC_PCU_SELF_GEN_ANTENNA_MASK 0x0002812c 2:0    0 1 1 2 1
---
>  mc_mac_pcu_self_gen_antenna_mask_value                7       MAC_PCU_SELF_GEN_ANTENNA_MASK 0x0002812c 2:0    0 1 1 2 1
400,406c436,442
<  mc_update_ba_bitmap_qos_null      0   mac_pcu_MAC_PCU_BA_BAR_CONTROL 0x00028130 12     0 1 1 2 1
<  mc_tx_ba_clear_ba_valid           0   mac_pcu_MAC_PCU_BA_BAR_CONTROL 0x00028130 11     0 1 1 2 1
<  mc_force_no_match                 0   mac_pcu_MAC_PCU_BA_BAR_CONTROL 0x00028130 10     0 1 1 2 1
<  mc_ack_policy_value               1   mac_pcu_MAC_PCU_BA_BAR_CONTROL 0x00028130 9      0 1 1 2 1
<  mc_compressed_value               1   mac_pcu_MAC_PCU_BA_BAR_CONTROL 0x00028130 8      0 1 1 2 1
<  mc_ack_policy_offset              0   mac_pcu_MAC_PCU_BA_BAR_CONTROL 0x00028130 7:4    0 1 1 2 1
<  mc_compressed_offset              2   mac_pcu_MAC_PCU_BA_BAR_CONTROL 0x00028130 3:0    0 1 1 2 1
---
>  mc_mac_pcu_ba_bar_control_update_ba_bitmap_qos_null   0       MAC_PCU_BA_BAR_CONTROL 0x00028130 12     0 1 1 2 1
>  mc_mac_pcu_ba_bar_control_tx_ba_clear_ba_valid        0       MAC_PCU_BA_BAR_CONTROL 0x00028130 11     0 1 1 2 1
>  mc_mac_pcu_ba_bar_control_force_no_match              0       MAC_PCU_BA_BAR_CONTROL 0x00028130 10     0 1 1 2 1
>  mc_mac_pcu_ba_bar_control_ack_policy_value            1       MAC_PCU_BA_BAR_CONTROL 0x00028130 9      0 1 1 2 1
>  mc_mac_pcu_ba_bar_control_compressed_value            1       MAC_PCU_BA_BAR_CONTROL 0x00028130 8      0 1 1 2 1
>  mc_mac_pcu_ba_bar_control_ack_policy_offset           0       MAC_PCU_BA_BAR_CONTROL 0x00028130 7:4    0 1 1 2 1
>  mc_mac_pcu_ba_bar_control_compressed_offset           2       MAC_PCU_BA_BAR_CONTROL 0x00028130 3:0    0 1 1 2 1
408,409c444,445
<  mc_min_length                     14  mac_pcu_MAC_PCU_LEGACY_PLCP_SPOOF 0x00028134 12:8   0 1 1 2 1
<  mc_eifs_minus_difs                0   mac_pcu_MAC_PCU_LEGACY_PLCP_SPOOF 0x00028134 7:0    0 1 1 2 1
---
>  mc_mac_pcu_legacy_plcp_spoof_min_length               14      MAC_PCU_LEGACY_PLCP_SPOOF 0x00028134 12:8   0 1 1 2 1
>  mc_mac_pcu_legacy_plcp_spoof_eifs_minus_difs          0       MAC_PCU_LEGACY_PLCP_SPOOF 0x00028134 7:0    0 1 1 2 1
411,412c447,448
<  mc_eifs_value                     0   mac_pcu_MAC_PCU_PHY_ERROR_MASK_CONT 0x00028138 23:16  0 1 1 2 1
<  mc_mask_value                     0   mac_pcu_MAC_PCU_PHY_ERROR_MASK_CONT 0x00028138 7:0    0 1 1 2 1
---
>  mc_mac_pcu_phy_error_mask_cont_eifs_value             0       MAC_PCU_PHY_ERROR_MASK_CONT 0x00028138 23:16  0 1 1 2 1
>  mc_mac_pcu_phy_error_mask_cont_mask_value             0       MAC_PCU_PHY_ERROR_MASK_CONT 0x00028138 7:0    0 1 1 2 1
414,418c450,454
<  mc_quiet_timer_enable             1   mac_pcu_MAC_PCU_TX_TIMER       0x0002813c 25     0 1 1 2 1
<  mc_quiet_timer                    4   mac_pcu_MAC_PCU_TX_TIMER       0x0002813c 24:20  0 1 1 2 1
<  mc_rifs_timer                     0   mac_pcu_MAC_PCU_TX_TIMER       0x0002813c 19:16  0 1 1 2 1
<  mc_tx_timer_enable                0   mac_pcu_MAC_PCU_TX_TIMER       0x0002813c 15     0 1 1 2 1
<  mc_tx_timer                       0   mac_pcu_MAC_PCU_TX_TIMER       0x0002813c 14:0   0 1 1 2 1
---
>  mc_mac_pcu_tx_timer_quiet_timer_enable                1       MAC_PCU_TX_TIMER     0x0002813c 25     0 1 1 2 1
>  mc_mac_pcu_tx_timer_quiet_timer                       4       MAC_PCU_TX_TIMER     0x0002813c 24:20  0 1 1 2 1
>  mc_mac_pcu_tx_timer_rifs_timer                        0       MAC_PCU_TX_TIMER     0x0002813c 19:16  0 1 1 2 1
>  mc_mac_pcu_tx_timer_tx_timer_enable                   0       MAC_PCU_TX_TIMER     0x0002813c 15     0 1 1 2 1
>  mc_mac_pcu_tx_timer_tx_timer                          0       MAC_PCU_TX_TIMER     0x0002813c 14:0   0 1 1 2 1
420,421c456,457
<  mc_tx_fifo_wrap_enable            1   mac_pcu_MAC_PCU_TXBUF_CTRL     0x00028140 16     0 1 1 2 1
<  mc_usable_entries                 511 mac_pcu_MAC_PCU_TXBUF_CTRL     0x00028140 11:0   0 1 1 2 1
---
>  mc_mac_pcu_txbuf_ctrl_tx_fifo_wrap_enable             1       MAC_PCU_TXBUF_CTRL   0x00028140 16     0 1 1 2 1
>  mc_mac_pcu_txbuf_ctrl_usable_entries                  511     MAC_PCU_TXBUF_CTRL   0x00028140 11:0   0 1 1 2 1
423,442c459,478
<  mc_reserved_1                     0   mac_pcu_MAC_PCU_MISC_MODE2     0x00028144 31:28  0 1 1 2 1
<  mc_rcv_timestamp_fix              1   mac_pcu_MAC_PCU_MISC_MODE2     0x00028144 27     0 1 1 2 1
<  mc_beacon_from_to_ds              1   mac_pcu_MAC_PCU_MISC_MODE2     0x00028144 26     0 1 1 2 1
<  mc_pm_field_for_mgmt              0   mac_pcu_MAC_PCU_MISC_MODE2     0x00028144 25     0 1 1 2 1
<  mc_pm_field_for_dat               0   mac_pcu_MAC_PCU_MISC_MODE2     0x00028144 24     0 1 1 2 1
<  mc_ignore_txop_if_zero            0   mac_pcu_MAC_PCU_MISC_MODE2     0x00028144 23     0 1 1 2 1
<  mc_ignore_txop_1st_pkt            1   mac_pcu_MAC_PCU_MISC_MODE2     0x00028144 22     0 1 1 2 1
<  mc_clear_more_frag                0   mac_pcu_MAC_PCU_MISC_MODE2     0x00028144 21     0 1 1 2 1
<  mc_bug_28676                      1   mac_pcu_MAC_PCU_MISC_MODE2     0x00028144 20     0 1 1 2 1
<  mc_dur_account_by_ba              1   mac_pcu_MAC_PCU_MISC_MODE2     0x00028144 19     0 1 1 2 1
<  mc_bc_mc_wapi_mode                0   mac_pcu_MAC_PCU_MISC_MODE2     0x00028144 18     0 1 1 2 1
<  mc_agg_wep                        0   mac_pcu_MAC_PCU_MISC_MODE2     0x00028144 17     0 1 1 2 1
<  mc_enable_load_nav_beacon_duration 0   mac_pcu_MAC_PCU_MISC_MODE2     0x00028144 16     0 1 1 2 1
<  mc_mgmt_qos                       16  mac_pcu_MAC_PCU_MISC_MODE2     0x00028144 15:8   0 1 1 2 1
<  mc_cfp_ignore                     0   mac_pcu_MAC_PCU_MISC_MODE2     0x00028144 7      0 1 1 2 1
<  mc_adhoc_mcast_keyid_enable       1   mac_pcu_MAC_PCU_MISC_MODE2     0x00028144 6      0 1 1 2 1
<  mc_reserved_0                     0   mac_pcu_MAC_PCU_MISC_MODE2     0x00028144 5:3    0 1 1 2 1
<  mc_no_crypto_for_non_data_pkt     0   mac_pcu_MAC_PCU_MISC_MODE2     0x00028144 2      0 1 1 2 1
<  mc_mgmt_crypto_enable             1   mac_pcu_MAC_PCU_MISC_MODE2     0x00028144 1      0 1 1 2 1
<  mc_bug_21532_fix_enable           1   mac_pcu_MAC_PCU_MISC_MODE2     0x00028144 0      0 1 1 2 1
---
>  mc_mac_pcu_misc_mode2_reserved_1                      0       MAC_PCU_MISC_MODE2   0x00028144 31:28  0 1 1 2 1
>  mc_mac_pcu_misc_mode2_rcv_timestamp_fix               1       MAC_PCU_MISC_MODE2   0x00028144 27     0 1 1 2 1
>  mc_mac_pcu_misc_mode2_beacon_from_to_ds               1       MAC_PCU_MISC_MODE2   0x00028144 26     0 1 1 2 1
>  mc_mac_pcu_misc_mode2_pm_field_for_mgmt               0       MAC_PCU_MISC_MODE2   0x00028144 25     0 1 1 2 1
>  mc_mac_pcu_misc_mode2_pm_field_for_dat                0       MAC_PCU_MISC_MODE2   0x00028144 24     0 1 1 2 1
>  mc_mac_pcu_misc_mode2_ignore_txop_if_zero             0       MAC_PCU_MISC_MODE2   0x00028144 23     0 1 1 2 1
>  mc_mac_pcu_misc_mode2_ignore_txop_1st_pkt             1       MAC_PCU_MISC_MODE2   0x00028144 22     0 1 1 2 1
>  mc_mac_pcu_misc_mode2_clear_more_frag                 0       MAC_PCU_MISC_MODE2   0x00028144 21     0 1 1 2 1
>  mc_mac_pcu_misc_mode2_bug_28676                       1       MAC_PCU_MISC_MODE2   0x00028144 20     0 1 1 2 1
>  mc_mac_pcu_misc_mode2_dur_account_by_ba               1       MAC_PCU_MISC_MODE2   0x00028144 19     0 1 1 2 1
>  mc_mac_pcu_misc_mode2_bc_mc_wapi_mode                 0       MAC_PCU_MISC_MODE2   0x00028144 18     0 1 1 2 1
>  mc_mac_pcu_misc_mode2_agg_wep                         0       MAC_PCU_MISC_MODE2   0x00028144 17     0 1 1 2 1
>  mc_mac_pcu_misc_mode2_enable_load_nav_beacon_duration 0       MAC_PCU_MISC_MODE2   0x00028144 16     0 1 1 2 1
>  mc_mac_pcu_misc_mode2_mgmt_qos                        16      MAC_PCU_MISC_MODE2   0x00028144 15:8   0 1 1 2 1
>  mc_mac_pcu_misc_mode2_cfp_ignore                      0       MAC_PCU_MISC_MODE2   0x00028144 7      0 1 1 2 1
>  mc_mac_pcu_misc_mode2_adhoc_mcast_keyid_enable        1       MAC_PCU_MISC_MODE2   0x00028144 6      0 1 1 2 1
>  mc_mac_pcu_misc_mode2_reserved_0                      0       MAC_PCU_MISC_MODE2   0x00028144 5:3    0 1 1 2 1
>  mc_mac_pcu_misc_mode2_no_crypto_for_non_data_pkt      0       MAC_PCU_MISC_MODE2   0x00028144 2      0 1 1 2 1
>  mc_mac_pcu_misc_mode2_mgmt_crypto_enable              1       MAC_PCU_MISC_MODE2   0x00028144 1      0 1 1 2 1
>  mc_mac_pcu_misc_mode2_bug_21532_fix_enable            1       MAC_PCU_MISC_MODE2   0x00028144 0      0 1 1 2 1
444c480
<  mc_mac_pcu_alt_aes_mute_mask_qos  143 mac_pcu_MAC_PCU_ALT_AES_MUTE_MASK 0x00028148 31:16  0 1 1 2 1
---
>  mc_mac_pcu_alt_aes_mute_mask_qos                      143     MAC_PCU_ALT_AES_MUTE_MASK 0x00028148 31:16  0 1 1 2 1
446c482
<  mc_mac_pcu_azimuth_time_stamp_value 0   mac_pcu_MAC_PCU_AZIMUTH_TIME_STAMP 0x0002814c 31:0   0 1 1 2 1
---
>  mc_mac_pcu_azimuth_time_stamp_value                   0       MAC_PCU_AZIMUTH_TIME_STAMP 0x0002814c 31:0   0 1 1 2 1
448,449c484,485
<  mc_usec_frac_denominator          0   mac_pcu_MAC_PCU_MAX_CFP_DUR    0x00028150 7:4    0 1 1 2 1
<  mc_usec_frac_numerator            0   mac_pcu_MAC_PCU_MAX_CFP_DUR    0x00028150 3:0    0 1 1 2 1
---
>  mc_mac_pcu_max_cfp_dur_usec_frac_denominator          0       MAC_PCU_MAX_CFP_DUR  0x00028150 7:4    0 1 1 2 1
>  mc_mac_pcu_max_cfp_dur_usec_frac_numerator            0       MAC_PCU_MAX_CFP_DUR  0x00028150 3:0    0 1 1 2 1
451c487
<  mc_mac_pcu_hcf_timeout_value      0   mac_pcu_MAC_PCU_HCF_TIMEOUT    0x00028154 15:0   0 1 1 2 1
---
>  mc_mac_pcu_hcf_timeout_value                          0       MAC_PCU_HCF_TIMEOUT  0x00028154 15:0   0 1 1 2 1
453c489
<  mc_wl_weight_contd                0   mac_pcu_MAC_PCU_BLUETOOTH_WEIGHTS2 0x00028158 31:16  0 1 1 2 1
---
>  mc_mac_pcu_bluetooth_weights2_wl_weight_contd         0       MAC_PCU_BLUETOOTH_WEIGHTS2 0x00028158 31:16  0 1 1 2 1
455c491
<  mc_mac_pcu_bluetooth_tsf_bt_active_value 0   mac_pcu_MAC_PCU_BLUETOOTH_TSF_BT_ACTIVE 0x0002815c 31:0   0 0 1 2 1
---
>  mc_mac_pcu_bluetooth_tsf_bt_active_value              0       MAC_PCU_BLUETOOTH_TSF_BT_ACTIVE 0x0002815c 31:0   0 0 1 2 1
457c493
<  mc_mac_pcu_bluetooth_tsf_bt_priority_value 0   mac_pcu_MAC_PCU_BLUETOOTH_TSF_BT_PRIORITY 0x00028160 31:0   0 0 1 2 1
---
>  mc_mac_pcu_bluetooth_tsf_bt_priority_value            0       MAC_PCU_BLUETOOTH_TSF_BT_PRIORITY 0x00028160 31:0   0 0 1 2 1
459,469c495,505
<  mc_bt_priority_extend_thres       0   mac_pcu_MAC_PCU_BLUETOOTH_MODE3 0x00028164 31:28  0 1 1 2 1
<  mc_bt_tx_on_en                    1   mac_pcu_MAC_PCU_BLUETOOTH_MODE3 0x00028164 27     0 1 1 2 1
<  mc_slot_slop                      1   mac_pcu_MAC_PCU_BLUETOOTH_MODE3 0x00028164 26:25  0 1 1 2 1
<  mc_dynamic_toggle_wla_en          0   mac_pcu_MAC_PCU_BLUETOOTH_MODE3 0x00028164 24     0 1 1 2 1
<  mc_dynamic_pri_en                 0   mac_pcu_MAC_PCU_BLUETOOTH_MODE3 0x00028164 23     0 1 1 2 1
<  mc_rfgain_lock_src                0   mac_pcu_MAC_PCU_BLUETOOTH_MODE3 0x00028164 22     0 1 1 2 1
<  mc_wl_priority_offset_en          0   mac_pcu_MAC_PCU_BLUETOOTH_MODE3 0x00028164 21     0 1 1 2 1
<  mc_shared_rx                      0   mac_pcu_MAC_PCU_BLUETOOTH_MODE3 0x00028164 20     0 1 1 2 1
<  mc_allow_concurrent_access        0   mac_pcu_MAC_PCU_BLUETOOTH_MODE3 0x00028164 19:16  0 1 1 2 1
<  mc_wl_qc_time                     0   mac_pcu_MAC_PCU_BLUETOOTH_MODE3 0x00028164 15:8   0 1 1 2 1
<  mc_wl_active_time                 0   mac_pcu_MAC_PCU_BLUETOOTH_MODE3 0x00028164 7:0    0 1 1 2 1
---
>  mc_mac_pcu_bluetooth_mode3_bt_priority_extend_thres   0       MAC_PCU_BLUETOOTH_MODE3 0x00028164 31:28  0 1 1 2 1
>  mc_mac_pcu_bluetooth_mode3_bt_tx_on_en                1       MAC_PCU_BLUETOOTH_MODE3 0x00028164 27     0 1 1 2 1
>  mc_mac_pcu_bluetooth_mode3_slot_slop                  1       MAC_PCU_BLUETOOTH_MODE3 0x00028164 26:25  0 1 1 2 1
>  mc_mac_pcu_bluetooth_mode3_dynamic_toggle_wla_en      0       MAC_PCU_BLUETOOTH_MODE3 0x00028164 24     0 1 1 2 1
>  mc_mac_pcu_bluetooth_mode3_dynamic_pri_en             0       MAC_PCU_BLUETOOTH_MODE3 0x00028164 23     0 1 1 2 1
>  mc_mac_pcu_bluetooth_mode3_rfgain_lock_src            0       MAC_PCU_BLUETOOTH_MODE3 0x00028164 22     0 1 1 2 1
>  mc_mac_pcu_bluetooth_mode3_wl_priority_offset_en      0       MAC_PCU_BLUETOOTH_MODE3 0x00028164 21     0 1 1 2 1
>  mc_mac_pcu_bluetooth_mode3_shared_rx                  0       MAC_PCU_BLUETOOTH_MODE3 0x00028164 20     0 1 1 2 1
>  mc_mac_pcu_bluetooth_mode3_allow_concurrent_access    0       MAC_PCU_BLUETOOTH_MODE3 0x00028164 19:16  0 1 1 2 1
>  mc_mac_pcu_bluetooth_mode3_wl_qc_time                 0       MAC_PCU_BLUETOOTH_MODE3 0x00028164 15:8   0 1 1 2 1
>  mc_mac_pcu_bluetooth_mode3_wl_active_time             0       MAC_PCU_BLUETOOTH_MODE3 0x00028164 7:0    0 1 1 2 1
471,472c507,508
<  mc_bt_priority_extend             0   mac_pcu_MAC_PCU_BLUETOOTH_MODE4 0x00028168 31:16  0 1 1 2 1
<  mc_bt_active_extend               0   mac_pcu_MAC_PCU_BLUETOOTH_MODE4 0x00028168 15:0   0 1 1 2 1
---
>  mc_mac_pcu_bluetooth_mode4_bt_priority_extend         0       MAC_PCU_BLUETOOTH_MODE4 0x00028168 31:16  0 1 1 2 1
>  mc_mac_pcu_bluetooth_mode4_bt_active_extend           0       MAC_PCU_BLUETOOTH_MODE4 0x00028168 15:0   0 1 1 2 1
474c510
<  mc_mac_pcu_bt_bt_weight           0   mac_pcu_MAC_PCU_BT_BT          0x00028200 31:0   0 1 1 2 1
---
>  mc_mac_pcu_bt_bt_weight                               0       MAC_PCU_BT_BT        0x00028200 31:0   0 1 1 2 1
476,479c512,515
<  mc_rxlp_weight                    0   mac_pcu_MAC_PCU_BT_BT_ASYNC    0x00028300 15:12  0 1 1 2 1
<  mc_rxhp_weight                    0   mac_pcu_MAC_PCU_BT_BT_ASYNC    0x00028300 11:8   0 1 1 2 1
<  mc_txlp_weight                    0   mac_pcu_MAC_PCU_BT_BT_ASYNC    0x00028300 7:4    0 1 1 2 1
<  mc_txhp_weight                    0   mac_pcu_MAC_PCU_BT_BT_ASYNC    0x00028300 3:0    0 1 1 2 1
---
>  mc_mac_pcu_bt_bt_async_rxlp_weight                    0       MAC_PCU_BT_BT_ASYNC  0x00028300 15:12  0 1 1 2 1
>  mc_mac_pcu_bt_bt_async_rxhp_weight                    0       MAC_PCU_BT_BT_ASYNC  0x00028300 11:8   0 1 1 2 1
>  mc_mac_pcu_bt_bt_async_txlp_weight                    0       MAC_PCU_BT_BT_ASYNC  0x00028300 7:4    0 1 1 2 1
>  mc_mac_pcu_bt_bt_async_txhp_weight                    0       MAC_PCU_BT_BT_ASYNC  0x00028300 3:0    0 1 1 2 1
481c517
<  mc_mac_pcu_bt_wl_1_weight         0   mac_pcu_MAC_PCU_BT_WL_1        0x00028304 31:0   0 1 1 2 1
---
>  mc_mac_pcu_bt_wl_1_weight                             0       MAC_PCU_BT_WL_1      0x00028304 31:0   0 1 1 2 1
483c519
<  mc_mac_pcu_bt_wl_2_weight         0   mac_pcu_MAC_PCU_BT_WL_2        0x00028308 31:0   0 1 1 2 1
---
>  mc_mac_pcu_bt_wl_2_weight                             0       MAC_PCU_BT_WL_2      0x00028308 31:0   0 1 1 2 1
485c521
<  mc_mac_pcu_bt_wl_3_weight         0   mac_pcu_MAC_PCU_BT_WL_3        0x0002830c 31:0   0 1 1 2 1
---
>  mc_mac_pcu_bt_wl_3_weight                             0       MAC_PCU_BT_WL_3      0x0002830c 31:0   0 1 1 2 1
487c523
<  mc_mac_pcu_bt_wl_4_weight         0   mac_pcu_MAC_PCU_BT_WL_4        0x00028310 31:0   0 1 1 2 1
---
>  mc_mac_pcu_bt_wl_4_weight                             0       MAC_PCU_BT_WL_4      0x00028310 31:0   0 1 1 2 1
489,490c525,526
<  mc_wt_idx                         0   mac_pcu_MAC_PCU_COEX_EPTA      0x00028314 12:6   0 1 1 2 1
<  mc_linkid                         0   mac_pcu_MAC_PCU_COEX_EPTA      0x00028314 5:0    0 1 1 2 1
---
>  mc_mac_pcu_coex_epta_wt_idx                           0       MAC_PCU_COEX_EPTA    0x00028314 12:6   0 1 1 2 1
>  mc_mac_pcu_coex_epta_linkid                           0       MAC_PCU_COEX_EPTA    0x00028314 5:0    0 1 1 2 1
492,495c528,531
<  mc_maxgain4                       255 mac_pcu_MAC_PCU_COEX_LNAMAXGAIN1 0x00028318 31:24  0 1 1 2 1
<  mc_maxgain3                       255 mac_pcu_MAC_PCU_COEX_LNAMAXGAIN1 0x00028318 23:16  0 1 1 2 1
<  mc_maxgain2                       255 mac_pcu_MAC_PCU_COEX_LNAMAXGAIN1 0x00028318 15:8   0 1 1 2 1
<  mc_maxgain1                       255 mac_pcu_MAC_PCU_COEX_LNAMAXGAIN1 0x00028318 7:0    0 1 1 2 1
---
>  mc_mac_pcu_coex_lnamaxgain1_maxgain4                  255     MAC_PCU_COEX_LNAMAXGAIN1 0x00028318 31:24  0 1 1 2 1
>  mc_mac_pcu_coex_lnamaxgain1_maxgain3                  255     MAC_PCU_COEX_LNAMAXGAIN1 0x00028318 23:16  0 1 1 2 1
>  mc_mac_pcu_coex_lnamaxgain1_maxgain2                  255     MAC_PCU_COEX_LNAMAXGAIN1 0x00028318 15:8   0 1 1 2 1
>  mc_mac_pcu_coex_lnamaxgain1_maxgain1                  255     MAC_PCU_COEX_LNAMAXGAIN1 0x00028318 7:0    0 1 1 2 1
497,500c533,536
<  mc_mac_pcu_coex_lnamaxgain2_maxgain4 255 mac_pcu_MAC_PCU_COEX_LNAMAXGAIN2 0x0002831c 31:24  0 1 1 2 1
<  mc_mac_pcu_coex_lnamaxgain2_maxgain3 255 mac_pcu_MAC_PCU_COEX_LNAMAXGAIN2 0x0002831c 23:16  0 1 1 2 1
<  mc_mac_pcu_coex_lnamaxgain2_maxgain2 255 mac_pcu_MAC_PCU_COEX_LNAMAXGAIN2 0x0002831c 15:8   0 1 1 2 1
<  mc_mac_pcu_coex_lnamaxgain2_maxgain1 255 mac_pcu_MAC_PCU_COEX_LNAMAXGAIN2 0x0002831c 7:0    0 1 1 2 1
---
>  mc_mac_pcu_coex_lnamaxgain2_maxgain4                  255     MAC_PCU_COEX_LNAMAXGAIN2 0x0002831c 31:24  0 1 1 2 1
>  mc_mac_pcu_coex_lnamaxgain2_maxgain3                  255     MAC_PCU_COEX_LNAMAXGAIN2 0x0002831c 23:16  0 1 1 2 1
>  mc_mac_pcu_coex_lnamaxgain2_maxgain2                  255     MAC_PCU_COEX_LNAMAXGAIN2 0x0002831c 15:8   0 1 1 2 1
>  mc_mac_pcu_coex_lnamaxgain2_maxgain1                  255     MAC_PCU_COEX_LNAMAXGAIN2 0x0002831c 7:0    0 1 1 2 1
502,505c538,541
<  mc_mac_pcu_coex_lnamaxgain3_maxgain4 255 mac_pcu_MAC_PCU_COEX_LNAMAXGAIN3 0x00028320 31:24  0 1 1 2 1
<  mc_mac_pcu_coex_lnamaxgain3_maxgain3 255 mac_pcu_MAC_PCU_COEX_LNAMAXGAIN3 0x00028320 23:16  0 1 1 2 1
<  mc_mac_pcu_coex_lnamaxgain3_maxgain2 255 mac_pcu_MAC_PCU_COEX_LNAMAXGAIN3 0x00028320 15:8   0 1 1 2 1
<  mc_mac_pcu_coex_lnamaxgain3_maxgain1 255 mac_pcu_MAC_PCU_COEX_LNAMAXGAIN3 0x00028320 7:0    0 1 1 2 1
---
>  mc_mac_pcu_coex_lnamaxgain3_maxgain4                  255     MAC_PCU_COEX_LNAMAXGAIN3 0x00028320 31:24  0 1 1 2 1
>  mc_mac_pcu_coex_lnamaxgain3_maxgain3                  255     MAC_PCU_COEX_LNAMAXGAIN3 0x00028320 23:16  0 1 1 2 1
>  mc_mac_pcu_coex_lnamaxgain3_maxgain2                  255     MAC_PCU_COEX_LNAMAXGAIN3 0x00028320 15:8   0 1 1 2 1
>  mc_mac_pcu_coex_lnamaxgain3_maxgain1                  255     MAC_PCU_COEX_LNAMAXGAIN3 0x00028320 7:0    0 1 1 2 1
507,510c543,546
<  mc_mac_pcu_coex_lnamaxgain4_maxgain4 255 mac_pcu_MAC_PCU_COEX_LNAMAXGAIN4 0x00028324 31:24  0 1 1 2 1
<  mc_mac_pcu_coex_lnamaxgain4_maxgain3 255 mac_pcu_MAC_PCU_COEX_LNAMAXGAIN4 0x00028324 23:16  0 1 1 2 1
<  mc_mac_pcu_coex_lnamaxgain4_maxgain2 255 mac_pcu_MAC_PCU_COEX_LNAMAXGAIN4 0x00028324 15:8   0 1 1 2 1
<  mc_mac_pcu_coex_lnamaxgain4_maxgain1 255 mac_pcu_MAC_PCU_COEX_LNAMAXGAIN4 0x00028324 7:0    0 1 1 2 1
---
>  mc_mac_pcu_coex_lnamaxgain4_maxgain4                  255     MAC_PCU_COEX_LNAMAXGAIN4 0x00028324 31:24  0 1 1 2 1
>  mc_mac_pcu_coex_lnamaxgain4_maxgain3                  255     MAC_PCU_COEX_LNAMAXGAIN4 0x00028324 23:16  0 1 1 2 1
>  mc_mac_pcu_coex_lnamaxgain4_maxgain2                  255     MAC_PCU_COEX_LNAMAXGAIN4 0x00028324 15:8   0 1 1 2 1
>  mc_mac_pcu_coex_lnamaxgain4_maxgain1                  255     MAC_PCU_COEX_LNAMAXGAIN4 0x00028324 7:0    0 1 1 2 1
512c548
<  mc_mac_pcu_basic_rate_set0_value  836565851 mac_pcu_MAC_PCU_BASIC_RATE_SET0 0x00028328 29:0   0 1 1 2 1
---
>  mc_mac_pcu_basic_rate_set0_value                      836565851 MAC_PCU_BASIC_RATE_SET0 0x00028328 29:0   0 1 1 2 1
514c550
<  mc_mac_pcu_basic_rate_set1_value  312814972 mac_pcu_MAC_PCU_BASIC_RATE_SET1 0x0002832c 29:0   0 1 1 2 1
---
>  mc_mac_pcu_basic_rate_set1_value                      312814972 MAC_PCU_BASIC_RATE_SET1 0x0002832c 29:0   0 1 1 2 1
516c552
<  mc_mac_pcu_basic_rate_set2_value  346400041 mac_pcu_MAC_PCU_BASIC_RATE_SET2 0x00028330 29:0   0 1 1 2 1
---
>  mc_mac_pcu_basic_rate_set2_value                      346400041 MAC_PCU_BASIC_RATE_SET2 0x00028330 29:0   0 1 1 2 1
518c554
<  mc_mac_pcu_basic_rate_set3_value  9741609 mac_pcu_MAC_PCU_BASIC_RATE_SET3 0x00028334 24:0   0 1 1 2 1
---
>  mc_mac_pcu_basic_rate_set3_value                      9741609 MAC_PCU_BASIC_RATE_SET3 0x00028334 24:0   0 1 1 2 1
520,523c556,559
<  mc_duration_h                     0   mac_pcu_MAC_PCU_RX_INT_STATUS0 0x00028338 31:24  0 0 1 2 1
<  mc_duration_l                     0   mac_pcu_MAC_PCU_RX_INT_STATUS0 0x00028338 23:16  0 0 1 2 1
<  mc_frame_control_h                0   mac_pcu_MAC_PCU_RX_INT_STATUS0 0x00028338 15:8   0 0 1 2 1
<  mc_frame_control_l                0   mac_pcu_MAC_PCU_RX_INT_STATUS0 0x00028338 7:0    0 0 1 2 1
---
>  mc_mac_pcu_rx_int_status0_duration_h                  0       MAC_PCU_RX_INT_STATUS0 0x00028338 31:24  0 0 1 2 1
>  mc_mac_pcu_rx_int_status0_duration_l                  0       MAC_PCU_RX_INT_STATUS0 0x00028338 23:16  0 0 1 2 1
>  mc_mac_pcu_rx_int_status0_frame_control_h             0       MAC_PCU_RX_INT_STATUS0 0x00028338 15:8   0 0 1 2 1
>  mc_mac_pcu_rx_int_status0_frame_control_l             0       MAC_PCU_RX_INT_STATUS0 0x00028338 7:0    0 0 1 2 1
525c561
<  mc_mac_pcu_rx_int_status1_value   0   mac_pcu_MAC_PCU_RX_INT_STATUS1 0x0002833c 17:0   0 0 1 2 1
---
>  mc_mac_pcu_rx_int_status1_value                       0       MAC_PCU_RX_INT_STATUS1 0x0002833c 17:0   0 0 1 2 1
527c563
<  mc_mac_pcu_rx_int_status2_value   0   mac_pcu_MAC_PCU_RX_INT_STATUS2 0x00028340 26:0   0 0 1 2 1
---
>  mc_mac_pcu_rx_int_status2_value                       0       MAC_PCU_RX_INT_STATUS2 0x00028340 26:0   0 0 1 2 1
529c565
<  mc_mac_pcu_rx_int_status3_value   0   mac_pcu_MAC_PCU_RX_INT_STATUS3 0x00028344 23:0   0 0 1 2 1
---
>  mc_mac_pcu_rx_int_status3_value                       0       MAC_PCU_RX_INT_STATUS3 0x00028344 23:0   0 0 1 2 1
531,534c567,570
<  mc_mcs3                           29  mac_pcu_HT_HALF_GI_RATE1       0x00028348 31:24  0 1 1 2 1
<  mc_mcs2                           22  mac_pcu_HT_HALF_GI_RATE1       0x00028348 23:16  0 1 1 2 1
<  mc_mcs1                           14  mac_pcu_HT_HALF_GI_RATE1       0x00028348 15:8   0 1 1 2 1
<  mc_mcs0                           7   mac_pcu_HT_HALF_GI_RATE1       0x00028348 7:0    0 1 1 2 1
---
>  mc_ht_half_gi_rate1_mcs3                              29      HT_HALF_GI_RATE1     0x00028348 31:24  0 1 1 2 1
>  mc_ht_half_gi_rate1_mcs2                              22      HT_HALF_GI_RATE1     0x00028348 23:16  0 1 1 2 1
>  mc_ht_half_gi_rate1_mcs1                              14      HT_HALF_GI_RATE1     0x00028348 15:8   0 1 1 2 1
>  mc_ht_half_gi_rate1_mcs0                              7       HT_HALF_GI_RATE1     0x00028348 7:0    0 1 1 2 1
536,539c572,575
<  mc_mcs7                           72  mac_pcu_HT_HALF_GI_RATE2       0x0002834c 31:24  0 1 1 2 1
<  mc_mcs6                           65  mac_pcu_HT_HALF_GI_RATE2       0x0002834c 23:16  0 1 1 2 1
<  mc_mcs5                           58  mac_pcu_HT_HALF_GI_RATE2       0x0002834c 15:8   0 1 1 2 1
<  mc_mcs4                           43  mac_pcu_HT_HALF_GI_RATE2       0x0002834c 7:0    0 1 1 2 1
---
>  mc_ht_half_gi_rate2_mcs7                              72      HT_HALF_GI_RATE2     0x0002834c 31:24  0 1 1 2 1
>  mc_ht_half_gi_rate2_mcs6                              65      HT_HALF_GI_RATE2     0x0002834c 23:16  0 1 1 2 1
>  mc_ht_half_gi_rate2_mcs5                              58      HT_HALF_GI_RATE2     0x0002834c 15:8   0 1 1 2 1
>  mc_ht_half_gi_rate2_mcs4                              43      HT_HALF_GI_RATE2     0x0002834c 7:0    0 1 1 2 1
541,544c577,580
<  mc_ht_full_gi_rate1_mcs3          26  mac_pcu_HT_FULL_GI_RATE1       0x00028350 31:24  0 1 1 2 1
<  mc_ht_full_gi_rate1_mcs2          20  mac_pcu_HT_FULL_GI_RATE1       0x00028350 23:16  0 1 1 2 1
<  mc_ht_full_gi_rate1_mcs1          13  mac_pcu_HT_FULL_GI_RATE1       0x00028350 15:8   0 1 1 2 1
<  mc_ht_full_gi_rate1_mcs0          7   mac_pcu_HT_FULL_GI_RATE1       0x00028350 7:0    0 1 1 2 1
---
>  mc_ht_full_gi_rate1_mcs3                              26      HT_FULL_GI_RATE1     0x00028350 31:24  0 1 1 2 1
>  mc_ht_full_gi_rate1_mcs2                              20      HT_FULL_GI_RATE1     0x00028350 23:16  0 1 1 2 1
>  mc_ht_full_gi_rate1_mcs1                              13      HT_FULL_GI_RATE1     0x00028350 15:8   0 1 1 2 1
>  mc_ht_full_gi_rate1_mcs0                              7       HT_FULL_GI_RATE1     0x00028350 7:0    0 1 1 2 1
546,549c582,585
<  mc_ht_full_gi_rate2_mcs7          65  mac_pcu_HT_FULL_GI_RATE2       0x00028354 31:24  0 1 1 2 1
<  mc_ht_full_gi_rate2_mcs6          59  mac_pcu_HT_FULL_GI_RATE2       0x00028354 23:16  0 1 1 2 1
<  mc_ht_full_gi_rate2_mcs5          52  mac_pcu_HT_FULL_GI_RATE2       0x00028354 15:8   0 1 1 2 1
<  mc_ht_full_gi_rate2_mcs4          39  mac_pcu_HT_FULL_GI_RATE2       0x00028354 7:0    0 1 1 2 1
---
>  mc_ht_full_gi_rate2_mcs7                              65      HT_FULL_GI_RATE2     0x00028354 31:24  0 1 1 2 1
>  mc_ht_full_gi_rate2_mcs6                              59      HT_FULL_GI_RATE2     0x00028354 23:16  0 1 1 2 1
>  mc_ht_full_gi_rate2_mcs5                              52      HT_FULL_GI_RATE2     0x00028354 15:8   0 1 1 2 1
>  mc_ht_full_gi_rate2_mcs4                              39      HT_FULL_GI_RATE2     0x00028354 7:0    0 1 1 2 1
551,555c587,591
<  mc_rate12                         54  mac_pcu_LEGACY_RATE1           0x00028358 29:24  0 1 1 2 1
<  mc_rate11                         6   mac_pcu_LEGACY_RATE1           0x00028358 23:18  0 1 1 2 1
<  mc_rate10                         12  mac_pcu_LEGACY_RATE1           0x00028358 17:12  0 1 1 2 1
<  mc_rate9                          24  mac_pcu_LEGACY_RATE1           0x00028358 11:6   0 1 1 2 1
<  mc_rate8                          48  mac_pcu_LEGACY_RATE1           0x00028358 5:0    0 1 1 2 1
---
>  mc_legacy_rate1_rate12                                54      LEGACY_RATE1         0x00028358 29:24  0 1 1 2 1
>  mc_legacy_rate1_rate11                                6       LEGACY_RATE1         0x00028358 23:18  0 1 1 2 1
>  mc_legacy_rate1_rate10                                12      LEGACY_RATE1         0x00028358 17:12  0 1 1 2 1
>  mc_legacy_rate1_rate9                                 24      LEGACY_RATE1         0x00028358 11:6   0 1 1 2 1
>  mc_legacy_rate1_rate8                                 48      LEGACY_RATE1         0x00028358 5:0    0 1 1 2 1
557,561c593,597
<  mc_rate25                         6   mac_pcu_LEGACY_RATE2           0x0002835c 29:24  0 1 1 2 1
<  mc_rate24                         11  mac_pcu_LEGACY_RATE2           0x0002835c 23:18  0 1 1 2 1
<  mc_rate15                         9   mac_pcu_LEGACY_RATE2           0x0002835c 17:12  0 1 1 2 1
<  mc_rate14                         22  mac_pcu_LEGACY_RATE2           0x0002835c 11:6   0 1 1 2 1
<  mc_rate13                         36  mac_pcu_LEGACY_RATE2           0x0002835c 5:0    0 1 1 2 1
---
>  mc_legacy_rate2_rate25                                6       LEGACY_RATE2         0x0002835c 29:24  0 1 1 2 1
>  mc_legacy_rate2_rate24                                11      LEGACY_RATE2         0x0002835c 23:18  0 1 1 2 1
>  mc_legacy_rate2_rate15                                9       LEGACY_RATE2         0x0002835c 17:12  0 1 1 2 1
>  mc_legacy_rate2_rate14                                22      LEGACY_RATE2         0x0002835c 11:6   0 1 1 2 1
>  mc_legacy_rate2_rate13                                36      LEGACY_RATE2         0x0002835c 5:0    0 1 1 2 1
563,567c599,603
<  mc_rate30                         2   mac_pcu_LEGACY_RATE3           0x00028360 29:24  0 1 1 2 1
<  mc_rate29                         6   mac_pcu_LEGACY_RATE3           0x00028360 23:18  0 1 1 2 1
<  mc_rate28                         11  mac_pcu_LEGACY_RATE3           0x00028360 17:12  0 1 1 2 1
<  mc_rate27                         1   mac_pcu_LEGACY_RATE3           0x00028360 11:6   0 1 1 2 1
<  mc_rate26                         2   mac_pcu_LEGACY_RATE3           0x00028360 5:0    0 1 1 2 1
---
>  mc_legacy_rate3_rate30                                2       LEGACY_RATE3         0x00028360 29:24  0 1 1 2 1
>  mc_legacy_rate3_rate29                                6       LEGACY_RATE3         0x00028360 23:18  0 1 1 2 1
>  mc_legacy_rate3_rate28                                11      LEGACY_RATE3         0x00028360 17:12  0 1 1 2 1
>  mc_legacy_rate3_rate27                                1       LEGACY_RATE3         0x00028360 11:6   0 1 1 2 1
>  mc_legacy_rate3_rate26                                2       LEGACY_RATE3         0x00028360 5:0    0 1 1 2 1
569,585c605,621
<  mc_ampdu                          1   mac_pcu_RX_INT_FILTER          0x00028364 16     0 1 1 2 1
<  mc_eosp                           1   mac_pcu_RX_INT_FILTER          0x00028364 15     0 1 1 2 1
<  mc_length_low                     1   mac_pcu_RX_INT_FILTER          0x00028364 14     0 1 1 2 1
<  mc_length_high                    1   mac_pcu_RX_INT_FILTER          0x00028364 13     0 1 1 2 1
<  mc_rssi                           1   mac_pcu_RX_INT_FILTER          0x00028364 12     0 1 1 2 1
<  mc_rate_low                       1   mac_pcu_RX_INT_FILTER          0x00028364 11     0 1 1 2 1
<  mc_rate_high                      1   mac_pcu_RX_INT_FILTER          0x00028364 10     0 1 1 2 1
<  mc_more_frag                      1   mac_pcu_RX_INT_FILTER          0x00028364 9      0 1 1 2 1
<  mc_more_data                      1   mac_pcu_RX_INT_FILTER          0x00028364 8      0 1 1 2 1
<  mc_retry                          1   mac_pcu_RX_INT_FILTER          0x00028364 7      0 1 1 2 1
<  mc_cts                            1   mac_pcu_RX_INT_FILTER          0x00028364 6      0 1 1 2 1
<  mc_ack                            1   mac_pcu_RX_INT_FILTER          0x00028364 5      0 1 1 2 1
<  mc_rts                            1   mac_pcu_RX_INT_FILTER          0x00028364 4      0 1 1 2 1
<  mc_mcast                          1   mac_pcu_RX_INT_FILTER          0x00028364 3      0 1 1 2 1
<  mc_bcast                          1   mac_pcu_RX_INT_FILTER          0x00028364 2      0 1 1 2 1
<  mc_directed                       1   mac_pcu_RX_INT_FILTER          0x00028364 1      0 1 1 2 1
<  mc_rx_int_filter_enable           1   mac_pcu_RX_INT_FILTER          0x00028364 0      0 1 1 2 1
---
>  mc_rx_int_filter_ampdu                                1       RX_INT_FILTER        0x00028364 16     0 1 1 2 1
>  mc_rx_int_filter_eosp                                 1       RX_INT_FILTER        0x00028364 15     0 1 1 2 1
>  mc_rx_int_filter_length_low                           1       RX_INT_FILTER        0x00028364 14     0 1 1 2 1
>  mc_rx_int_filter_length_high                          1       RX_INT_FILTER        0x00028364 13     0 1 1 2 1
>  mc_rx_int_filter_rssi                                 1       RX_INT_FILTER        0x00028364 12     0 1 1 2 1
>  mc_rx_int_filter_rate_low                             1       RX_INT_FILTER        0x00028364 11     0 1 1 2 1
>  mc_rx_int_filter_rate_high                            1       RX_INT_FILTER        0x00028364 10     0 1 1 2 1
>  mc_rx_int_filter_more_frag                            1       RX_INT_FILTER        0x00028364 9      0 1 1 2 1
>  mc_rx_int_filter_more_data                            1       RX_INT_FILTER        0x00028364 8      0 1 1 2 1
>  mc_rx_int_filter_retry                                1       RX_INT_FILTER        0x00028364 7      0 1 1 2 1
>  mc_rx_int_filter_cts                                  1       RX_INT_FILTER        0x00028364 6      0 1 1 2 1
>  mc_rx_int_filter_ack                                  1       RX_INT_FILTER        0x00028364 5      0 1 1 2 1
>  mc_rx_int_filter_rts                                  1       RX_INT_FILTER        0x00028364 4      0 1 1 2 1
>  mc_rx_int_filter_mcast                                1       RX_INT_FILTER        0x00028364 3      0 1 1 2 1
>  mc_rx_int_filter_bcast                                1       RX_INT_FILTER        0x00028364 2      0 1 1 2 1
>  mc_rx_int_filter_directed                             1       RX_INT_FILTER        0x00028364 1      0 1 1 2 1
>  mc_rx_int_filter_enable                               1       RX_INT_FILTER        0x00028364 0      0 1 1 2 1
587c623
<  mc_status                         1   mac_pcu_RX_INT_OVERFLOW        0x00028368 0      0 0 1 2 1
---
>  mc_rx_int_overflow_status                             1       RX_INT_OVERFLOW      0x00028368 0      0 0 1 2 1
589,591c625,627
<  mc_rssi_low                       1   mac_pcu_RX_FILTER_THRESH       0x0002836c 23:16  0 1 1 2 1
<  mc_rx_filter_thresh_rate_low      0   mac_pcu_RX_FILTER_THRESH       0x0002836c 15:8   0 1 1 2 1
<  mc_rx_filter_thresh_rate_high     0   mac_pcu_RX_FILTER_THRESH       0x0002836c 7:0    0 1 1 2 1
---
>  mc_rx_filter_thresh_rssi_low                          1       RX_FILTER_THRESH     0x0002836c 23:16  0 1 1 2 1
>  mc_rx_filter_thresh_rate_low                          0       RX_FILTER_THRESH     0x0002836c 15:8   0 1 1 2 1
>  mc_rx_filter_thresh_rate_high                         0       RX_FILTER_THRESH     0x0002836c 7:0    0 1 1 2 1
593,594c629,630
<  mc_rx_filter_thresh1_length_low   0   mac_pcu_RX_FILTER_THRESH1      0x00028370 23:12  0 1 1 2 1
<  mc_rx_filter_thresh1_length_high  4095 mac_pcu_RX_FILTER_THRESH1      0x00028370 11:0   0 1 1 2 1
---
>  mc_rx_filter_thresh1_length_low                       0       RX_FILTER_THRESH1    0x00028370 23:12  0 1 1 2 1
>  mc_rx_filter_thresh1_length_high                      4095    RX_FILTER_THRESH1    0x00028370 11:0   0 1 1 2 1
596,599c632,635
<  mc_rx_priority_thresh0_rssi_low   1   mac_pcu_RX_PRIORITY_THRESH0    0x00028374 31:24  0 1 1 2 1
<  mc_rssi_high                      1   mac_pcu_RX_PRIORITY_THRESH0    0x00028374 23:16  0 1 1 2 1
<  mc_rx_priority_thresh0_rate_low   0   mac_pcu_RX_PRIORITY_THRESH0    0x00028374 15:8   0 1 1 2 1
<  mc_rx_priority_thresh0_rate_high  0   mac_pcu_RX_PRIORITY_THRESH0    0x00028374 7:0    0 1 1 2 1
---
>  mc_rx_priority_thresh0_rssi_low                       1       RX_PRIORITY_THRESH0  0x00028374 31:24  0 1 1 2 1
>  mc_rx_priority_thresh0_rssi_high                      1       RX_PRIORITY_THRESH0  0x00028374 23:16  0 1 1 2 1
>  mc_rx_priority_thresh0_rate_low                       0       RX_PRIORITY_THRESH0  0x00028374 15:8   0 1 1 2 1
>  mc_rx_priority_thresh0_rate_high                      0       RX_PRIORITY_THRESH0  0x00028374 7:0    0 1 1 2 1
601,603c637,639
<  mc_xcast_rssi_high                1   mac_pcu_RX_PRIORITY_THRESH1    0x00028378 31:24  0 1 1 2 1
<  mc_rx_priority_thresh1_length_low 0   mac_pcu_RX_PRIORITY_THRESH1    0x00028378 23:12  0 1 1 2 1
<  mc_rx_priority_thresh1_length_high 4095 mac_pcu_RX_PRIORITY_THRESH1    0x00028378 11:0   0 1 1 2 1
---
>  mc_rx_priority_thresh1_xcast_rssi_high                1       RX_PRIORITY_THRESH1  0x00028378 31:24  0 1 1 2 1
>  mc_rx_priority_thresh1_length_low                     0       RX_PRIORITY_THRESH1  0x00028378 23:12  0 1 1 2 1
>  mc_rx_priority_thresh1_length_high                    4095    RX_PRIORITY_THRESH1  0x00028378 11:0   0 1 1 2 1
605,608c641,644
<  mc_null_rssi_high                 1   mac_pcu_RX_PRIORITY_THRESH2    0x0002837c 31:24  0 1 1 2 1
<  mc_beacon_rssi_high               1   mac_pcu_RX_PRIORITY_THRESH2    0x0002837c 23:16  0 1 1 2 1
<  mc_mgmt_rssi_high                 1   mac_pcu_RX_PRIORITY_THRESH2    0x0002837c 15:8   0 1 1 2 1
<  mc_presp_rssi_high                1   mac_pcu_RX_PRIORITY_THRESH2    0x0002837c 7:0    0 1 1 2 1
---
>  mc_rx_priority_thresh2_null_rssi_high                 1       RX_PRIORITY_THRESH2  0x0002837c 31:24  0 1 1 2 1
>  mc_rx_priority_thresh2_beacon_rssi_high               1       RX_PRIORITY_THRESH2  0x0002837c 23:16  0 1 1 2 1
>  mc_rx_priority_thresh2_mgmt_rssi_high                 1       RX_PRIORITY_THRESH2  0x0002837c 15:8   0 1 1 2 1
>  mc_rx_priority_thresh2_presp_rssi_high                1       RX_PRIORITY_THRESH2  0x0002837c 7:0    0 1 1 2 1
610,611c646,647
<  mc_ps_poll_rssi_high              1   mac_pcu_RX_PRIORITY_THRESH3    0x00028380 15:8   0 1 1 2 1
<  mc_preq_rssi_high                 1   mac_pcu_RX_PRIORITY_THRESH3    0x00028380 7:0    0 1 1 2 1
---
>  mc_rx_priority_thresh3_ps_poll_rssi_high              1       RX_PRIORITY_THRESH3  0x00028380 15:8   0 1 1 2 1
>  mc_rx_priority_thresh3_preq_rssi_high                 1       RX_PRIORITY_THRESH3  0x00028380 7:0    0 1 1 2 1
613,617c649,653
<  mc_rx_priority_offset0_xcast_rssi_high 0   mac_pcu_RX_PRIORITY_OFFSET0    0x00028384 29:24  0 1 1 2 1
<  mc_rx_priority_offset0_rssi_low   0   mac_pcu_RX_PRIORITY_OFFSET0    0x00028384 23:18  0 1 1 2 1
<  mc_rx_priority_offset0_rssi_high  0   mac_pcu_RX_PRIORITY_OFFSET0    0x00028384 17:12  0 1 1 2 1
<  mc_phy_rate_low                   0   mac_pcu_RX_PRIORITY_OFFSET0    0x00028384 11:6   0 1 1 2 1
<  mc_phy_rate_high                  0   mac_pcu_RX_PRIORITY_OFFSET0    0x00028384 5:0    0 1 1 2 1
---
>  mc_rx_priority_offset0_xcast_rssi_high                0       RX_PRIORITY_OFFSET0  0x00028384 29:24  0 1 1 2 1
>  mc_rx_priority_offset0_rssi_low                       0       RX_PRIORITY_OFFSET0  0x00028384 23:18  0 1 1 2 1
>  mc_rx_priority_offset0_rssi_high                      0       RX_PRIORITY_OFFSET0  0x00028384 17:12  0 1 1 2 1
>  mc_rx_priority_offset0_phy_rate_low                   0       RX_PRIORITY_OFFSET0  0x00028384 11:6   0 1 1 2 1
>  mc_rx_priority_offset0_phy_rate_high                  0       RX_PRIORITY_OFFSET0  0x00028384 5:0    0 1 1 2 1
619,623c655,659
<  mc_rx_priority_offset1_rts        0   mac_pcu_RX_PRIORITY_OFFSET1    0x00028388 29:24  0 1 1 2 1
<  mc_retx                           0   mac_pcu_RX_PRIORITY_OFFSET1    0x00028388 23:18  0 1 1 2 1
<  mc_rx_priority_offset1_presp_rssi_high 0   mac_pcu_RX_PRIORITY_OFFSET1    0x00028388 17:12  0 1 1 2 1
<  mc_rx_priority_offset1_length_low 0   mac_pcu_RX_PRIORITY_OFFSET1    0x00028388 11:6   0 1 1 2 1
<  mc_rx_priority_offset1_length_high 0   mac_pcu_RX_PRIORITY_OFFSET1    0x00028388 5:0    0 1 1 2 1
---
>  mc_rx_priority_offset1_rts                            0       RX_PRIORITY_OFFSET1  0x00028388 29:24  0 1 1 2 1
>  mc_rx_priority_offset1_retx                           0       RX_PRIORITY_OFFSET1  0x00028388 23:18  0 1 1 2 1
>  mc_rx_priority_offset1_presp_rssi_high                0       RX_PRIORITY_OFFSET1  0x00028388 17:12  0 1 1 2 1
>  mc_rx_priority_offset1_length_low                     0       RX_PRIORITY_OFFSET1  0x00028388 11:6   0 1 1 2 1
>  mc_rx_priority_offset1_length_high                    0       RX_PRIORITY_OFFSET1  0x00028388 5:0    0 1 1 2 1
625,629c661,665
<  mc_rx_priority_offset2_beacon     0   mac_pcu_RX_PRIORITY_OFFSET2    0x0002838c 29:24  0 1 1 2 1
<  mc_mgmt                           0   mac_pcu_RX_PRIORITY_OFFSET2    0x0002838c 23:18  0 1 1 2 1
<  mc_atim                           0   mac_pcu_RX_PRIORITY_OFFSET2    0x0002838c 17:12  0 1 1 2 1
<  mc_presp                          0   mac_pcu_RX_PRIORITY_OFFSET2    0x0002838c 11:6   0 1 1 2 1
<  mc_xcast                          0   mac_pcu_RX_PRIORITY_OFFSET2    0x0002838c 5:0    0 1 1 2 1
---
>  mc_rx_priority_offset2_beacon                         0       RX_PRIORITY_OFFSET2  0x0002838c 29:24  0 1 1 2 1
>  mc_rx_priority_offset2_mgmt                           0       RX_PRIORITY_OFFSET2  0x0002838c 23:18  0 1 1 2 1
>  mc_rx_priority_offset2_atim                           0       RX_PRIORITY_OFFSET2  0x0002838c 17:12  0 1 1 2 1
>  mc_rx_priority_offset2_presp                          0       RX_PRIORITY_OFFSET2  0x0002838c 11:6   0 1 1 2 1
>  mc_rx_priority_offset2_xcast                          0       RX_PRIORITY_OFFSET2  0x0002838c 5:0    0 1 1 2 1
631,635c667,671
<  mc_rx_priority_offset3_ps_poll    0   mac_pcu_RX_PRIORITY_OFFSET3    0x00028390 29:24  0 1 1 2 1
<  mc_amsdu                          0   mac_pcu_RX_PRIORITY_OFFSET3    0x00028390 23:18  0 1 1 2 1
<  mc_rx_priority_offset3_ampdu      0   mac_pcu_RX_PRIORITY_OFFSET3    0x00028390 17:12  0 1 1 2 1
<  mc_rx_priority_offset3_eosp       0   mac_pcu_RX_PRIORITY_OFFSET3    0x00028390 11:6   0 1 1 2 1
<  mc_more                           0   mac_pcu_RX_PRIORITY_OFFSET3    0x00028390 5:0    0 1 1 2 1
---
>  mc_rx_priority_offset3_ps_poll                        0       RX_PRIORITY_OFFSET3  0x00028390 29:24  0 1 1 2 1
>  mc_rx_priority_offset3_amsdu                          0       RX_PRIORITY_OFFSET3  0x00028390 23:18  0 1 1 2 1
>  mc_rx_priority_offset3_ampdu                          0       RX_PRIORITY_OFFSET3  0x00028390 17:12  0 1 1 2 1
>  mc_rx_priority_offset3_eosp                           0       RX_PRIORITY_OFFSET3  0x00028390 11:6   0 1 1 2 1
>  mc_rx_priority_offset3_more                           0       RX_PRIORITY_OFFSET3  0x00028390 5:0    0 1 1 2 1
637,641c673,677
<  mc_rx_priority_offset4_beacon_rssi_high 0   mac_pcu_RX_PRIORITY_OFFSET4    0x00028394 29:24  0 1 1 2 1
<  mc_rx_priority_offset4_mgmt_rssi_high 0   mac_pcu_RX_PRIORITY_OFFSET4    0x00028394 23:18  0 1 1 2 1
<  mc_beacon_ssid                    0   mac_pcu_RX_PRIORITY_OFFSET4    0x00028394 17:12  0 1 1 2 1
<  mc_null                           0   mac_pcu_RX_PRIORITY_OFFSET4    0x00028394 11:6   0 1 1 2 1
<  mc_preq                           0   mac_pcu_RX_PRIORITY_OFFSET4    0x00028394 5:0    0 1 1 2 1
---
>  mc_rx_priority_offset4_beacon_rssi_high               0       RX_PRIORITY_OFFSET4  0x00028394 29:24  0 1 1 2 1
>  mc_rx_priority_offset4_mgmt_rssi_high                 0       RX_PRIORITY_OFFSET4  0x00028394 23:18  0 1 1 2 1
>  mc_rx_priority_offset4_beacon_ssid                    0       RX_PRIORITY_OFFSET4  0x00028394 17:12  0 1 1 2 1
>  mc_rx_priority_offset4_null                           0       RX_PRIORITY_OFFSET4  0x00028394 11:6   0 1 1 2 1
>  mc_rx_priority_offset4_preq                           0       RX_PRIORITY_OFFSET4  0x00028394 5:0    0 1 1 2 1
643,645c679,681
<  mc_rx_priority_offset5_ps_poll_rssi_high 0   mac_pcu_RX_PRIORITY_OFFSET5    0x00028398 17:12  0 1 1 2 1
<  mc_rx_priority_offset5_preq_rssi_high 0   mac_pcu_RX_PRIORITY_OFFSET5    0x00028398 11:6   0 1 1 2 1
<  mc_rx_priority_offset5_null_rssi_high 0   mac_pcu_RX_PRIORITY_OFFSET5    0x00028398 5:0    0 1 1 2 1
---
>  mc_rx_priority_offset5_ps_poll_rssi_high              0       RX_PRIORITY_OFFSET5  0x00028398 17:12  0 1 1 2 1
>  mc_rx_priority_offset5_preq_rssi_high                 0       RX_PRIORITY_OFFSET5  0x00028398 11:6   0 1 1 2 1
>  mc_rx_priority_offset5_null_rssi_high                 0       RX_PRIORITY_OFFSET5  0x00028398 5:0    0 1 1 2 1
647c683
<  mc_mac_pcu_bssid2_l32_addr        0   mac_pcu_MAC_PCU_BSSID2_L32     0x0002839c 31:0   0 1 1 2 1
---
>  mc_mac_pcu_bssid2_l32_addr                            0       MAC_PCU_BSSID2_L32   0x0002839c 31:0   0 1 1 2 1
649,650c685,686
<  mc_mac_pcu_bssid2_u16_enable      0   mac_pcu_MAC_PCU_BSSID2_U16     0x000283a0 16     0 1 1 2 1
<  mc_mac_pcu_bssid2_u16_addr        0   mac_pcu_MAC_PCU_BSSID2_U16     0x000283a0 15:0   0 1 1 2 1
---
>  mc_mac_pcu_bssid2_u16_enable                          0       MAC_PCU_BSSID2_U16   0x000283a0 16     0 1 1 2 1
>  mc_mac_pcu_bssid2_u16_addr                            0       MAC_PCU_BSSID2_U16   0x000283a0 15:0   0 1 1 2 1
652c688
<  mc_mac_pcu_tsf1_status_l32_value  268435455 mac_pcu_MAC_PCU_TSF1_STATUS_L32 0x000283a4 31:0   0 0 1 2 1
---
>  mc_mac_pcu_tsf1_status_l32_value                      268435455 MAC_PCU_TSF1_STATUS_L32 0x000283a4 31:0   0 0 1 2 1
654c690
<  mc_mac_pcu_tsf1_status_u32_value  268435455 mac_pcu_MAC_PCU_TSF1_STATUS_U32 0x000283a8 31:0   0 0 1 2 1
---
>  mc_mac_pcu_tsf1_status_u32_value                      268435455 MAC_PCU_TSF1_STATUS_U32 0x000283a8 31:0   0 0 1 2 1
656c692
<  mc_mac_pcu_tsf2_status_l32_value  268435455 mac_pcu_MAC_PCU_TSF2_STATUS_L32 0x000283ac 31:0   0 0 1 2 1
---
>  mc_mac_pcu_tsf2_status_l32_value                      268435455 MAC_PCU_TSF2_STATUS_L32 0x000283ac 31:0   0 0 1 2 1
658c694
<  mc_mac_pcu_tsf2_status_u32_value  268435455 mac_pcu_MAC_PCU_TSF2_STATUS_U32 0x000283b0 31:0   0 0 1 2 1
---
>  mc_mac_pcu_tsf2_status_u32_value                      268435455 MAC_PCU_TSF2_STATUS_U32 0x000283b0 31:0   0 0 1 2 1
660c696
<  mc_mac_pcu_txbuf_ba_data          0   mac_pcu_MAC_PCU_TXBUF_BA       0x00028400 31:0   0 1 1 2 1
---
>  mc_mac_pcu_txbuf_ba_data                              0       MAC_PCU_TXBUF_BA     0x00028400 31:0   0 1 1 2 1
662c698
<  mc_mac_pcu_key_cache_1_data       0   mac_pcu_MAC_PCU_KEY_CACHE_1    0x00028800 31:0   0 1 1 2 1
---
>  mc_mac_pcu_key_cache_1_data                           0       MAC_PCU_KEY_CACHE_1  0x00028800 31:0   0 1 1 2 1
664c700
<  mc_mac_pcu_baseband_0_data        0   mac_pcu_MAC_PCU_BASEBAND_0     0x00029800 31:0   0 1 1 2 1
---
>  mc_mac_pcu_baseband_0_data                            0       MAC_PCU_BASEBAND_0   0x00029800 31:0   0 1 1 2 1
666c702
<  mc_mac_pcu_baseband_1_data        0   mac_pcu_MAC_PCU_BASEBAND_1     0x0002a000 31:0   0 1 1 2 1
---
>  mc_mac_pcu_baseband_1_data                            0       MAC_PCU_BASEBAND_1   0x0002a000 31:0   0 1 1 2 1
668c704
<  mc_mac_pcu_baseband_2_data        0   mac_pcu_MAC_PCU_BASEBAND_2     0x0002c000 31:0   0 1 1 2 1
---
>  mc_mac_pcu_baseband_2_data                            0       MAC_PCU_BASEBAND_2   0x0002c000 31:0   0 1 1 2 1
670c706
<  mc_mac_pcu_baseband_3_data        0   mac_pcu_MAC_PCU_BASEBAND_3     0x0002d000 31:0   0 1 1 2 1
---
>  mc_mac_pcu_baseband_3_data                            0       MAC_PCU_BASEBAND_3   0x0002d000 31:0   0 1 1 2 1
672c708
<  mc_mac_pcu_buf_data               0   mac_pcu_MAC_PCU_BUF            0x0002e000 31:0   0 1 1 2 1
---
>  mc_mac_pcu_buf_data                                   0       MAC_PCU_BUF          0x0002e000 31:0   0 1 1 2 1
