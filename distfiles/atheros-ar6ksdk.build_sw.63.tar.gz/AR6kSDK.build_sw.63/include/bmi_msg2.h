/*
 * Copyright (c) 2009 Atheros Communications, Inc.
 *
 * Permission to use, copy, modify, and distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */

#if !defined(__ATH6K_BMI_MSG_H__)
#define __ATH6K_BMI_MSG_H__

#include "linux/types.h"

/*
 * Bootloader Messaging Interface (BMI)
 *
 * BMI is a very simple messaging interface used during initialization
 * to read memory, write memory, execute code, and to define an
 * application entry PC.
 *
 * It is used to download an application to AR6K, to provide
 * patches to code that is already resident on AR6K, and generally
 * to examine and modify state.  The Host has an opportunity to use
 * BMI only once during bootup.  Once the Host issues a BMI_DONE
 * command, this opportunity ends.
 *
 * The Host writes BMI requests to mailbox0, and reads BMI responses
 * from mailbox0, subject to the Host/Target BMI Protocol.   BMI
 * requests all begin with a command (see below for specific commands),
 * and are followed by command-specific data.
 *
 * Flow control:
 * The Host can only issue a command once the Target gives it a
 * "BMI Command Credit", using AR6K Counter #4.  As soon as the
 * Target has completed a command, it issues another BMI Command
 * Credit (so the Host can issue the next command).
 */


/* Maximum data size used for BMI transfers */
#define BMI_DATASZ_MAX                      256

/* Maximum size used for BMI commands */
#define BMI_CMDSZ_MAX (BMI_DATASZ_MAX + \
                       sizeof(u32) /* cmd */ + \
                       sizeof(u32) /* addr */ + \
                       sizeof(u32))/* length */

#define BMI_COMMAND_FITS(sz) ((sz) <= BMI_CMDSZ_MAX)

/* BMI Commands */

#define BMI_NO_COMMAND                      0

#define BMI_DONE                            1
        /*
         * Semantics: Host is done using BMI
         *
         * Request format:
         * 	struct bmi_done_cmd
         *
         * Response format: none
         */
struct bmi_done_cmd {
	__u32	command;	/* BMI_DONE */
};

#define BMI_READ_MEMORY                     2
        /*
         * Semantics: Host reads AR6K memory
         *
         * Request format:
         * 	struct bmi_read_memory_cmd
         *
         * Response format:
         * 	u8 data[length]
         */
struct bmi_read_memory_cmd {
	__u32	command;
	__u32	address;
	__u32	length; /* in bytes, <= BMI_DATASZ_MAX */
};

#define BMI_WRITE_MEMORY                    3
        /*
         * Semantics: Host writes AR6K memory
         *
         * Request format:
         * 	struct bmi_write_memory_cmd_hdr
         * 	u8 data[length]
         *
         * Response format: none
         */
struct bmi_write_memory_cmd_hdr {
	__u32	command;
	__u32	address;
	__u32	length;
};

#define BMI_EXECUTE                         4
        /*
         * Semantics: Causes AR6K to execute code
         *
         * Request format:
         * 	struct bmi_execute_cmd
         *
         * Response format:
         *    u32      return value
         */
struct bmi_execute_cmd {
	__u32	command;
	__u32	address;
	__u32	param;
};

#define BMI_SET_APP_START                   5
        /*
         * Semantics: Set Target application starting address
         *
         * Request format:
         * 	struct bmi_set_app_start_cmd
         *
         * Response format: none
         */
struct bmi_set_app_start_cmd {
	__u32	command;
	__u32	address;
};

#define BMI_READ_SOC_REGISTER               6
        /*
         * Semantics: Read a 32-bit Target SOC register.
         *
         * Request format:
         * 	struct bmi_read_soc_register_cmd
         *
         * Response format: 
         *    u32      value
         */
struct bmi_read_soc_register_cmd {
	__u32	command;
	__u32	address;
};

#define BMI_WRITE_SOC_REGISTER              7
        /*
         * Semantics: Write a 32-bit Target SOC register.
         *
         * Request format:
         * 	struct bmi_write_soc_register_cmd
         *
         * Response format: none
         */
struct bmi_write_soc_register_cmd {
	__u32	command;
	__u32	address;
	__u32	value;
};

#define BMI_GET_TARGET_ID                  8
#define BMI_GET_TARGET_INFO                8
        /*
         * Semantics: Fetch Target information
         * 
         * Request format:
         * 	struct bmi_get_target_info_cmd
         *
         * Response format1 (old firmware):
         * 	u32	TargetVersionID
         * Response format2 (newer firmware):
         * 	u32			TARGET_VERSION_SENTINAL
         * 	struct bmi_target_info  targ_info;
         */
struct bmi_get_target_info_cmd {
	__u32	command;
};

struct bmi_target_info {
	__u32 target_info_byte_count; /* ==sizeof(struct bmi_target_info) */
	__u32 target_ver;             /* Target Version ID */
	__u32 target_type;            /* Target type */
};
#define TARGET_VERSION_SENTINAL 0xffffffff
#define TARGET_TYPE_AR6001 1
#define TARGET_TYPE_AR6002 2
#define TARGET_TYPE_AR6003 3


#define BMI_ROMPATCH_INSTALL               9
        /*
         * Semantics: Install a ROM Patch.
         *
         * Request format:
         * 	struct bmi_rompatch_install_cmd
         *
         * Response format:
         *    u32      PatchID
         */
struct bmi_rompatch_install_cmd {
	__u32	command;
	__u32	address;		/* ROM address */
	__u32	address_or_value;	/* RAM address or value */
	__u32	size;			/* Size in bytes */
	__u32	activate;		/* 0 or 1 */
};

#define BMI_ROMPATCH_UNINSTALL             10
        /*
         * Semantics: Uninstall a previously-installed ROM Patch,
         * automatically deactivating, if necessary.
         *
         * Request format:
         * 	struct bmi_rompatch_uninstall_cmd
         *
         * Response format: none
         */
struct bmi_rompatch_uninstall_cmd {
	__u32	command;
	__u32	PatchID;
};

#define BMI_ROMPATCH_ACTIVATE              11
        /*
         * Semantics: Activate a list of previously-installed ROM Patches.
         *
         * Request format:
         * 	struct bmi_rompatch_activate_cmd_hdr
         * 	u32 PatchID[rompatch_count]
         *
         * Response format: none
         */
struct bmi_rompatch_activate_cmd_hdr {
	__u32	command;
	__u32	rompatch_count;
};

#define BMI_ROMPATCH_DEACTIVATE            12
        /*
         * Semantics: Deactivate a list of active ROM Patches.
         *
         * Request format:
         * 	struct bmi_rompatch_deactivate_cmd_hdr
         * 	u32 PatchID[rompatch_count]
         *
         * Response format: none
         */
struct bmi_rompatch_deactivate_cmd_hdr {
	__u32	command;
	__u32	rompatch_count;
};


#define BMI_LZ_STREAM_START                13
        /*
         * Semantics: Begin an LZ-compressed stream of input
         * which is to be uncompressed by the Target to an
         * output buffer at address.  The output buffer must
         * be sufficiently large to hold the uncompressed
         * output from the compressed input stream.  This BMI
         * command can be followed by a series of BMI_LZ_DATA
         * commands.
         *
         * Request format:
         * 	struct bmi_lz_stream_start_cmd
         *
         * Response format: none
         */
struct bmi_lz_stream_start_cmd {
	__u32	command;
	__u32	address;
};

#define BMI_LZ_DATA                        14
        /*
         * Semantics: Host writes AR6K memory with LZ-compressed
         * data which is uncompressed by the Target.  This command
         * must be preceded by a BMI_LZ_STREAM_START command. A series
         * of BMI_LZ_DATA commands are considered part of a single
         * input stream until another BMI_LZ_STREAM_START is issued.
         *
         * Request format:
         * 	struct bmi_lz_data_cmd_hdr
         * 	u8 CompressedData[length]
         *
         * Response format: none
         *
         * Note: Not supported on all versions of ROM firmware.
         */
struct bmi_lz_data_cmd_hdr {
	__u32	command;
	__u32	length;	/* in bytes, <= BMI_DATASZ_MAX */
};

#endif /* __ATH6K_BMI_MSG_H__ */
