NETIF=${NETIF:-eth1}
logfile="/var/log/ath6klog.txt"
# target firmware hierarchy
ATH6K_FWDIR=/lib/firmware/ath6k
# NB: also used to chase /sys/module pathnames
ATH6K_MODULE_NAME=ar6000
# NB: fwmode=1 enables sta mode
ATH6K_MODULE_ARGS="bmienable=1 fwmode=1 busspeedlow=0"

bmiload()
{
	/usr/local/sbin/bmiloader -i $NETIF $*
}

eeprom()
{
	/usr/local/sbin/eeprom $* --interface=$NETIF
}

/usr/local/sbin/recEvent $logfile /dev/null 2>&1 &
modprobe $ATH6K_MODULE_NAME $ATH6K_MODULE_ARGS
if [ $? -ne 0 ]; then
	echo "Failed to load ath6k module"
	exit -1
fi

# Load the Target firmware, load EEPROM and exit BMI mode.
exit_value=0

if [ -e "/sys/module/$ATH6K_MODULE_NAME/debugbmi" ]; then
    PARAMETERS="/sys/module/$ATH6K_MODULE_NAME"
fi
if [ -e "/sys/module/$ATH6K_MODULE_NAME/parameters/debugbmi" ]; then
    PARAMETERS="/sys/module/$ATH6K_MODULE_NAME/parameters"
fi
if [ "$PARAMETERS" != "" ]; then
    # For speed, temporarily disable Host-side debugging
    save_dbg=`cat ${PARAMETERS}/debugdriver`
    echo 0 > ${PARAMETERS}/debugdriver
fi

if [ "$TARGET_TYPE" = "" ]; then
    # Determine TARGET_TYPE
    eval export `bmiload --quiet --info | grep TARGET_TYPE`
fi
#echo TARGET TYPE is $TARGET_TYPE

if [ "$TARGET_VERSION" = "" ]; then
    # Determine TARGET_VERSION
    eval export `bmiload --quiet --info | grep TARGET_VERSION`
fi
AR6002_VERSION_REV2=0x20000188
# echo TARGET VERSION is $TARGET_VERSION

if [ "$TARGET_TYPE" = "AR6002" -o "$TARGET_TYPE" = "AR6003" ]; then
    # Temporarily disable System Sleep on AR6002
    old_options=`bmiload --quiet --set --address=0x180c0 --or=8`
    old_sleep=`bmiload --quiet --set --address=0x40c4 --or=1`

    # AR6002 REV2 clock setup.

    if [ "$TARGET_VERSION" = "$AR6002_VERSION_REV2" ]; then
	host_intr_addr=0x500400
    else # AR6002_VERSION_REV4 (AR6003)
	host_intr_addr=0x540600
    fi

    # Run at 40/44MHz by default.
    bmiload --quiet --set --address=0x4020 --param=0

    # It is the Host's responsibility to set hi_refclk_hz
    # according to the actual speed of the reference clock.
    #
    # hi_refclk_hz to 26MHz
    # (Commented out because 26MHz is the default.)
    # bmiload --quiet --set --address=$(($host_intr_addr + 0x78)) --param=26000000

    want_lpo_cal=1
    if [ "$TARGET_TYPE" = "AR6002" ]; then
	# If an external LF clock is detected, use it.
	# No need for LPO calibration in that case.
	ext_clk_detected=`bmiload --quiet --get --address=$(($host_intr_addr + 0x7c))`
	if [ $ext_clk_detected = 0x1 ]; then
	    want_lpo_cal=0
	fi
    fi

    if [ $want_lpo_cal -eq 1 ];  then
	# LPO_CAL_TIME is based on refclk speed: 27500/Actual_MHz_of_refclk
	# So for 26MHz (the default), we would use:
	# param=$((27500/26))
	# bmiload --quiet --set --address=0x40d4 --param=$param

	# LPO_CAL.ENABLE = 1
	bmiload --quiet --set --address=0x40e0 --param=0x100000
    fi

    # Set XTAL_SETTLE to ~2Ms default; some crystals may require longer settling time.
    # In general, XTAL_SETTLE time is handled by the WLAN driver (because it needs
    # to match the MAC's SLEEP32_WAKE_XTL_TIME).  The driver's default is 2Ms; so for
    # typical use there's no need to set it here.
    # param=ceiling(DesiredSeconds*32768)
    # bmiload --quiet --set --address=0x401c --param=66
fi

if [ "$RPDF_FILE" = "" ]; then
    # Default value for ROM Patch Distribution file
    # is based on Target type and revision.
    if [ "$TARGET_TYPE" = "AR6001" ]; then
	RPDF_FILE=$ATH6K_FWDIR/AR6001/bin/patch.rpdf
    else
      if [ "$TARGET_VERSION" = "$AR6002_VERSION_REV2" ]; then
	RPDF_FILE=$ATH6K_FWDIR/AR6002/hw2.0/bin/patch.rpdf
      fi
    fi
fi

if [ "$RPDF_FILE" != "" -a -r "$RPDF_FILE" ]; then
    echo "Install ROM Patch Distribution File, " $RPDF_FILE
    $IMAGEPATH/fwpatch --interface=$NETIF --file=$RPDF_FILE
    if [ $? -ne 0 ]; then
	echo "Failed to load ROM Patch Distribution"
	exit_value=-1
    fi
fi

if [ "$TARGET_TYPE" = "AR6002" ]; then
    if [ "$EEPROM" != "" ]; then
	echo "Load Board Data from $EEPROM"
	if [ "$macaddr" = "" ]; then
	    eeprom --transfer --file=$EEPROM
	else
	    eeprom --transfer --setmac=$macaddr --file=$EEPROM
	fi
	if [ $? -ne 0 ]
	then
	    echo "Failed to load AR6002 Board Data from file."
	    exit_value=-1
	fi
    else
	if [ "$TARGET_VERSION" = "$AR6002_VERSION_REV2" ]; then
	    bmiload --write --address=0x502070 --file=$ATH6K_FWDIR/AR6002/hw2.0/bin/eeprom.data
	    bmiload --write --address=0x514a00 --file=$ATH6K_FWDIR/AR6002/hw2.0/bin/eeprom.bin
	    bmiload --execute --address=0x914a00 --param=0
	fi
    fi
fi

if [ "$TARGET_TYPE" = "AR6003" ]; then
    # For AR6002_REV4 FPGA 
    #EEPROM=${EEPROM:-$ATH6K_FWDIR/AR6003/fakeBoardData_AR6003.bin}
    # For AR6002_REV4 1.0  
    EEPROM=${EEPROM:-$ATH6K_FWDIR/AR6003/fakeBoardData_AR6003_v1_0.bin}
    if [ "$EEPROM" != "" ]; then
	echo "Load Board Data from $EEPROM"
	if [ "$macaddr" = "" ]; then
	    eeprom --transfer --file=$EEPROM
	else
	    eeprom --transfer --setmac=$macaddr --file=$EEPROM
	fi
	if [ $? -ne 0 ]; then
	    echo "Failed to load AR6003 Board Data from file."
	    exit_value=-1
	fi
    fi
fi


# For AR6002/AR6003, download athwlan.bin to Target RAM.
# For AR6001, athwlan is already in ROM or Flash.
if [ "$TARGET_TYPE" = "AR6002" -o "$TARGET_TYPE" = "AR6003" ]; then
    # Download the Target application, usually athwlan.bin,
    # into Target RAM.
    if [ "$TARGET_VERSION" = "$AR6002_VERSION_REV2" ]; then
	LOADADDR=0x502070
	BEGINADDR=0x914a00
	wlanapp=${wlanapp:-$ATH6K_FWDIR/AR6002/hw2.0/bin/athwlan.bin}
	dsetimg=${dsetimg:-$ATH6K_FWDIR/AR6002/hw2.0/bin/data.patch.hw2_0.bin}

	# Enable HI_OPTION_TIMER_WAR (timerwar)
	bmiload --set --address=0x500410 --or=1
    fi

    if [ "$TARGET_TYPE" = "AR6003" ]; then
	LOADADDR=0x543000
	BEGINADDR=0x945000
	# For AR6002_REV4 FPGA 
	#wlanapp=${wlanapp:-$ATH6K_FWDIR/AR6003/fpga/bin/athwlan.bin}
	# For AR6002_REV4 1.0  
	wlanapp=${wlanapp:-$ATH6K_FWDIR/AR6003/hw1.0/bin/athwlan.bin}
	dsetimg=${dsetimg:-$ATH6K_FWDIR/AR6003/hw1.0/bin/data.patch.hw1_0.bin}
	dbguart_tx=${dbguart_tx:-8}
    fi

    if [ -r $wlanapp.z77 -o -r $wlanapp ]; then
	# Use a compressed RAM image, if one is available....
	if [ -r $wlanapp.z77 ]; then
	    # If a compressed version of the WLAN application exists, use it
	    bmiload --write --address=$LOADADDR --file=$wlanapp.z77 --uncompress
	else
	    # ...otherwise, use an uncompressed RAM image.
	    bmiload --write --address=$LOADADDR --file=$wlanapp
	fi

	# If any RAM image was used, set the application start address.
	bmiload --begin --address=$BEGINADDR
    fi

    # WLAN Patch DataSets
    if [ "$TARGET_VERSION" = "$AR6002_VERSION_REV2" ]; then
	bmiload --write --address=0x52d8b0 --file=$dsetimg
	bmiload --write --address=0x500418 --param=0x52d8b0
    fi

    if [ "$TARGET_TYPE" = "AR6003" ]; then
	#reserve 8K of RAM
	bmiload --set --address=0x540668 --param=8192
	bmiload --write --address=0x57e6c4 --file=$dsetimg
	bmiload --write --address=0x540618 --param=0x57e6c4
    fi

    # Restore System Sleep on AR6002/AR6003
    bmiload --set --address=0x40c4 --param=$old_sleep > /dev/null
    bmiload --set --address=0x180c0 --param=$old_options > /dev/null

    if [ "$TARGET_TYPE" = "AR6003" ]; then
	# Configure GPIO AR6003 UART
	bmiload --set --address=0x540680 --param=$dbguart_tx
    fi
fi

if [ "$TARGET_TYPE" = "AR6001" ]; then
    # Request maximum system performance (max clock rates)
    bmiload --set --address=0xac000020 --param=0x203 > /dev/null
    bmiload --set --address=0xac000024 --param=0x203 > /dev/null
fi

if [ "$PARAMETERS" != "" ]; then
    # Restore Host debug state.
    echo $save_dbg > ${PARAMETERS}/debugdriver
fi

if [ \( $exit_value -eq 0 \) ]; then
    # Leave BMI now and start the WLAN driver.
    bmiload --done
fi

exit $exit_value
