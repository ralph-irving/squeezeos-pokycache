/*
 * Copyright (c) 2008 Atheros Communications, Inc.
 * All rights reserved.
 * 
 *
 * 
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License version 2 as
// published by the Free Software Foundation;
//
// Software distributed under the License is distributed on an "AS
// IS" basis, WITHOUT WARRANTY OF ANY KIND, either express or
// implied. See the License for the specific language governing
// rights and limitations under the License.
//
//
 * 
 */

#define AR6001 1

#include "AR6001/hw/apb_map.h"
#include "AR6001/hw/gpio_reg.h"
#include "AR6001/hw/rtc_reg.h"
#include "AR6001/hw/si_reg.h"

#define MY_TARGET_DEF AR6001def
#define MY_TARGET_BOARD_DATA_SZ AR6000_BOARD_DATA_SZ
#include "targetdef.h"
